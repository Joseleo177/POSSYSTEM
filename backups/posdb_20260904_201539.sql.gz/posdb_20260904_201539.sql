--
-- PostgreSQL database dump
--

\restrict 9GKPv3L0hu2RbuLMxPdoQeeUqu2EdlTTmkKi1hZLw0qM1BglWVTI7yw3J5F1kpC

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: posuser
--

CREATE FUNCTION public.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at() OWNER TO posuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO posuser;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    employee_id integer,
    employee_name character varying(200),
    method character varying(10) NOT NULL,
    path character varying(500) NOT NULL,
    ip character varying(60),
    status_code integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO posuser;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO posuser;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: banks; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.banks (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(10),
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.banks OWNER TO posuser;

--
-- Name: banks_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.banks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.banks_id_seq OWNER TO posuser;

--
-- Name: banks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.banks_id_seq OWNED BY public.banks.id;


--
-- Name: cash_session_journals; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.cash_session_journals (
    id integer NOT NULL,
    session_id integer,
    journal_id integer,
    opening_amount numeric(12,2) DEFAULT 0 NOT NULL,
    closing_amount numeric(12,2),
    expected_amount numeric(12,2),
    difference numeric(12,2),
    company_id integer NOT NULL
);


ALTER TABLE public.cash_session_journals OWNER TO posuser;

--
-- Name: cash_session_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.cash_session_journals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_session_journals_id_seq OWNER TO posuser;

--
-- Name: cash_session_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.cash_session_journals_id_seq OWNED BY public.cash_session_journals.id;


--
-- Name: cash_sessions; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.cash_sessions (
    id integer NOT NULL,
    employee_id integer,
    warehouse_id integer,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    notes text,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    company_id integer NOT NULL
);


ALTER TABLE public.cash_sessions OWNER TO posuser;

--
-- Name: cash_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.cash_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_sessions_id_seq OWNER TO posuser;

--
-- Name: cash_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.cash_sessions_id_seq OWNED BY public.cash_sessions.id;


--
-- Name: catalog_banners; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.catalog_banners (
    id integer NOT NULL,
    title character varying(120),
    image_filename character varying(500) NOT NULL,
    image_mobile_filename character varying(500),
    link_url character varying(500),
    alt_text character varying(200),
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    company_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.catalog_banners OWNER TO posuser;

--
-- Name: catalog_banners_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.catalog_banners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.catalog_banners_id_seq OWNER TO posuser;

--
-- Name: catalog_banners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.catalog_banners_id_seq OWNED BY public.catalog_banners.id;


--
-- Name: catalog_benefit_tags; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.catalog_benefit_tags (
    id integer NOT NULL,
    name character varying(60) NOT NULL,
    company_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.catalog_benefit_tags OWNER TO posuser;

--
-- Name: catalog_benefit_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.catalog_benefit_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.catalog_benefit_tags_id_seq OWNER TO posuser;

--
-- Name: catalog_benefit_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.catalog_benefit_tags_id_seq OWNED BY public.catalog_benefit_tags.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20) DEFAULT NULL::character varying,
    company_id integer NOT NULL,
    image_filename character varying(500) DEFAULT NULL::character varying,
    short_description character varying(160) DEFAULT NULL::character varying
);


ALTER TABLE public.categories OWNER TO posuser;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO posuser;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    tax_id character varying(50),
    address text,
    phone character varying(20),
    email character varying(150),
    active boolean DEFAULT true NOT NULL,
    logo_url character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    plan_name character varying(50) DEFAULT 'Básico'::character varying NOT NULL,
    subscription_status character varying(20) DEFAULT 'Demo'::character varying NOT NULL,
    expires_at timestamp with time zone,
    max_users integer DEFAULT 5 NOT NULL,
    catalog_enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.companies OWNER TO posuser;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companies_id_seq OWNER TO posuser;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.currencies (
    id integer NOT NULL,
    code character varying(3) NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(5) NOT NULL,
    exchange_rate numeric(12,6) DEFAULT 1.0 NOT NULL,
    is_base boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.currencies OWNER TO posuser;

--
-- Name: currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.currencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.currencies_id_seq OWNER TO posuser;

--
-- Name: currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.currencies_id_seq OWNED BY public.currencies.id;


--
-- Name: customer_credit_movements; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.customer_credit_movements (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    warehouse_id integer,
    amount numeric(14,6) NOT NULL,
    reason character varying(30) NOT NULL,
    sale_id integer,
    return_id integer,
    employee_id integer,
    company_id integer,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.customer_credit_movements OWNER TO posuser;

--
-- Name: customer_credit_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.customer_credit_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_credit_movements_id_seq OWNER TO posuser;

--
-- Name: customer_credit_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.customer_credit_movements_id_seq OWNED BY public.customer_credit_movements.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    type character varying(20) DEFAULT 'cliente'::character varying NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20),
    email character varying(150),
    address text,
    rif character varying(15),
    tax_name character varying(200),
    tax_regime character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    credit_balance numeric(14,6) DEFAULT 0 NOT NULL
);


ALTER TABLE public.customers OWNER TO posuser;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO posuser;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: employee_warehouses; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.employee_warehouses (
    employee_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.employee_warehouses OWNER TO posuser;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    email character varying(150),
    phone character varying(20),
    role_id integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.employees OWNER TO posuser;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO posuser;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    active boolean DEFAULT true,
    company_id integer NOT NULL
);


ALTER TABLE public.expense_categories OWNER TO posuser;

--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_categories_id_seq OWNER TO posuser;

--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    reference character varying(50),
    description character varying(255) NOT NULL,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    rate numeric(14,6) DEFAULT 1,
    category_id integer NOT NULL,
    payment_journal_id integer,
    employee_id integer NOT NULL,
    notes text,
    status character varying(20) DEFAULT 'activo'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    company_id integer NOT NULL,
    date timestamp with time zone,
    warehouse_id integer
);


ALTER TABLE public.expenses OWNER TO posuser;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO posuser;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: income_categories; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.income_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    active boolean DEFAULT true,
    company_id integer
);


ALTER TABLE public.income_categories OWNER TO posuser;

--
-- Name: income_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.income_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_categories_id_seq OWNER TO posuser;

--
-- Name: income_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.income_categories_id_seq OWNED BY public.income_categories.id;


--
-- Name: incomes; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.incomes (
    id integer NOT NULL,
    reference character varying(50),
    description character varying(255) NOT NULL,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    rate numeric(14,6) DEFAULT 1,
    category_id integer NOT NULL,
    payment_journal_id integer,
    employee_id integer NOT NULL,
    company_id integer,
    notes text,
    status character varying(20) DEFAULT 'activo'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    date timestamp with time zone,
    warehouse_id integer
);


ALTER TABLE public.incomes OWNER TO posuser;

--
-- Name: incomes_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.incomes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incomes_id_seq OWNER TO posuser;

--
-- Name: incomes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.incomes_id_seq OWNED BY public.incomes.id;


--
-- Name: payment_journals; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.payment_journals (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(30) DEFAULT 'efectivo'::character varying NOT NULL,
    bank_id integer,
    currency_id integer,
    bank character varying(200),
    color character varying(7) DEFAULT '#555555'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    company_id integer NOT NULL,
    warehouse_id integer
);


ALTER TABLE public.payment_journals OWNER TO posuser;

--
-- Name: payment_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.payment_journals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_journals_id_seq OWNER TO posuser;

--
-- Name: payment_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.payment_journals_id_seq OWNED BY public.payment_journals.id;


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.payment_methods (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(50) NOT NULL,
    color character varying(7) DEFAULT '#555555'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    allows_outflow boolean DEFAULT true NOT NULL
);


ALTER TABLE public.payment_methods OWNER TO posuser;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_methods_id_seq OWNER TO posuser;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    customer_id integer,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    exchange_rate numeric(12,6) DEFAULT 1.0 NOT NULL,
    payment_journal_id integer,
    employee_id integer,
    reference_date date,
    reference_number character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    change_given numeric(14,6) DEFAULT NULL::numeric,
    change_journal_id integer,
    company_id integer NOT NULL,
    idempotency_key character varying(100),
    batch_id character varying(64)
);


ALTER TABLE public.payments OWNER TO posuser;

--
-- Name: COLUMN payments.change_given; Type: COMMENT; Schema: public; Owner: posuser
--

COMMENT ON COLUMN public.payments.change_given IS 'Cambio/vuelto entregado al cliente (en moneda base)';


--
-- Name: COLUMN payments.change_journal_id; Type: COMMENT; Schema: public; Owner: posuser
--

COMMENT ON COLUMN public.payments.change_journal_id IS 'Diario del que se descontó el cambio entregado';


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO posuser;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: product_benefit_tags; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.product_benefit_tags (
    product_id integer NOT NULL,
    benefit_tag_id integer NOT NULL
);


ALTER TABLE public.product_benefit_tags OWNER TO posuser;

--
-- Name: product_combo_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.product_combo_items (
    id integer NOT NULL,
    combo_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.product_combo_items OWNER TO posuser;

--
-- Name: product_combo_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.product_combo_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_combo_items_id_seq OWNER TO posuser;

--
-- Name: product_combo_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.product_combo_items_id_seq OWNED BY public.product_combo_items.id;


--
-- Name: product_lots; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.product_lots (
    id integer NOT NULL,
    product_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    lot_number character varying(100) NOT NULL,
    expiration_date date NOT NULL,
    qty numeric(10,3) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.product_lots OWNER TO posuser;

--
-- Name: product_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.product_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_lots_id_seq OWNER TO posuser;

--
-- Name: product_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.product_lots_id_seq OWNED BY public.product_lots.id;


--
-- Name: product_stock; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.product_stock (
    warehouse_id integer NOT NULL,
    product_id integer NOT NULL,
    qty numeric(10,3) DEFAULT 0 NOT NULL,
    company_id integer NOT NULL,
    price numeric(14,5),
    min_stock numeric(10,3),
    cost_price numeric(14,4),
    CONSTRAINT product_stock_qty_check CHECK ((qty >= (0)::numeric))
);


ALTER TABLE public.product_stock OWNER TO posuser;

--
-- Name: products; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    price numeric(14,5) NOT NULL,
    stock numeric(10,3) DEFAULT 0 NOT NULL,
    unit character varying(20) DEFAULT 'unidad'::character varying NOT NULL,
    qty_step numeric(10,3) DEFAULT 1.000 NOT NULL,
    category_id integer,
    image_filename character varying(255),
    cost_price numeric(14,4),
    profit_margin numeric(5,2) DEFAULT NULL::numeric,
    min_stock numeric(10,3) DEFAULT 0 NOT NULL,
    package_size numeric(10,3) DEFAULT NULL::numeric,
    package_unit character varying(50) DEFAULT NULL::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_service boolean DEFAULT false NOT NULL,
    is_combo boolean DEFAULT false NOT NULL,
    barcode character varying(50),
    company_id integer NOT NULL,
    bulk_price numeric(14,5),
    visible_in_catalog boolean DEFAULT false NOT NULL,
    sellable boolean DEFAULT true NOT NULL,
    brand character varying(80) DEFAULT NULL::character varying,
    short_description character varying(200) DEFAULT NULL::character varying,
    description text,
    CONSTRAINT products_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT products_stock_check CHECK ((stock >= (0)::numeric))
);


ALTER TABLE public.products OWNER TO posuser;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO posuser;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: promotion_products; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.promotion_products (
    promotion_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.promotion_products OWNER TO posuser;

--
-- Name: promotions; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.promotions (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    discount_pct numeric(5,2),
    buy_qty integer,
    get_qty integer,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    active boolean DEFAULT true NOT NULL,
    company_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    warehouse_id integer
);


ALTER TABLE public.promotions OWNER TO posuser;

--
-- Name: promotions_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.promotions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.promotions_id_seq OWNER TO posuser;

--
-- Name: promotions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.promotions_id_seq OWNED BY public.promotions.id;


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.purchase_items (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    product_id integer,
    product_name character varying(200) NOT NULL,
    package_unit character varying(50) DEFAULT 'unidad'::character varying NOT NULL,
    package_qty numeric(10,3) DEFAULT 1 NOT NULL,
    package_size numeric(10,3) DEFAULT 1 NOT NULL,
    package_price numeric(14,5) NOT NULL,
    unit_cost numeric(14,5) NOT NULL,
    profit_margin numeric(5,2) DEFAULT 0 NOT NULL,
    sale_price numeric(14,5) NOT NULL,
    total_units numeric(10,3) NOT NULL,
    subtotal numeric(14,5) NOT NULL,
    lot_number character varying(100) DEFAULT NULL::character varying,
    expiration_date date,
    update_price boolean DEFAULT true NOT NULL
);


ALTER TABLE public.purchase_items OWNER TO posuser;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.purchase_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_items_id_seq OWNER TO posuser;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.purchase_items_id_seq OWNED BY public.purchase_items.id;


--
-- Name: purchase_payments; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.purchase_payments (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    exchange_rate numeric(12,6) DEFAULT 1 NOT NULL,
    payment_journal_id integer,
    employee_id integer,
    reference_date date,
    reference_number character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.purchase_payments OWNER TO posuser;

--
-- Name: purchase_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.purchase_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_payments_id_seq OWNER TO posuser;

--
-- Name: purchase_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.purchase_payments_id_seq OWNED BY public.purchase_payments.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.purchases (
    id integer NOT NULL,
    supplier_id integer,
    supplier_name character varying(200),
    notes text,
    total numeric(10,2) DEFAULT 0 NOT NULL,
    employee_id integer,
    warehouse_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    payment_status character varying(20) DEFAULT 'pendiente'::character varying NOT NULL,
    company_id integer NOT NULL,
    status character varying(20) DEFAULT 'recibido'::character varying NOT NULL,
    currency_id integer,
    exchange_rate numeric(12,6) DEFAULT 1 NOT NULL
);


ALTER TABLE public.purchases OWNER TO posuser;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchases_id_seq OWNER TO posuser;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.quotation_items (
    id integer NOT NULL,
    quotation_id integer NOT NULL,
    product_id integer,
    product_name character varying(255) NOT NULL,
    quantity numeric(14,4) NOT NULL,
    price numeric(14,4) NOT NULL,
    subtotal numeric(14,2) NOT NULL
);


ALTER TABLE public.quotation_items OWNER TO posuser;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.quotation_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_items_id_seq OWNER TO posuser;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.quotations (
    id integer NOT NULL,
    customer_id integer,
    customer_name character varying(255),
    customer_rif character varying(50),
    employee_id integer,
    warehouse_id integer,
    currency_id integer,
    exchange_rate numeric(14,6) DEFAULT 1,
    discount_amount numeric(14,2) DEFAULT 0,
    subtotal numeric(14,2) NOT NULL,
    total numeric(14,2) NOT NULL,
    status character varying(20) DEFAULT 'pendiente'::character varying,
    notes text,
    converted_sale_id integer,
    company_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.quotations OWNER TO posuser;

--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotations_id_seq OWNER TO posuser;

--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: return_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer,
    name character varying(300) NOT NULL,
    price numeric(14,5) NOT NULL,
    qty numeric(10,3) NOT NULL,
    subtotal numeric(14,6) NOT NULL,
    sale_item_id integer,
    company_id integer NOT NULL
);


ALTER TABLE public.return_items OWNER TO posuser;

--
-- Name: return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.return_items_id_seq OWNER TO posuser;

--
-- Name: return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.return_items_id_seq OWNED BY public.return_items.id;


--
-- Name: returns; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.returns (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    employee_id integer,
    reason character varying(500),
    total numeric(14,6) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    nc_number character varying(50),
    status character varying(20) DEFAULT 'activo'::character varying NOT NULL,
    annulled_at timestamp with time zone,
    annulled_by integer
);


ALTER TABLE public.returns OWNER TO posuser;

--
-- Name: returns_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.returns_id_seq OWNER TO posuser;

--
-- Name: returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.returns_id_seq OWNED BY public.returns.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.roles OWNER TO posuser;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO posuser;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.sale_items (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    product_id integer,
    name character varying(200) NOT NULL,
    price numeric(14,5) NOT NULL,
    quantity numeric(10,3) NOT NULL,
    discount numeric(14,5) DEFAULT 0 NOT NULL,
    subtotal numeric(14,5) GENERATED ALWAYS AS (((price - discount) * quantity)) STORED,
    cost_price numeric(14,5),
    note character varying(200) DEFAULT NULL::character varying,
    CONSTRAINT sale_items_quantity_check CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.sale_items OWNER TO posuser;

--
-- Name: sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sale_items_id_seq OWNER TO posuser;

--
-- Name: sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.sale_items_id_seq OWNED BY public.sale_items.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    total numeric(14,5) NOT NULL,
    paid numeric(10,2) NOT NULL,
    change numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'pendiente'::character varying NOT NULL,
    customer_id integer,
    employee_id integer,
    currency_id integer,
    exchange_rate numeric(12,6) DEFAULT 1.0 NOT NULL,
    discount_amount numeric(10,2) DEFAULT 0 NOT NULL,
    payment_method character varying(30) DEFAULT 'efectivo'::character varying NOT NULL,
    payment_method_id integer,
    payment_journal_id integer,
    warehouse_id integer,
    serie_id integer,
    serie_range_id integer,
    correlative_number integer,
    invoice_number character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    idempotency_key character varying(64),
    credit_applied numeric(14,6) DEFAULT 0 NOT NULL,
    web_customer_name character varying(120),
    web_customer_phone character varying(30),
    web_note text,
    held_by_employee_id integer,
    held_at timestamp with time zone,
    service_charge numeric(14,5) DEFAULT 0 NOT NULL,
    service_charge_label character varying(40),
    forgiven_amount numeric(14,6) DEFAULT 0 NOT NULL,
    forgiven_reason character varying(300),
    forgiven_by integer,
    forgiven_at timestamp with time zone,
    requested_warehouse_id integer
);


ALTER TABLE public.sales OWNER TO posuser;

--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_id_seq OWNER TO posuser;

--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- Name: serie_ranges; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.serie_ranges (
    id integer NOT NULL,
    serie_id integer NOT NULL,
    start_number integer NOT NULL,
    end_number integer NOT NULL,
    current_number integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.serie_ranges OWNER TO posuser;

--
-- Name: serie_ranges_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.serie_ranges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.serie_ranges_id_seq OWNER TO posuser;

--
-- Name: serie_ranges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.serie_ranges_id_seq OWNED BY public.serie_ranges.id;


--
-- Name: series; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.series (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    prefix character varying(10) NOT NULL,
    padding integer DEFAULT 4 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    type character varying(20) DEFAULT 'factura'::character varying NOT NULL,
    warehouse_id integer NOT NULL,
    nc_serie_id integer
);


ALTER TABLE public.series OWNER TO posuser;

--
-- Name: series_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.series_id_seq OWNER TO posuser;

--
-- Name: series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.series_id_seq OWNED BY public.series.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.settings (
    key character varying(100) NOT NULL,
    value text,
    company_id integer NOT NULL
);


ALTER TABLE public.settings OWNER TO posuser;

--
-- Name: stock_session_lines; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.stock_session_lines (
    id integer NOT NULL,
    session_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(255) NOT NULL,
    qty_before numeric(14,4) DEFAULT 0 NOT NULL,
    qty_adjusted numeric(14,4) NOT NULL,
    qty_after numeric(14,4) NOT NULL,
    type character varying(10) NOT NULL,
    reason character varying(60),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_session_lines OWNER TO posuser;

--
-- Name: stock_session_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.stock_session_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_session_lines_id_seq OWNER TO posuser;

--
-- Name: stock_session_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.stock_session_lines_id_seq OWNED BY public.stock_session_lines.id;


--
-- Name: stock_sessions; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.stock_sessions (
    id integer NOT NULL,
    warehouse_id integer NOT NULL,
    employee_id integer,
    company_id integer,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_sessions OWNER TO posuser;

--
-- Name: stock_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.stock_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_sessions_id_seq OWNER TO posuser;

--
-- Name: stock_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.stock_sessions_id_seq OWNED BY public.stock_sessions.id;


--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.stock_transfer_items (
    id integer NOT NULL,
    transfer_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200) NOT NULL,
    unit character varying(20),
    qty_sent numeric(14,4) NOT NULL,
    qty_received numeric(14,4),
    diff_reason character varying(120),
    diff_resolution character varying(20),
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    unit_cost numeric(14,4)
);


ALTER TABLE public.stock_transfer_items OWNER TO posuser;

--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.stock_transfer_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_transfer_items_id_seq OWNER TO posuser;

--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.stock_transfer_items_id_seq OWNED BY public.stock_transfer_items.id;


--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.stock_transfers (
    id integer NOT NULL,
    from_warehouse_id integer,
    to_warehouse_id integer NOT NULL,
    product_id integer,
    product_name character varying(200),
    qty numeric(10,3),
    note text,
    employee_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    code character varying(30),
    status character varying(32) DEFAULT 'sent'::character varying NOT NULL,
    difference_status character varying(16) DEFAULT 'none'::character varying NOT NULL,
    dispatched_at timestamp with time zone,
    received_by integer,
    received_at timestamp with time zone,
    receipt_note text,
    cancelled_by integer,
    cancelled_at timestamp with time zone,
    cancel_reason text,
    CONSTRAINT stock_transfers_qty_check CHECK ((qty > (0)::numeric))
);


ALTER TABLE public.stock_transfers OWNER TO posuser;

--
-- Name: stock_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.stock_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_transfers_id_seq OWNER TO posuser;

--
-- Name: stock_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.stock_transfers_id_seq OWNED BY public.stock_transfers.id;


--
-- Name: user_series; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.user_series (
    user_id integer NOT NULL,
    serie_id integer NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.user_series OWNER TO posuser;

--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    sells boolean DEFAULT true NOT NULL,
    parent_warehouse_id integer
);


ALTER TABLE public.warehouses OWNER TO posuser;

--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouses_id_seq OWNER TO posuser;

--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: banks id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.banks ALTER COLUMN id SET DEFAULT nextval('public.banks_id_seq'::regclass);


--
-- Name: cash_session_journals id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals ALTER COLUMN id SET DEFAULT nextval('public.cash_session_journals_id_seq'::regclass);


--
-- Name: cash_sessions id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions ALTER COLUMN id SET DEFAULT nextval('public.cash_sessions_id_seq'::regclass);


--
-- Name: catalog_banners id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.catalog_banners ALTER COLUMN id SET DEFAULT nextval('public.catalog_banners_id_seq'::regclass);


--
-- Name: catalog_benefit_tags id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.catalog_benefit_tags ALTER COLUMN id SET DEFAULT nextval('public.catalog_benefit_tags_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: currencies id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.currencies ALTER COLUMN id SET DEFAULT nextval('public.currencies_id_seq'::regclass);


--
-- Name: customer_credit_movements id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customer_credit_movements ALTER COLUMN id SET DEFAULT nextval('public.customer_credit_movements_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: income_categories id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.income_categories ALTER COLUMN id SET DEFAULT nextval('public.income_categories_id_seq'::regclass);


--
-- Name: incomes id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes ALTER COLUMN id SET DEFAULT nextval('public.incomes_id_seq'::regclass);


--
-- Name: payment_journals id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals ALTER COLUMN id SET DEFAULT nextval('public.payment_journals_id_seq'::regclass);


--
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: product_combo_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items ALTER COLUMN id SET DEFAULT nextval('public.product_combo_items_id_seq'::regclass);


--
-- Name: product_lots id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots ALTER COLUMN id SET DEFAULT nextval('public.product_lots_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: promotions id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotions ALTER COLUMN id SET DEFAULT nextval('public.promotions_id_seq'::regclass);


--
-- Name: purchase_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_items_id_seq'::regclass);


--
-- Name: purchase_payments id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments ALTER COLUMN id SET DEFAULT nextval('public.purchase_payments_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: return_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items ALTER COLUMN id SET DEFAULT nextval('public.return_items_id_seq'::regclass);


--
-- Name: returns id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns ALTER COLUMN id SET DEFAULT nextval('public.returns_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sale_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items ALTER COLUMN id SET DEFAULT nextval('public.sale_items_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- Name: serie_ranges id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.serie_ranges ALTER COLUMN id SET DEFAULT nextval('public.serie_ranges_id_seq'::regclass);


--
-- Name: series id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series ALTER COLUMN id SET DEFAULT nextval('public.series_id_seq'::regclass);


--
-- Name: stock_session_lines id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_session_lines ALTER COLUMN id SET DEFAULT nextval('public.stock_session_lines_id_seq'::regclass);


--
-- Name: stock_sessions id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions ALTER COLUMN id SET DEFAULT nextval('public.stock_sessions_id_seq'::regclass);


--
-- Name: stock_transfer_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfer_items ALTER COLUMN id SET DEFAULT nextval('public.stock_transfer_items_id_seq'::regclass);


--
-- Name: stock_transfers id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers ALTER COLUMN id SET DEFAULT nextval('public.stock_transfers_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public."SequelizeMeta" (name) FROM stdin;
20260320000000-initial-schema.js
20260320000001-add-is-service-to-products.js
20260320232210-add-combo-support.js
20260324000001-create-cash-sessions.js
20260324000002-update-cash-sessions.js
20260324152000-remove-icon-from-payment-methods.js
20260413000000-add-sale-item-id-to-returns.js
20260413000001-allow-negative-payments.js
20260413100000-add-change-to-payments.js
20260413110000-add-color-to-categories.js
20260413120000-add-lot-fields-to-purchase-items.js
20260413120001-create-product-lots.js
20260414000000-create-expenses.js
20260414200000-create-purchase-payments.js
20260414210000-normalize-inventory-units.js
20260414220000-add-barcode-to-products.js
20260415121000-multi-company-setup.js
20260415133000-add-subscription-fields.js
20260415185900-complete-tenant-isolation-patch.js
20260415190820-isolate-currencies.js
20260415192205-remove-global-unique-constraints.js
20260415193302-final-multi-tenant-hardening.js
20260415200000-settings-composite-pk.js
20260421000000-granular-role-permissions.js
20260515000000-create-quotations.js
20260515001000-add-type-to-series-nc-number-to-returns.js
20260515002000-create-promotions.js
20260518000000-add-status-to-purchases.js
20260522000000-base-currency-symbol-ref.js
20260522010000-add-idempotency-key-to-sales.js
20260525000001-create-incomes.js
20260525100000-fix-change-given-precision.js
20260525200000-fix-amount-precision.js
20260527100000-fix-payments-amount-precision.js
20260529100000-add-credit-balance-to-customers.js
20260529200000-create-stock-sessions.js
20260609000000-add-date-to-incomes-expenses.js
20260609000001-increase-product-price-precision.js
20260609000002-add-credit-applied-to-sales.js
20260610000000-increase-price-to-5-decimals.js
20260610100000-add-update-price-to-purchase-items.js
20260612000000-add-bulk-price-to-products.js
20260617000000-increase-purchase-items-price-precision.js
20260723000000-increase-sale-items-price-precision.js
20260803000000-add-cost-price-to-sale-items.js
20260805000000-add-visible-in-catalog-to-products.js
20260805010000-add-web-order-fields-to-sales.js
20260806000000-add-held-by-to-sales.js
20260810120000-add-exchange-rate-to-purchases.js
20260810180000-fix-income-categories-tenant.js
20260819170000-payment-idempotency-and-invoice-unique.js
20260819180000-add-warehouse-to-series.js
20260819190000-add-warehouse-to-incomes-expenses.js
20260820120000-add-warehouse-to-payment-journals.js
20260820160000-expand-role-permissions.js
20260820180000-add-sells-to-warehouses.js
20260820190000-add-parent-warehouse.js
20260820200000-add-nc-serie-id.js
20260821100000-add-status-to-returns.js
20260821140000-add-sellable-to-products.js
20260821160000-add-service-charge-to-sales.js
20260821180000-catalog-slug.js
20260821200000-transfer-receipt-flow.js
20260824100000-add-forgiveness-to-sales.js
20260824140000-add-batch-id-to-payments.js
20260824150000-backfill-batch-id.js
20260824170000-backfill-movement-date.js
20260825120000-returns-money-precision.js
20260825140000-incomes-created-at-tz.js
20260828120000-seed-categories-per-company.js
20260828140000-warehouse-price-and-min-stock.js
20260828150000-promotions-per-warehouse.js
20260828160000-warehouse-cost-price.js
20260829090000-normalize-legacy-role-permissions.js
20260902100000-catalog-category-image.js
20260902110000-create-catalog-banners.js
20260903100000-product-storefront-fields.js
20260903150000-product-detail-fields.js
20260903160000-catalog-benefit-tags.js
20260904100000-category-short-description.js
20260904150000-sale-item-note.js
20260905100000-company-catalog-enabled.js
20260905110000-add-allows-outflow-to-payment-methods.js
20260905120000-add-requested-warehouse-to-sales.js
20260905130000-create-customer-credit-movements.js
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.audit_logs (id, employee_id, employee_name, method, path, ip, status_code, created_at, company_id) FROM stdin;
1	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-18 13:54:55.257299+00	1
2	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:03:25.881254+00	1
3	1	Administrador	POST	/	172.19.0.1	200	2026-05-18 14:04:00.280446+00	1
4	1	Administrador	POST	/1/ranges	172.19.0.1	200	2026-05-18 14:04:11.988467+00	1
5	1	Administrador	PUT	/1/users	172.19.0.1	200	2026-05-18 14:04:13.597112+00	1
6	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-05-18 14:04:41.823668+00	1
7	1	Administrador	POST	/open	172.19.0.1	201	2026-05-18 14:04:48.580101+00	1
8	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:07:13.075429+00	1
9	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-18 14:07:31.087931+00	1
10	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:07:55.212085+00	1
11	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:10:30.255092+00	1
12	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:12:54.885601+00	1
13	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:15:25.200824+00	1
14	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:15:45.487805+00	1
15	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:15:55.188241+00	1
16	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:16:03.502485+00	1
17	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:19:29.56238+00	1
18	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-18 14:23:45.665968+00	1
19	1	Administrador	POST	/3/return	172.19.0.1	201	2026-05-18 14:25:07.045152+00	1
20	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:14.717063+00	1
21	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:16.00161+00	1
22	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:16.524302+00	1
23	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:16.861508+00	1
24	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:22.876449+00	1
25	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:37.416348+00	1
26	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:51.908275+00	1
27	1	Administrador	PUT	/1/stock/1	172.19.0.1	200	2026-05-18 14:32:17.223337+00	1
28	1	Administrador	DELETE	/1/stock/1	172.19.0.1	200	2026-05-18 14:32:19.973211+00	1
29	1	Administrador	DELETE	/1/stock/2	172.19.0.1	200	2026-05-18 14:32:21.885511+00	1
30	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:34:01.487172+00	1
31	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:34:51.236336+00	1
32	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:35:18.606544+00	1
33	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-05-18 14:35:34.776213+00	1
34	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:36:56.236861+00	1
35	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:36:56.714347+00	1
36	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:37:48.112321+00	1
37	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-18 14:38:07.461369+00	1
38	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:38:18.316154+00	1
39	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:44:36.842599+00	1
40	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:44:47.674506+00	1
41	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-18 14:45:03.763463+00	1
42	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-18 14:45:05.967366+00	1
43	1	Administrador	POST	/2/payments	172.19.0.1	201	2026-05-18 14:45:24.227151+00	1
44	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:51:19.212738+00	1
45	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-18 14:51:34.038832+00	1
46	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:51:57.323059+00	1
47	1	Administrador	DELETE	/1	172.19.0.1	200	2026-05-18 17:32:58.778214+00	1
48	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 17:57:38.588233+00	1
49	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 18:30:32.272326+00	1
50	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 18:30:54.151086+00	1
51	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 18:31:10.977052+00	1
52	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 18:31:21.178611+00	1
53	1	Administrador	POST	/1/stock	172.19.0.1	200	2026-05-18 18:32:05.600283+00	1
54	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 19:19:48.045492+00	1
55	1	Administrador	POST	/	172.19.0.1	200	2026-05-18 19:27:39.556044+00	1
56	1	Administrador	POST	/2/ranges	172.19.0.1	200	2026-05-18 19:27:48.585233+00	1
57	1	Administrador	PUT	/2/users	172.19.0.1	200	2026-05-18 19:27:48.94232+00	1
58	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 19:59:18.150611+00	1
59	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 20:49:16.095007+00	1
60	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-18 20:49:45.582315+00	1
61	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 13:50:03.149082+00	1
62	1	Administrador	PATCH	/5/confirm	172.19.0.1	200	2026-05-19 13:53:34.022833+00	1
63	1	Administrador	DELETE	/5	172.19.0.1	200	2026-05-19 14:01:46.385857+00	1
64	1	Administrador	DELETE	/3	172.19.0.1	500	2026-05-19 14:01:48.616525+00	1
65	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:02:42.900737+00	1
66	1	Administrador	PATCH	/6	172.19.0.1	200	2026-05-19 14:24:26.260131+00	1
67	1	Administrador	PATCH	/6/confirm	172.19.0.1	200	2026-05-19 14:24:33.748718+00	1
68	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-19 14:24:49.76147+00	1
69	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:26:45.164822+00	1
70	1	Administrador	PATCH	/7	172.19.0.1	200	2026-05-19 14:27:18.662645+00	1
71	1	Administrador	PATCH	/7	172.19.0.1	200	2026-05-19 14:36:49.599516+00	1
72	1	Administrador	PATCH	/7/receive	172.19.0.1	500	2026-05-19 14:36:52.958367+00	1
73	1	Administrador	PATCH	/7/receive	172.19.0.1	500	2026-05-19 14:36:54.498893+00	1
74	1	Administrador	PATCH	/7	172.19.0.1	200	2026-05-19 14:36:57.323723+00	1
75	1	Administrador	PATCH	/7/receive	172.19.0.1	200	2026-05-19 14:36:58.971013+00	1
76	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-19 14:43:58.800764+00	1
77	1	Administrador	DELETE	/3	172.19.0.1	500	2026-05-19 14:44:00.418958+00	1
78	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:44:15.109971+00	1
79	1	Administrador	PATCH	/8/confirm	172.19.0.1	200	2026-05-19 14:46:04.528232+00	1
80	1	Administrador	DELETE	/8	172.19.0.1	200	2026-05-19 14:46:13.453394+00	1
81	1	Administrador	DELETE	/3	172.19.0.1	500	2026-05-19 14:55:38.494205+00	1
82	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:56:11.942332+00	1
83	1	Administrador	PATCH	/9	172.19.0.1	200	2026-05-19 14:56:59.856803+00	1
84	1	Administrador	PATCH	/9/confirm	172.19.0.1	200	2026-05-19 14:57:01.611924+00	1
85	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-19 15:01:21.073002+00	1
86	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:01:34.978803+00	1
87	1	Administrador	PATCH	/10	172.19.0.1	200	2026-05-19 15:01:42.174527+00	1
88	1	Administrador	PATCH	/10	172.19.0.1	200	2026-05-19 15:01:50.036692+00	1
89	1	Administrador	PATCH	/10/receive	172.19.0.1	500	2026-05-19 15:08:15.100061+00	1
90	1	Administrador	PATCH	/10	172.19.0.1	200	2026-05-19 15:08:22.27886+00	1
91	1	Administrador	PATCH	/10/receive	172.19.0.1	200	2026-05-19 15:08:23.185153+00	1
92	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-19 15:08:40.630343+00	1
93	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:08:51.220962+00	1
94	1	Administrador	PATCH	/11	172.19.0.1	200	2026-05-19 15:25:19.482369+00	1
95	1	Administrador	PATCH	/11/receive	172.19.0.1	200	2026-05-19 15:25:56.895343+00	1
96	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-19 15:26:13.158487+00	1
97	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:26:24.989615+00	1
98	1	Administrador	PATCH	/12	172.19.0.1	200	2026-05-19 15:28:30.563548+00	1
99	1	Administrador	PATCH	/12/confirm	172.19.0.1	200	2026-05-19 15:32:45.609549+00	1
100	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-19 15:34:02.786622+00	1
101	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:34:21.950862+00	1
102	1	Administrador	PATCH	/13/confirm	172.19.0.1	200	2026-05-19 15:37:01.310713+00	1
103	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-19 15:37:45.270143+00	1
104	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:41:46.136508+00	1
105	1	Administrador	PATCH	/14/confirm	172.19.0.1	200	2026-05-19 15:42:07.530566+00	1
106	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:10.708055+00	1
107	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:12.858611+00	1
108	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:13.354506+00	1
109	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:13.647962+00	1
110	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:13.814022+00	1
111	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:19.763878+00	1
112	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:20.811417+00	1
113	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:23.010361+00	1
114	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:24.110046+00	1
115	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:30.019865+00	1
116	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:30.839113+00	1
117	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:31.388739+00	1
118	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:34.231748+00	1
119	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:42.489807+00	1
120	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:50.391975+00	1
121	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:51.182208+00	1
122	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:52.358765+00	1
123	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:52.881793+00	1
124	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:50:57.431801+00	1
125	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:50:58.90984+00	1
126	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:55:24.741523+00	1
127	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:55:26.96366+00	1
128	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:34.74044+00	1
129	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:35.828599+00	1
130	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:56:35.873303+00	1
131	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.049181+00	1
132	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.486263+00	1
133	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.680855+00	1
134	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.867333+00	1
135	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:38.055166+00	1
136	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:38.182627+00	1
137	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:38.324183+00	1
138	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:39.03885+00	1
139	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:51.977498+00	1
140	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:52.807694+00	1
141	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-19 15:57:00.461294+00	1
142	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:57:30.720699+00	1
143	1	Administrador	PATCH	/15/confirm	172.19.0.1	200	2026-05-19 15:57:47.274903+00	1
144	1	Administrador	PATCH	/15	172.19.0.1	400	2026-05-19 15:58:01.853767+00	1
145	1	Administrador	PATCH	/15	172.19.0.1	200	2026-05-19 16:05:46.506554+00	1
146	1	Administrador	PATCH	/15/receive	172.19.0.1	200	2026-05-19 16:05:47.547064+00	1
147	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-19 16:06:05.737257+00	1
148	1	Administrador	DELETE	/1/stock/5	172.19.0.1	200	2026-05-19 16:06:22.514503+00	1
149	1	Administrador	DELETE	/1/stock/4	172.19.0.1	200	2026-05-19 16:06:24.443424+00	1
150	1	Administrador	DELETE	/1/stock/2	172.19.0.1	200	2026-05-19 16:06:26.549321+00	1
151	1	Administrador	DELETE	/1/stock/6	172.19.0.1	200	2026-05-19 16:06:31.187154+00	1
152	1	Administrador	DELETE	/4	172.19.0.1	400	2026-05-19 16:06:36.558377+00	1
153	1	Administrador	DELETE	/5	172.19.0.1	200	2026-05-19 16:06:40.219366+00	1
154	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-19 16:06:43.139288+00	1
155	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 16:07:07.239165+00	1
156	1	Administrador	PATCH	/16/confirm	172.19.0.1	200	2026-05-19 16:07:32.908062+00	1
157	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-19 16:22:39.973301+00	1
158	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 16:23:23.933496+00	1
159	1	Administrador	PATCH	/17	172.19.0.1	200	2026-05-19 16:23:38.985832+00	1
160	1	Administrador	PATCH	/17	172.19.0.1	200	2026-05-19 16:25:05.764791+00	1
161	1	Administrador	PATCH	/17/confirm	172.19.0.1	200	2026-05-19 16:25:44.817502+00	1
162	1	Administrador	PATCH	/17/receive	172.19.0.1	200	2026-05-19 16:25:47.260177+00	1
163	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-19 16:25:51.600944+00	1
164	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 16:25:58.984022+00	1
165	1	Administrador	PATCH	/18	172.19.0.1	200	2026-05-19 16:29:05.703838+00	1
166	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-19 16:29:15.047722+00	1
167	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-19 16:29:36.398415+00	1
168	1	Administrador	PUT	/2	172.19.0.1	200	2026-05-19 16:29:46.073368+00	1
169	1	Administrador	PUT	/4	172.19.0.1	200	2026-05-19 16:29:53.20003+00	1
170	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-19 16:30:01.222485+00	1
171	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-19 16:30:07.008578+00	1
172	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-19 16:30:18.819881+00	1
173	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-22 14:37:29.867978+00	1
174	1	Administrador	PATCH	/18/confirm	172.19.0.1	200	2026-05-22 14:45:11.435331+00	1
175	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-22 16:09:21.317512+00	1
176	1	Administrador	PUT	/	172.19.0.1	200	2026-05-22 16:28:00.128102+00	1
177	1	Administrador	POST	/1/close	172.19.0.1	200	2026-05-22 20:41:48.373474+00	1
178	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:20:30.667678+00	1
179	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:20:34.924918+00	1
180	1	Administrador	POST	/1/stock	172.19.0.1	200	2026-05-25 15:21:26.494376+00	1
181	1	Administrador	POST	/1/stock	172.19.0.1	200	2026-05-25 15:21:36.429875+00	1
182	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:27:30.876429+00	1
183	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:27:41.838462+00	1
184	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 15:28:08.70944+00	1
185	1	Administrador	PUT	/roles/3	172.19.0.1	200	2026-05-25 15:28:55.432391+00	1
186	1	Administrador	PUT	/roles/3	172.19.0.1	200	2026-05-25 15:29:20.803774+00	1
187	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 15:55:10.10645+00	1
188	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 15:55:44.698557+00	1
189	1	Administrador	POST	/open	172.19.0.1	201	2026-05-25 15:56:01.051686+00	1
190	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 15:56:18.849205+00	1
191	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:02:51.312914+00	1
192	1	Administrador	DELETE	/8	172.19.0.1	200	2026-05-25 16:04:07.359389+00	1
193	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:07:27.020866+00	1
194	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-25 16:16:39.47075+00	1
195	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:16:56.33006+00	1
196	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-25 16:18:00.165285+00	1
197	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-25 16:18:02.346566+00	1
198	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-25 16:18:22.18391+00	1
199	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:21:35.813313+00	1
200	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:25:51.430541+00	1
201	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:26:15.154198+00	1
202	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-25 16:27:48.083332+00	1
203	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-25 16:27:53.131681+00	1
204	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:28:03.85392+00	1
205	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-25 16:28:49.415085+00	1
206	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-25 16:28:52.311811+00	1
207	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-25 16:28:56.450765+00	1
208	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:27:24.25644+00	1
209	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-25 17:28:04.843157+00	1
210	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:28:44.394003+00	1
211	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:29:04.190679+00	1
212	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-25 17:36:59.600007+00	1
213	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:37:10.493974+00	1
214	1	Administrador	POST	/2/close	172.19.0.1	200	2026-05-25 17:38:21.855849+00	1
215	1	Administrador	POST	/open	172.19.0.1	201	2026-05-25 17:45:06.312496+00	1
216	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:45:22.878053+00	1
217	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:45:36.548004+00	1
218	1	Administrador	POST	/3/close	172.19.0.1	200	2026-05-25 17:47:20.106389+00	1
219	1	Administrador	DELETE	/3	172.19.0.1	200	2026-05-25 18:12:18.513451+00	1
220	1	Administrador	DELETE	/18	172.19.0.1	200	2026-05-25 18:15:58.562884+00	1
221	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-25 18:16:00.354223+00	1
222	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-25 18:16:02.230116+00	1
223	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-25 18:16:07.391934+00	1
224	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-25 18:16:09.222792+00	1
225	1	Administrador	DELETE	/8	172.19.0.1	200	2026-05-25 18:28:04.594812+00	1
226	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-25 18:28:06.708084+00	1
227	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-25 18:28:09.887298+00	1
228	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-25 18:28:11.665187+00	1
229	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-25 18:28:21.435319+00	1
230	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-25 18:28:23.415541+00	1
231	1	Administrador	DELETE	/5	172.19.0.1	200	2026-05-25 18:28:25.339632+00	1
232	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-25 18:28:27.094249+00	1
233	1	Administrador	DELETE	/2	172.19.0.1	200	2026-05-25 18:28:29.004577+00	1
234	1	Administrador	DELETE	/1	172.19.0.1	400	2026-05-25 18:28:32.013732+00	1
235	1	Administrador	DELETE	/1	172.19.0.1	400	2026-05-25 18:28:33.284436+00	1
236	1	Administrador	DELETE	/1	172.19.0.1	400	2026-05-25 18:28:55.373293+00	1
237	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-25 18:31:52.938654+00	1
238	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-25 18:32:00.935159+00	1
239	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-25 18:32:02.525282+00	1
240	1	Administrador	PUT	/1/stock/1	172.19.0.1	200	2026-05-25 18:33:56.215786+00	1
241	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-25 18:34:02.27712+00	1
242	1	Administrador	DELETE	/2	172.19.0.1	200	2026-05-25 18:34:04.084728+00	1
243	1	Administrador	PATCH	/18	172.19.0.1	200	2026-05-25 18:36:26.115982+00	1
244	1	Administrador	PATCH	/18	172.19.0.1	200	2026-05-25 18:37:13.354751+00	1
245	1	Administrador	PATCH	/18/receive	172.19.0.1	200	2026-05-25 18:38:28.857097+00	1
246	1	Administrador	POST	/open	172.19.0.1	201	2026-05-25 18:39:23.708067+00	1
247	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:39:47.757985+00	1
248	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:40:19.628434+00	1
249	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-25 18:41:25.051814+00	1
250	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-25 18:41:31.070165+00	1
251	1	Administrador	DELETE	/19	172.19.0.1	400	2026-05-25 18:41:38.119511+00	1
252	1	Administrador	DELETE	/19	172.19.0.1	400	2026-05-25 18:41:38.742843+00	1
253	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:43:05.554529+00	1
254	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:43:59.390637+00	1
255	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:44:32.692849+00	1
256	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:44:53.090457+00	1
257	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-25 18:48:15.911692+00	1
258	1	Administrador	DELETE	/22	172.19.0.1	200	2026-05-25 18:48:26.921825+00	1
259	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:48:43.965841+00	1
260	1	Administrador	DELETE	/18	172.19.0.1	200	2026-05-25 18:49:04.378969+00	1
261	1	Administrador	DELETE	/23	172.19.0.1	200	2026-05-25 18:49:08.105695+00	1
262	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:49:24.99794+00	1
263	1	Administrador	POST	/4/close	172.19.0.1	200	2026-05-25 18:57:23.432246+00	1
264	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:49.767524+00	1
265	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:50.516938+00	1
266	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:51.175831+00	1
267	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:52.43564+00	1
268	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-05-25 19:06:53.435378+00	1
269	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-05-25 19:06:58.077236+00	1
270	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:59.484146+00	1
271	1	Administrador	DELETE	/18/permanent	172.19.0.1	200	2026-05-25 19:16:31.149128+00	1
272	1	Administrador	DELETE	/17/permanent	172.19.0.1	200	2026-05-25 19:16:33.270504+00	1
273	1	Administrador	PUT	/2	172.19.0.1	200	2026-05-25 19:18:28.503433+00	1
274	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-25 19:19:50.60373+00	1
275	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-25 19:20:28.02517+00	1
276	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-25 19:23:46.391886+00	1
277	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:24:12.181863+00	1
278	1	Administrador	DELETE	/20	172.19.0.1	200	2026-05-25 19:24:26.382536+00	1
279	1	Administrador	DELETE	/20/permanent	172.19.0.1	200	2026-05-25 19:24:28.399012+00	1
280	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-25 19:41:17.319273+00	1
281	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:41:42.647379+00	1
282	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-25 19:45:05.309564+00	1
283	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-25 19:48:57.397475+00	1
284	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:49:05.500091+00	1
285	1	Administrador	DELETE	/18	172.19.0.1	200	2026-05-25 19:51:03.832863+00	1
286	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:52:07.5685+00	1
287	1	Administrador	DELETE	/19	172.19.0.1	200	2026-05-25 19:56:59.361525+00	1
288	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:57:05.200553+00	1
289	1	Administrador	DELETE	/20	172.19.0.1	200	2026-05-25 20:01:17.427905+00	1
290	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:01:23.274934+00	1
291	1	Administrador	DELETE	/21	172.19.0.1	200	2026-05-25 20:05:17.258605+00	1
292	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:05:34.866975+00	1
293	1	Administrador	DELETE	/22	172.19.0.1	200	2026-05-25 20:08:41.813928+00	1
294	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:08:55.504313+00	1
295	1	Administrador	DELETE	/23	172.19.0.1	200	2026-05-25 20:08:58.917575+00	1
296	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:09:28.146638+00	1
297	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:09:56.107558+00	1
298	1	Administrador	DELETE	/25	172.19.0.1	200	2026-05-25 20:10:05.750474+00	1
299	1	Administrador	DELETE	/24	172.19.0.1	200	2026-05-25 20:10:09.308068+00	1
300	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:11:25.234254+00	1
301	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:11:31.785008+00	1
302	1	Administrador	DELETE	/27	172.19.0.1	200	2026-05-25 20:11:35.164446+00	1
303	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:13:12.727215+00	1
304	1	Administrador	DELETE	/28	172.19.0.1	200	2026-05-25 20:14:11.867939+00	1
305	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:14:39.295745+00	1
306	1	Administrador	DELETE	/29	172.19.0.1	200	2026-05-25 20:15:20.295054+00	1
307	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:15:42.140208+00	1
308	1	Administrador	DELETE	/30	172.19.0.1	200	2026-05-25 20:15:51.209639+00	1
309	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:18:05.828528+00	1
310	1	Administrador	DELETE	/26	172.19.0.1	200	2026-05-27 14:45:59.041477+00	1
311	1	Administrador	DELETE	/31	172.19.0.1	200	2026-05-27 14:46:01.063561+00	1
312	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-27 14:46:11.855414+00	1
313	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-27 14:46:20.921098+00	1
314	1	Administrador	POST	/12/return	172.19.0.1	201	2026-05-29 13:30:33.563122+00	1
315	1	Administrador	DELETE	/21	172.19.0.1	200	2026-05-29 13:32:43.21032+00	1
316	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:46:35.196484+00	1
317	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:46:40.370192+00	1
318	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:47:46.74739+00	1
319	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:47:52.150433+00	1
320	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:47:58.53105+00	1
321	1	Administrador	POST	/12/exchange	172.19.0.1	201	2026-05-29 13:49:35.264614+00	1
322	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:10:59.475035+00	1
323	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-29 15:12:58.401164+00	1
324	1	Administrador	DELETE	/25	172.19.0.1	400	2026-05-29 15:13:09.001749+00	1
325	1	Administrador	DELETE	/25	172.19.0.1	400	2026-05-29 15:13:09.797766+00	1
326	1	Administrador	POST	/12/return	172.19.0.1	201	2026-05-29 15:17:43.711239+00	1
327	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-05-29 15:17:59.12587+00	1
328	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:28:45.547844+00	1
329	1	Administrador	PATCH	/19/confirm	172.19.0.1	200	2026-05-29 15:28:58.381635+00	1
330	1	Administrador	PATCH	/19	172.19.0.1	200	2026-05-29 15:31:17.190213+00	1
331	1	Administrador	PATCH	/19	172.19.0.1	200	2026-05-29 15:31:23.761545+00	1
332	1	Administrador	PATCH	/19/receive	172.19.0.1	200	2026-05-29 15:31:24.84333+00	1
333	1	Administrador	DELETE	/19	172.19.0.1	200	2026-05-29 15:32:48.205595+00	1
334	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:35:53.122104+00	1
335	1	Administrador	PATCH	/20/receive	172.19.0.1	500	2026-05-29 15:35:58.847538+00	1
336	1	Administrador	PATCH	/20/receive	172.19.0.1	500	2026-05-29 15:36:04.949342+00	1
337	1	Administrador	PATCH	/20	172.19.0.1	200	2026-05-29 15:36:07.60089+00	1
338	1	Administrador	PATCH	/20/receive	172.19.0.1	200	2026-05-29 15:36:08.347153+00	1
339	1	Administrador	DELETE	/20	172.19.0.1	200	2026-05-29 15:36:17.106005+00	1
340	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:42:50.881294+00	1
341	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:42:57.872686+00	1
342	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:43:08.408423+00	1
343	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:43:41.977073+00	1
344	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:43:58.553934+00	1
345	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:45:22.350885+00	1
346	1	Administrador	PATCH	/21/confirm	172.19.0.1	200	2026-05-29 15:45:32.642381+00	1
347	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:47:14.712757+00	1
348	1	Administrador	PATCH	/21	172.19.0.1	200	2026-05-29 15:47:59.786874+00	1
349	1	Administrador	PATCH	/21	172.19.0.1	200	2026-05-29 15:52:04.754837+00	1
350	1	Administrador	PATCH	/21	172.19.0.1	200	2026-05-29 15:52:11.292069+00	1
351	1	Administrador	PATCH	/21/receive	172.19.0.1	200	2026-05-29 15:52:11.855445+00	1
352	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-05-29 16:20:17.483435+00	1
353	1	Administrador	POST	/1/sessions/1/lines	172.19.0.1	500	2026-05-29 16:20:17.541583+00	1
354	1	Administrador	POST	/1/sessions/1/lines	172.19.0.1	500	2026-05-29 16:20:25.754325+00	1
355	1	Administrador	POST	/1/sessions/1/lines	172.19.0.1	201	2026-05-29 16:24:52.319351+00	1
356	1	Administrador	PATCH	/1/sessions/1/close	172.19.0.1	200	2026-05-29 16:25:04.275087+00	1
357	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-05-29 16:25:22.960267+00	1
358	1	Administrador	PATCH	/1/sessions/2/close	172.19.0.1	200	2026-05-29 16:25:24.569651+00	1
359	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 17:01:58.475049+00	1
360	1	Administrador	POST	/open	172.19.0.1	201	2026-05-29 18:18:54.637398+00	1
361	1	Administrador	POST	/	172.19.0.1	500	2026-05-29 18:20:05.928226+00	1
362	1	Administrador	POST	/	172.19.0.1	500	2026-05-29 18:20:12.717894+00	1
363	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:23:21.454167+00	1
364	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:24:13.824204+00	1
365	1	Administrador	DELETE	/30	172.19.0.1	200	2026-05-29 18:28:16.24941+00	1
366	1	Administrador	DELETE	/29	172.19.0.1	200	2026-05-29 18:28:18.1956+00	1
367	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:28:35.340023+00	1
368	1	Administrador	DELETE	/32	172.19.0.1	200	2026-05-29 18:29:12.83969+00	1
369	1	Administrador	DELETE	/31	172.19.0.1	200	2026-05-29 18:29:14.959343+00	1
370	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:33:22.771259+00	1
371	1	Administrador	DELETE	/34	172.19.0.1	200	2026-05-29 18:33:29.955857+00	1
372	1	Administrador	DELETE	/33	172.19.0.1	200	2026-05-29 18:33:32.812363+00	1
373	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:33:47.434073+00	1
374	1	Administrador	DELETE	/36	172.19.0.1	200	2026-05-29 18:33:53.103231+00	1
375	1	Administrador	DELETE	/35	172.19.0.1	200	2026-05-29 18:33:54.683992+00	1
376	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:34:16.985007+00	1
377	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-29 18:42:55.734641+00	1
378	1	Administrador	DELETE	/37	172.19.0.1	200	2026-05-29 18:52:53.369269+00	1
379	1	Administrador	DELETE	/27	172.19.0.1	200	2026-05-29 18:52:55.19172+00	1
380	1	Administrador	DELETE	/24	172.19.0.1	200	2026-05-29 18:52:58.259332+00	1
381	1	Administrador	DELETE	/25	172.19.0.1	400	2026-05-29 18:53:00.348322+00	1
382	1	Administrador	POST	/trigger	172.19.0.1	200	2026-05-29 19:22:02.678134+00	1
383	1	Administrador	POST	/trigger	172.19.0.1	200	2026-05-29 19:22:55.986623+00	1
384	1	Administrador	PUT	/1/stock/10	172.19.0.1	200	2026-06-01 13:29:36.037187+00	1
385	1	Administrador	PUT	/1/stock/10	172.19.0.1	200	2026-06-01 13:29:46.755005+00	1
386	1	Administrador	PUT	/1/stock/1	172.19.0.1	200	2026-06-01 13:29:55.386979+00	1
387	1	Administrador	PUT	/	172.19.0.1	200	2026-06-05 13:14:19.535854+00	1
388	1	Administrador	PUT	/	172.19.0.1	200	2026-06-05 13:14:23.758935+00	1
389	1	Administrador	PUT	/	172.19.0.1	200	2026-06-05 13:25:02.584068+00	1
390	1	Administrador	POST	/	172.19.0.1	201	2026-06-05 14:23:23.922982+00	1
391	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 18:53:13.25965+00	1
392	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 18:53:24.747271+00	1
393	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 18:53:34.770257+00	1
394	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 18:59:42.885944+00	1
395	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 18:59:58.571126+00	1
396	1	Administrador	PUT	/2	172.19.0.1	200	2026-06-09 19:02:19.448594+00	1
397	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-06-09 19:02:26.243128+00	1
398	1	Administrador	PUT	/1	172.19.0.1	200	2026-06-09 19:10:44.433182+00	1
399	1	Administrador	PUT	/2	172.19.0.1	200	2026-06-09 19:10:51.958653+00	1
400	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 19:18:52.438625+00	1
401	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 19:19:00.335728+00	1
402	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 19:35:39.352241+00	1
403	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 19:35:51.73043+00	1
404	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 19:54:32.909484+00	1
405	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 20:05:08.412331+00	1
406	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-09 20:05:15.379959+00	1
407	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:06:36.584552+00	1
408	1	Administrador	PUT	/12	172.19.0.1	200	2026-06-09 20:07:15.434378+00	1
409	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:07:33.748957+00	1
410	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:07:36.534993+00	1
411	1	Administrador	PUT	/2/toggle	172.19.0.1	200	2026-06-09 20:08:11.129713+00	1
412	1	Administrador	PUT	/2/toggle	172.19.0.1	200	2026-06-09 20:08:27.011587+00	1
413	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:08:33.805522+00	1
414	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:08:39.162854+00	1
415	1	Administrador	DELETE	/posdb_20260608_124945.sql.gz	172.19.0.1	200	2026-06-09 20:09:04.17653+00	1
416	1	Administrador	DELETE	/posdb_20260603_193706.sql.gz	172.19.0.1	200	2026-06-09 20:09:05.051074+00	1
417	1	Administrador	DELETE	/posdb_20260601_132039.sql.gz	172.19.0.1	200	2026-06-09 20:09:05.582947+00	1
418	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:10:26.087538+00	1
419	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:10:29.949418+00	1
420	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:10:31.165163+00	1
421	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:10:32.479278+00	1
422	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:10:36.011191+00	1
423	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:10:39.804161+00	1
424	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:10:50.834016+00	1
425	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:13:25.016678+00	1
426	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:13:30.380145+00	1
427	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:13:34.526941+00	1
430	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:13:47.219987+00	1
428	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-09 20:13:35.751146+00	1
429	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-09 20:13:44.358595+00	1
431	1	Administrador	DELETE	/39	172.19.0.1	200	2026-06-09 20:18:26.469312+00	1
432	1	Administrador	DELETE	/38	172.19.0.1	200	2026-06-09 20:18:28.715575+00	1
433	1	Administrador	DELETE	/26	172.19.0.1	200	2026-06-09 20:18:30.630851+00	1
434	1	Administrador	DELETE	/25	172.19.0.1	400	2026-06-09 20:18:32.779713+00	1
435	1	Administrador	DELETE	/25	172.19.0.1	400	2026-06-09 20:18:33.664234+00	1
436	1	Administrador	DELETE	/38	172.19.0.1	200	2026-06-09 20:18:40.754029+00	1
437	1	Administrador	DELETE	/38/permanent	172.19.0.1	200	2026-06-09 20:18:43.088336+00	1
438	1	Administrador	DELETE	/37	172.19.0.1	200	2026-06-09 20:18:45.087279+00	1
439	1	Administrador	DELETE	/37/permanent	172.19.0.1	200	2026-06-09 20:18:47.379838+00	1
440	1	Administrador	DELETE	/36	172.19.0.1	200	2026-06-09 20:18:48.673388+00	1
441	1	Administrador	DELETE	/36/permanent	172.19.0.1	200	2026-06-09 20:18:50.430805+00	1
442	1	Administrador	DELETE	/19	172.19.0.1	200	2026-06-09 20:18:52.279711+00	1
443	1	Administrador	DELETE	/19/permanent	172.19.0.1	200	2026-06-09 20:18:56.375246+00	1
444	1	Administrador	DELETE	/16	172.19.0.1	200	2026-06-09 20:18:58.376191+00	1
445	1	Administrador	DELETE	/16/permanent	172.19.0.1	200	2026-06-09 20:19:00.021858+00	1
446	1	Administrador	PUT	/2	172.19.0.1	200	2026-06-09 20:21:55.142605+00	1
447	1	Administrador	PUT	/2	172.19.0.1	200	2026-06-09 20:22:07.029909+00	1
448	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:22:26.505629+00	1
449	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:22:53.457703+00	1
450	1	Administrador	DELETE	/25	172.19.0.1	400	2026-06-09 20:23:13.81405+00	1
451	1	Administrador	DELETE	/41	172.19.0.1	200	2026-06-09 20:27:50.07755+00	1
452	1	Administrador	DELETE	/40	172.19.0.1	200	2026-06-09 20:27:51.650703+00	1
453	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-06-09 20:28:15.90133+00	1
454	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:28:35.822897+00	1
455	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:28:41.364154+00	1
456	1	Administrador	DELETE	/42	172.19.0.1	200	2026-06-09 20:32:25.562865+00	1
457	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-06-09 20:32:38.697612+00	1
458	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:33:19.889178+00	1
459	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:33:47.445769+00	1
460	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-06-09 20:33:57.716986+00	1
461	1	Administrador	DELETE	/43	172.19.0.1	200	2026-06-09 20:34:10.228027+00	1
462	1	Administrador	DELETE	/12	172.19.0.1	200	2026-06-09 20:34:22.757776+00	1
463	1	Administrador	DELETE	/11	172.19.0.1	200	2026-06-09 20:34:24.999702+00	1
464	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:37:01.00731+00	1
465	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:46:37.193761+00	1
466	1	Administrador	POST	/1/credit-refund	172.19.0.1	200	2026-06-09 20:47:36.06787+00	1
467	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-06-09 20:47:38.84643+00	1
468	1	Administrador	DELETE	/44	172.19.0.1	200	2026-06-09 20:49:32.823714+00	1
469	1	Administrador	DELETE	/25	172.19.0.1	400	2026-06-09 20:49:34.489215+00	1
470	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:49:45.945442+00	1
471	1	Administrador	POST	/1/credit-refund	172.19.0.1	200	2026-06-09 20:50:09.028532+00	1
472	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-06-09 20:50:12.52992+00	1
473	1	Administrador	DELETE	/45	172.19.0.1	200	2026-06-09 20:54:58.877643+00	1
474	1	Administrador	DELETE	/40	172.19.0.1	200	2026-06-09 20:55:04.467161+00	1
475	1	Administrador	DELETE	/40/permanent	172.19.0.1	200	2026-06-09 20:55:06.380742+00	1
476	1	Administrador	DELETE	/39	172.19.0.1	200	2026-06-09 20:55:08.256979+00	1
477	1	Administrador	DELETE	/39/permanent	172.19.0.1	200	2026-06-09 20:55:10.518822+00	1
478	1	Administrador	DELETE	/19	172.19.0.1	200	2026-06-09 20:55:15.966114+00	1
479	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:55:24.406089+00	1
480	1	Administrador	POST	/1/credit-refund	172.19.0.1	200	2026-06-09 20:56:00.335485+00	1
481	1	Administrador	POST	/1/credit-refund	172.19.0.1	200	2026-06-09 20:56:09.631558+00	1
482	1	Administrador	DELETE	/46	172.19.0.1	200	2026-06-09 20:56:23.190518+00	1
483	1	Administrador	DELETE	/42	172.19.0.1	200	2026-06-09 20:56:33.677688+00	1
484	1	Administrador	DELETE	/42/permanent	172.19.0.1	200	2026-06-09 20:56:36.413739+00	1
485	1	Administrador	DELETE	/41	172.19.0.1	200	2026-06-09 20:56:37.909424+00	1
486	1	Administrador	DELETE	/41/permanent	172.19.0.1	200	2026-06-09 20:56:40.001524+00	1
487	1	Administrador	POST	/	172.19.0.1	201	2026-06-09 20:59:39.561939+00	1
488	1	Administrador	POST	/1/credit-refund	172.19.0.1	200	2026-06-09 20:59:51.152921+00	1
489	1	Administrador	DELETE	/43	172.19.0.1	200	2026-06-09 21:01:00.6596+00	1
490	1	Administrador	DELETE	/43/permanent	172.19.0.1	200	2026-06-09 21:01:02.689166+00	1
491	1	Administrador	DELETE	/47	172.19.0.1	200	2026-06-09 21:01:06.12463+00	1
492	1	Administrador	DELETE	/11	172.19.0.1	400	2026-06-10 15:03:54.703592+00	1
493	1	Administrador	DELETE	/8	172.19.0.1	400	2026-06-10 15:04:00.339196+00	1
494	1	Administrador	DELETE	/8	172.19.0.1	400	2026-06-10 15:04:01.035408+00	1
495	1	Administrador	DELETE	/20	172.19.0.1	200	2026-06-10 15:04:08.944512+00	1
496	1	Administrador	DELETE	/25	172.19.0.1	400	2026-06-10 15:04:13.076297+00	1
497	1	Administrador	DELETE	/11	172.19.0.1	200	2026-06-10 15:06:33.869441+00	1
498	1	Administrador	DELETE	/8	172.19.0.1	200	2026-06-10 15:06:36.288103+00	1
499	1	Administrador	DELETE	/9	172.19.0.1	200	2026-06-10 15:06:38.408607+00	1
500	1	Administrador	DELETE	/21	172.19.0.1	200	2026-06-10 15:06:47.004391+00	1
501	1	Administrador	DELETE	/18	172.19.0.1	200	2026-06-10 15:06:48.63614+00	1
502	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 15:07:13.336335+00	1
503	1	Administrador	PATCH	/22/confirm	172.19.0.1	200	2026-06-10 15:07:16.751991+00	1
504	1	Administrador	PATCH	/22/receive	172.19.0.1	200	2026-06-10 15:08:06.540438+00	1
505	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 15:10:11.097782+00	1
506	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:23:49.659679+00	1
507	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 15:26:11.454717+00	1
508	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 15:28:12.604165+00	1
509	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:41:50.788845+00	1
510	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 15:44:50.961481+00	1
511	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:45:24.750082+00	1
512	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:45:36.590324+00	1
513	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:45:49.248746+00	1
514	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:46:02.329805+00	1
515	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:48:55.176167+00	1
516	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 15:49:06.133953+00	1
517	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-06-10 15:55:11.474665+00	1
518	1	Administrador	POST	/1/sessions/3/lines	172.19.0.1	201	2026-06-10 15:55:11.526901+00	1
519	1	Administrador	PATCH	/1/sessions/3/close	172.19.0.1	200	2026-06-10 15:55:23.167103+00	1
520	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:03:37.883942+00	1
521	1	Administrador	PUT	/3	172.19.0.1	200	2026-06-10 16:04:12.669392+00	1
522	1	Administrador	PUT	/3	172.19.0.1	200	2026-06-10 16:04:51.107075+00	1
523	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:06:34.713355+00	1
524	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:06:37.236091+00	1
525	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:12:23.446786+00	1
526	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:12:28.531355+00	1
527	1	Administrador	PUT	/3	172.19.0.1	200	2026-06-10 16:12:49.275431+00	1
528	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-10 16:13:54.87945+00	1
529	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:14:15.938474+00	1
530	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:15:00.762458+00	1
531	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:20:11.113652+00	1
532	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-10 16:20:45.665467+00	1
533	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:24:52.041451+00	1
534	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:24:55.729123+00	1
535	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:25:07.322934+00	1
536	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:25:16.874831+00	1
537	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:25:21.810052+00	1
538	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-06-10 16:30:01.700032+00	1
539	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:30:22.696976+00	1
540	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:30:29.056733+00	1
541	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:30:32.800653+00	1
542	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:30:36.735223+00	1
543	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:30:39.351337+00	1
544	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:30:41.593777+00	1
545	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:30:48.883508+00	1
546	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:30:58.147159+00	1
547	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:31:02.540043+00	1
548	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-10 16:31:13.220471+00	1
549	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:23.044574+00	1
550	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:27.264132+00	1
551	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:30.741278+00	1
552	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:37.469408+00	1
553	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:38.260502+00	1
554	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:38.85286+00	1
555	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-10 16:31:46.638453+00	1
556	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:49.005918+00	1
557	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:52.155354+00	1
558	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:53.356337+00	1
559	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:31:54.42371+00	1
560	1	Administrador	DELETE	/22	172.19.0.1	200	2026-06-10 16:32:51.125976+00	1
561	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 16:33:07.570946+00	1
562	1	Administrador	PATCH	/23/receive	172.19.0.1	200	2026-06-10 16:33:14.854771+00	1
563	1	Administrador	DELETE	/23	172.19.0.1	200	2026-06-10 16:35:35.161599+00	1
564	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 16:36:04.712062+00	1
565	1	Administrador	PATCH	/24/receive	172.19.0.1	200	2026-06-10 16:36:07.199672+00	1
566	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-06-10 16:37:03.00107+00	1
567	1	Administrador	POST	/1/sessions/4/lines	172.19.0.1	201	2026-06-10 16:37:03.06283+00	1
568	1	Administrador	PATCH	/1/sessions/4/close	172.19.0.1	200	2026-06-10 16:37:05.707731+00	1
569	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:40:33.357634+00	1
570	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:40:38.412968+00	1
571	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:40:49.024027+00	1
572	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-06-10 16:41:04.536964+00	1
573	1	Administrador	POST	/1/sessions/5/lines	172.19.0.1	201	2026-06-10 16:41:04.621747+00	1
574	1	Administrador	POST	/1/sessions/5/lines	172.19.0.1	201	2026-06-10 16:41:13.927669+00	1
575	1	Administrador	PATCH	/1/sessions/5/close	172.19.0.1	200	2026-06-10 16:41:19.691059+00	1
576	1	Administrador	DELETE	/24	172.19.0.1	500	2026-06-10 16:41:28.310261+00	1
577	1	Administrador	DELETE	/24	172.19.0.1	500	2026-06-10 16:41:33.510112+00	1
578	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-06-10 16:41:50.447097+00	1
579	1	Administrador	POST	/1/sessions/6/lines	172.19.0.1	201	2026-06-10 16:41:50.483392+00	1
580	1	Administrador	PATCH	/1/sessions/6/close	172.19.0.1	200	2026-06-10 16:41:53.609161+00	1
581	1	Administrador	DELETE	/24	172.19.0.1	200	2026-06-10 16:42:00.349052+00	1
582	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 16:42:42.472672+00	1
583	1	Administrador	PATCH	/25/receive	172.19.0.1	200	2026-06-10 16:42:52.657629+00	1
584	1	Administrador	DELETE	/25	172.19.0.1	200	2026-06-10 16:43:11.90097+00	1
585	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 16:45:05.976866+00	1
586	1	Administrador	PATCH	/26/receive	172.19.0.1	200	2026-06-10 16:45:14.403678+00	1
587	1	Administrador	DELETE	/26	172.19.0.1	200	2026-06-10 16:45:39.008856+00	1
588	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 16:48:43.058055+00	1
589	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:48:59.319938+00	1
590	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:49:19.891169+00	1
591	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:49:20.949555+00	1
592	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:49:39.925283+00	1
593	1	Administrador	PUT	/1	172.19.0.1	200	2026-06-10 16:50:02.89968+00	1
594	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:50:09.658394+00	1
595	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:50:11.257496+00	1
596	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:50:13.657693+00	1
597	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:50:27.392874+00	1
598	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:50:28.392572+00	1
599	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:50:29.034616+00	1
600	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:50:40.29728+00	1
601	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:50:46.523437+00	1
602	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:50:54.694291+00	1
603	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:51:37.128262+00	1
604	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:51:42.828964+00	1
605	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:51:46.9057+00	1
606	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:51:49.855816+00	1
607	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:51:50.889423+00	1
608	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:51:55.1826+00	1
609	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:52:04.298385+00	1
610	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:52:12.357477+00	1
611	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:52:42.665965+00	1
612	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:25.646957+00	1
613	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:27.163768+00	1
614	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:27.367015+00	1
615	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:27.559317+00	1
616	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:27.756811+00	1
617	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:28.011057+00	1
618	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:28.220955+00	1
619	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:28.408248+00	1
620	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:28.597308+00	1
621	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:28.962845+00	1
622	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:53:29.188129+00	1
623	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:53:31.358647+00	1
624	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 16:54:21.853872+00	1
625	1	Administrador	DELETE	/23	172.19.0.1	200	2026-06-10 16:54:40.436975+00	1
626	1	Administrador	DELETE	/22	172.19.0.1	200	2026-06-10 16:54:42.143938+00	1
627	1	Administrador	DELETE	/21	172.19.0.1	200	2026-06-10 16:54:44.857836+00	1
628	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:58:28.480881+00	1
629	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:30.505201+00	1
630	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:30.765429+00	1
631	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:31.022653+00	1
632	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:31.214875+00	1
633	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:31.380997+00	1
634	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:31.528031+00	1
635	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:31.685511+00	1
636	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:58:35.076132+00	1
637	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 16:58:39.015263+00	1
638	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:53.280329+00	1
639	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:54.043875+00	1
640	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:54.265454+00	1
641	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 16:58:54.431537+00	1
642	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 16:58:59.870338+00	1
643	2	Prueba	POST	/refresh	172.19.0.1	403	2026-06-10 17:00:02.810278+00	1
644	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 17:02:10.089448+00	1
645	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:02:16.464096+00	1
646	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:02:18.05879+00	1
647	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:02:23.342963+00	1
648	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:02:30.924423+00	1
649	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:38.305489+00	1
650	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:40.443208+00	1
651	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:41.191709+00	1
652	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:42.381669+00	1
653	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:42.892269+00	1
654	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:43.510061+00	1
655	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:43.880386+00	1
656	1	Administrador	PUT	/3/toggle	172.19.0.1	200	2026-06-10 17:02:44.513376+00	1
657	1	Administrador	POST	/trigger	172.19.0.1	200	2026-06-10 17:04:56.332547+00	1
658	1	Administrador	DELETE	/3	172.19.0.1	200	2026-06-10 17:30:23.0589+00	1
659	1	Administrador	POST	/refresh	172.19.0.1	500	2026-06-10 17:34:56.683072+00	1
660	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:35:01.391813+00	1
661	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 17:35:03.48777+00	1
662	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 17:35:08.085813+00	1
663	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:35:11.80231+00	1
664	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 17:35:30.776233+00	1
665	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:35:34.032554+00	1
666	1	Administrador	DELETE	/4	172.19.0.1	200	2026-06-10 17:35:41.000868+00	1
667	1	Administrador	PUT	/	172.19.0.1	200	2026-06-10 17:40:18.63772+00	1
668	1	Administrador	PUT	/	172.19.0.1	200	2026-06-10 17:44:11.895143+00	1
669	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 17:44:38.303547+00	1
670	1	Administrador	PUT	/	172.19.0.1	200	2026-06-10 17:45:20.446992+00	1
671	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 17:45:32.44632+00	1
672	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-06-10 17:47:39.014578+00	1
673	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:47:41.281833+00	1
674	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 17:58:42.603459+00	1
675	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:06:54.381033+00	1
676	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:07:33.583998+00	1
677	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:08:00.222366+00	1
678	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:08:26.36949+00	1
679	1	Administrador	DELETE	/48	172.19.0.1	200	2026-06-10 18:11:49.239092+00	1
680	1	Administrador	DELETE	/49	172.19.0.1	200	2026-06-10 18:11:50.894439+00	1
681	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:15:44.152146+00	1
682	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-06-10 18:17:16.049728+00	1
683	1	Administrador	POST	/1/sessions/7/lines	172.19.0.1	201	2026-06-10 18:17:16.096147+00	1
684	1	Administrador	POST	/1/sessions/7/lines	172.19.0.1	201	2026-06-10 18:17:19.627446+00	1
685	1	Administrador	POST	/1/sessions/7/lines	172.19.0.1	201	2026-06-10 18:17:24.610473+00	1
686	1	Administrador	PATCH	/1/sessions/7/close	172.19.0.1	200	2026-06-10 18:17:31.88818+00	1
687	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-06-10 18:18:15.561431+00	1
688	1	Administrador	POST	/1/sessions/8/lines	172.19.0.1	201	2026-06-10 18:18:15.600756+00	1
689	1	Administrador	PATCH	/1/sessions/8/close	172.19.0.1	200	2026-06-10 18:18:30.211438+00	1
690	1	Administrador	DELETE	/52	172.19.0.1	200	2026-06-10 18:23:50.900082+00	1
691	1	Administrador	DELETE	/51	172.19.0.1	200	2026-06-10 18:23:52.600361+00	1
692	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:25:41.161393+00	1
693	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 18:27:03.145613+00	1
694	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:27:18.640042+00	1
695	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:27:47.222842+00	1
696	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-06-10 18:42:14.901252+00	1
697	1	Administrador	POST	/1/sessions/9/lines	172.19.0.1	201	2026-06-10 18:42:14.975672+00	1
698	1	Administrador	PATCH	/1/sessions/9/close	172.19.0.1	200	2026-06-10 18:42:16.800118+00	1
699	1	Administrador	DELETE	/54	172.19.0.1	200	2026-06-10 18:45:01.064832+00	1
700	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-06-10 18:46:36.10356+00	1
701	1	Administrador	PUT	/13	172.19.0.1	200	2026-06-10 18:47:20.281761+00	1
702	1	Administrador	POST	/	172.19.0.1	201	2026-06-10 18:48:00.180578+00	1
703	1	Administrador	PATCH	/27/confirm	172.19.0.1	200	2026-06-10 18:48:03.421437+00	1
704	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-10 18:54:47.108815+00	1
705	1	Administrador	PATCH	/27/receive	172.19.0.1	500	2026-06-10 19:03:33.336625+00	1
706	1	Administrador	PATCH	/27	172.19.0.1	200	2026-06-10 19:03:38.074137+00	1
707	1	Administrador	PATCH	/27/receive	172.19.0.1	200	2026-06-10 19:03:40.055322+00	1
708	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-10 19:04:08.795778+00	1
709	1	Administrador	PATCH	/27	172.19.0.1	200	2026-06-10 19:06:03.42227+00	1
710	1	Administrador	PATCH	/27/receive	172.19.0.1	200	2026-06-10 19:06:05.420566+00	1
711	1	Administrador	POST	/	172.19.0.1	201	2026-06-12 18:17:59.907528+00	1
712	1	Administrador	PUT	/2/employees	172.19.0.1	200	2026-06-12 18:18:02.514051+00	1
713	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-12 18:25:20.375531+00	1
714	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-12 18:25:35.146395+00	1
715	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-12 18:25:45.601888+00	1
716	1	Administrador	POST	/	172.19.0.1	500	2026-06-12 18:26:17.927296+00	1
717	1	Administrador	POST	/	172.19.0.1	500	2026-06-12 18:26:25.219006+00	1
718	1	Administrador	POST	/	172.19.0.1	201	2026-06-12 18:27:31.756235+00	1
719	1	Administrador	POST	/	172.19.0.1	201	2026-06-12 18:28:07.665731+00	1
720	1	Administrador	POST	/	172.19.0.1	201	2026-06-12 18:29:44.417962+00	1
721	1	Administrador	POST	/1/stock	172.19.0.1	200	2026-06-12 18:31:48.307156+00	1
722	1	Administrador	PUT	/1/stock/16	172.19.0.1	200	2026-06-12 18:32:07.851355+00	1
723	1	Administrador	POST	/open	172.19.0.1	201	2026-06-12 18:32:43.663613+00	1
724	1	Administrador	DELETE	/18	172.19.0.1	400	2026-06-12 18:54:20.942217+00	1
725	1	Administrador	DELETE	/1/stock/18	172.19.0.1	200	2026-06-12 18:54:53.669993+00	1
726	1	Administrador	DELETE	/1/stock/13	172.19.0.1	200	2026-06-12 18:54:56.544745+00	1
727	1	Administrador	DELETE	/18	172.19.0.1	200	2026-06-12 18:55:10.63833+00	1
728	1	Administrador	DELETE	/13	172.19.0.1	200	2026-06-12 18:55:13.515753+00	1
729	1	Administrador	POST	/	172.19.0.1	201	2026-06-12 18:55:33.820065+00	1
730	1	Administrador	POST	/	172.19.0.1	201	2026-06-12 18:57:09.427331+00	1
731	1	Administrador	POST	/	172.19.0.1	201	2026-06-12 18:58:28.073205+00	1
732	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-12 19:00:59.429442+00	1
733	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-12 19:01:21.916245+00	1
734	1	Administrador	PUT	/10	172.19.0.1	200	2026-06-12 19:01:32.168666+00	1
735	1	Administrador	DELETE	/27	172.19.0.1	200	2026-06-15 14:18:02.024359+00	1
736	1	Administrador	POST	/	172.19.0.1	201	2026-06-15 14:21:04.631874+00	1
737	1	Administrador	PATCH	/28	172.19.0.1	200	2026-06-15 14:23:48.015675+00	1
738	1	Administrador	PATCH	/28/receive	172.19.0.1	500	2026-06-15 14:24:01.652861+00	1
739	1	Administrador	PATCH	/28/receive	172.19.0.1	500	2026-06-15 14:24:02.907961+00	1
740	1	Administrador	PATCH	/28	172.19.0.1	200	2026-06-15 14:24:06.055588+00	1
741	1	Administrador	PATCH	/28/receive	172.19.0.1	200	2026-06-15 14:24:07.056693+00	1
742	1	Administrador	DELETE	/28	172.19.0.1	200	2026-06-15 14:24:20.821424+00	1
743	1	Administrador	POST	/	172.19.0.1	201	2026-06-15 14:25:31.879908+00	1
744	1	Administrador	PATCH	/29/receive	172.19.0.1	500	2026-06-15 14:25:33.257093+00	1
745	1	Administrador	PATCH	/29	172.19.0.1	200	2026-06-15 14:25:35.678219+00	1
746	1	Administrador	PATCH	/29/receive	172.19.0.1	200	2026-06-15 14:25:36.361169+00	1
747	1	Administrador	POST	/	172.19.0.1	201	2026-06-15 14:25:54.842455+00	1
748	1	Administrador	PATCH	/30/receive	172.19.0.1	200	2026-06-15 14:25:56.520922+00	1
749	1	Administrador	DELETE	/30	172.19.0.1	200	2026-06-15 14:26:16.047159+00	1
750	1	Administrador	DELETE	/29	172.19.0.1	200	2026-06-15 14:26:17.651581+00	1
751	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-15 14:32:36.357888+00	1
752	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-16 18:42:23.172186+00	1
753	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-16 18:42:24.164844+00	1
754	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-16 18:42:25.009215+00	1
755	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-16 18:42:25.73493+00	1
756	1	Administrador	PUT	/19	172.19.0.1	200	2026-06-17 14:36:38.664459+00	1
757	1	Administrador	PUT	/19	172.19.0.1	200	2026-06-17 14:57:19.560528+00	1
758	1	Administrador	PUT	/19	172.19.0.1	200	2026-06-17 14:58:16.197356+00	1
759	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-17 14:58:59.398843+00	1
760	1	Administrador	PUT	/19	172.19.0.1	200	2026-06-17 15:00:57.920938+00	1
761	1	Administrador	PUT	/19	172.19.0.1	200	2026-06-17 15:02:30.470106+00	1
762	1	Administrador	PUT	/16	172.19.0.1	200	2026-06-17 15:03:26.747033+00	1
763	1	Administrador	PUT	/19	172.19.0.1	200	2026-06-17 15:04:49.718988+00	1
764	1	Administrador	POST	/	172.19.0.1	201	2026-06-17 15:27:25.102997+00	1
765	1	Administrador	PATCH	/31	172.19.0.1	200	2026-06-17 15:31:06.125062+00	1
766	1	Administrador	PATCH	/31	172.19.0.1	200	2026-06-17 15:36:07.023651+00	1
767	1	Administrador	DELETE	/31	172.19.0.1	200	2026-06-17 15:36:56.834511+00	1
768	1	Administrador	POST	/	172.19.0.1	201	2026-06-17 15:38:26.723984+00	1
769	1	Administrador	DELETE	/32	172.19.0.1	200	2026-06-17 15:45:31.136014+00	1
770	1	Administrador	POST	/	172.19.0.1	201	2026-06-17 15:56:51.052529+00	1
771	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 15:57:45.501622+00	1
772	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-17 15:58:13.047063+00	1
773	1	Administrador	DELETE	/posdb_20260610_170457.sql.gz	172.19.0.1	200	2026-06-17 15:58:17.463645+00	1
774	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:02:33.636216+00	1
775	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:02:41.47574+00	1
776	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:02:45.777372+00	1
777	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:02:53.713186+00	1
778	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:03:00.093171+00	1
779	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:03:03.680553+00	1
780	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:06:21.806638+00	1
781	1	Administrador	PATCH	/33/confirm	172.19.0.1	200	2026-06-17 16:07:33.221276+00	1
782	1	Administrador	PATCH	/33	172.19.0.1	200	2026-06-17 16:12:17.045597+00	1
783	1	Administrador	PATCH	/33/receive	172.19.0.1	200	2026-06-17 16:12:23.684723+00	1
784	1	Administrador	DELETE	/33	172.19.0.1	200	2026-06-17 16:17:01.350002+00	1
785	1	Administrador	POST	/	172.19.0.1	201	2026-06-17 16:17:28.100792+00	1
786	1	Administrador	PATCH	/34	172.19.0.1	200	2026-06-17 16:17:43.85718+00	1
787	1	Administrador	PATCH	/34/receive	172.19.0.1	200	2026-06-17 16:17:46.20504+00	1
788	1	Administrador	PUT	/19	172.19.0.1	200	2026-06-17 16:18:36.73611+00	1
789	1	Administrador	DELETE	/34	172.19.0.1	200	2026-06-17 16:30:05.106942+00	1
790	1	Administrador	POST	/	172.19.0.1	201	2026-06-17 16:30:40.754931+00	1
791	1	Administrador	PATCH	/35	172.19.0.1	200	2026-06-17 16:30:57.485502+00	1
792	1	Administrador	PATCH	/35/receive	172.19.0.1	200	2026-06-17 16:30:59.304468+00	1
793	1	Administrador	DELETE	/35	172.19.0.1	200	2026-06-17 16:31:15.422093+00	1
794	1	Administrador	PUT	/1	172.19.0.1	200	2026-06-18 13:29:07.37462+00	1
795	1	Administrador	PUT	/api/products/3	172.19.0.1	500	2026-06-18 13:30:05.553938+00	1
796	1	Administrador	PUT	/3	172.19.0.1	200	2026-06-18 13:30:29.607805+00	1
797	1	Administrador	PUT	/1	172.19.0.1	200	2026-06-18 13:33:02.131878+00	1
798	1	Administrador	PUT	/3	172.19.0.1	200	2026-06-18 13:33:08.657694+00	1
799	1	Administrador	PUT	/3	172.19.0.1	200	2026-06-18 13:33:17.583392+00	1
800	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-18 14:12:43.537102+00	1
801	1	Administrador	PUT	/16	172.19.0.1	200	2026-06-18 14:13:15.265297+00	1
802	1	Administrador	PUT	/12	172.19.0.1	200	2026-06-18 14:13:43.272904+00	1
803	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-18 14:13:56.545166+00	1
804	1	Administrador	POST	/refresh	172.19.0.1	200	2026-06-18 14:13:57.680173+00	1
805	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:13:35.942414+00	1
806	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:13:54.261589+00	1
807	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:14:06.185495+00	1
808	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:14:15.889665+00	1
809	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:14:36.237485+00	1
810	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:14:50.223165+00	1
811	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:15:19.187828+00	1
812	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:15:29.828335+00	1
813	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:15:38.187397+00	1
814	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:15:52.644085+00	1
815	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:16:06.476266+00	1
816	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:36:57.16321+00	1
817	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:37:01.667528+00	1
818	1	Administrador	POST	/	172.19.0.1	201	2026-07-06 20:37:06.966131+00	1
819	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-07 21:01:46.797332+00	1
820	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-08 12:23:55.5913+00	1
821	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-08 12:23:57.281134+00	1
822	1	Administrador	POST	/refresh	172.19.0.1	500	2026-07-08 12:24:05.922278+00	1
823	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 13:08:56.784411+00	1
824	1	Administrador	PUT	/21	172.19.0.1	200	2026-07-20 13:22:55.563492+00	1
825	1	Administrador	POST	/	172.19.0.1	400	2026-07-20 13:23:48.094699+00	1
826	1	Administrador	POST	/	172.19.0.1	400	2026-07-20 13:24:34.396921+00	1
827	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 13:24:37.310411+00	1
828	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 13:42:14.912276+00	1
829	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 13:42:29.879604+00	1
830	1	Administrador	PATCH	/2/cancel	172.19.0.1	200	2026-07-20 13:43:28.387422+00	1
831	1	Administrador	DELETE	/39	172.19.0.1	200	2026-07-20 13:44:30.501744+00	1
832	1	Administrador	DELETE	/38	172.19.0.1	200	2026-07-20 13:44:33.624726+00	1
833	1	Administrador	DELETE	/37	172.19.0.1	200	2026-07-20 13:44:35.374789+00	1
834	1	Administrador	DELETE	/36	172.19.0.1	200	2026-07-20 13:44:37.204473+00	1
835	1	Administrador	DELETE	/35	172.19.0.1	200	2026-07-20 13:44:38.897638+00	1
836	1	Administrador	DELETE	/34	172.19.0.1	200	2026-07-20 13:44:40.382579+00	1
837	1	Administrador	DELETE	/33	172.19.0.1	200	2026-07-20 13:44:41.789647+00	1
838	1	Administrador	DELETE	/32	172.19.0.1	200	2026-07-20 13:44:43.49983+00	1
839	1	Administrador	DELETE	/31	172.19.0.1	200	2026-07-20 13:44:51.52831+00	1
840	1	Administrador	DELETE	/28	172.19.0.1	200	2026-07-20 13:44:59.399815+00	1
841	1	Administrador	DELETE	/59	172.19.0.1	400	2026-07-20 13:45:03.99317+00	1
842	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-20 13:47:39.794695+00	1
843	1	Administrador	DELETE	/2	172.19.0.1	200	2026-07-20 13:48:40.990534+00	1
844	1	Administrador	DELETE	/59	172.19.0.1	400	2026-07-20 13:50:48.250768+00	1
845	1	Administrador	DELETE	/44	172.19.0.1	200	2026-07-20 13:53:13.632184+00	1
846	1	Administrador	DELETE	/44/permanent	172.19.0.1	200	2026-07-20 13:53:15.847365+00	1
847	1	Administrador	DELETE	/59	172.19.0.1	200	2026-07-20 13:55:54.203565+00	1
848	1	Administrador	DELETE	/58	172.19.0.1	200	2026-07-20 13:55:56.135218+00	1
849	1	Administrador	DELETE	/57	172.19.0.1	200	2026-07-20 13:55:57.776629+00	1
850	1	Administrador	DELETE	/56	172.19.0.1	200	2026-07-20 13:55:59.422684+00	1
851	1	Administrador	DELETE	/55	172.19.0.1	200	2026-07-20 13:56:01.784563+00	1
852	1	Administrador	DELETE	/53	172.19.0.1	200	2026-07-20 13:56:03.750583+00	1
853	1	Administrador	DELETE	/50	172.19.0.1	200	2026-07-20 13:56:05.56651+00	1
854	1	Administrador	DELETE	/30	172.19.0.1	200	2026-07-20 13:56:10.436233+00	1
856	1	Administrador	DELETE	/27	172.19.0.1	200	2026-07-20 13:56:14.554313+00	1
855	1	Administrador	DELETE	/29	172.19.0.1	200	2026-07-20 13:56:12.693977+00	1
857	1	Administrador	DELETE	/26	172.19.0.1	200	2026-07-20 13:56:16.411157+00	1
858	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:00:29.910777+00	1
859	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:00:36.697153+00	1
860	1	Administrador	DELETE	/40	172.19.0.1	200	2026-07-20 14:00:58.209436+00	1
861	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:02:15.699201+00	1
862	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:02:41.639577+00	1
863	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:02:47.325223+00	1
864	1	Administrador	POST	/41/exchange	172.19.0.1	201	2026-07-20 14:03:42.165623+00	1
865	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:03:52.884013+00	1
866	1	Administrador	DELETE	/42	172.19.0.1	200	2026-07-20 14:10:18.833988+00	1
867	1	Administrador	DELETE	/41	172.19.0.1	200	2026-07-20 14:10:21.240484+00	1
868	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-20 14:14:41.313679+00	1
869	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:19:27.729711+00	1
870	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:19:30.299661+00	1
871	1	Administrador	POST	/43/return	172.19.0.1	201	2026-07-20 14:19:56.596072+00	1
872	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:20:26.977097+00	1
873	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:20:36.019643+00	1
874	1	Administrador	POST	/44/return	172.19.0.1	201	2026-07-20 14:23:58.572968+00	1
875	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:36:52.433292+00	1
876	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:37:09.86227+00	1
877	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:38:19.742546+00	1
878	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 14:38:43.504912+00	1
879	1	Administrador	POST	/46/return	172.19.0.1	201	2026-07-20 14:38:51.742881+00	1
880	1	Administrador	POST	/	172.19.0.1	201	2026-07-20 15:15:59.241021+00	1
881	1	Administrador	PATCH	/36/receive	172.19.0.1	500	2026-07-20 15:16:09.721256+00	1
882	1	Administrador	PATCH	/36	172.19.0.1	200	2026-07-20 15:16:11.305599+00	1
883	1	Administrador	PATCH	/36/receive	172.19.0.1	200	2026-07-20 15:16:12.06788+00	1
884	1	Administrador	POST	/36/payments	172.19.0.1	201	2026-07-20 15:52:54.428261+00	1
885	1	Administrador	PUT	/21	172.19.0.1	200	2026-07-21 12:33:26.813866+00	1
886	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-21 13:09:55.89917+00	1
887	1	Administrador	PUT	/17	172.19.0.1	200	2026-07-21 13:57:42.676817+00	1
888	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-21 13:58:49.792246+00	1
889	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-23 17:46:16.20588+00	1
890	1	Administrador	PUT	/16	172.19.0.1	200	2026-07-23 17:46:33.989545+00	1
891	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 17:47:06.719983+00	1
892	1	Administrador	DELETE	/47	172.19.0.1	200	2026-07-23 17:53:09.874993+00	1
893	1	Administrador	DELETE	/68	172.19.0.1	200	2026-07-23 17:53:17.604673+00	1
894	1	Administrador	DELETE	/67	172.19.0.1	200	2026-07-23 17:53:21.431654+00	1
895	1	Administrador	DELETE	/66	172.19.0.1	200	2026-07-23 17:53:23.028563+00	1
896	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:05:17.147675+00	1
897	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:05:37.896223+00	1
898	1	Administrador	DELETE	/49	172.19.0.1	200	2026-07-23 18:08:10.101846+00	1
899	1	Administrador	DELETE	/48	172.19.0.1	200	2026-07-23 18:08:12.070327+00	1
900	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:08:56.667693+00	1
901	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:14:17.539276+00	1
902	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:15:11.339041+00	1
903	1	Administrador	DELETE	/51	172.19.0.1	200	2026-07-23 18:16:40.221404+00	1
904	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:16:53.502288+00	1
905	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:20:07.690041+00	1
906	1	Administrador	DELETE	/46	172.19.0.1	200	2026-07-23 18:39:31.676445+00	1
907	1	Administrador	DELETE	/45	172.19.0.1	200	2026-07-23 18:39:33.749208+00	1
908	1	Administrador	DELETE	/43	172.19.0.1	200	2026-07-23 18:39:35.428655+00	1
909	1	Administrador	DELETE	/44	172.19.0.1	200	2026-07-23 18:39:37.327384+00	1
910	1	Administrador	DELETE	/50	172.19.0.1	200	2026-07-23 18:39:42.239624+00	1
911	1	Administrador	DELETE	/52	172.19.0.1	200	2026-07-23 18:39:44.430977+00	1
912	1	Administrador	DELETE	/53	172.19.0.1	200	2026-07-23 18:39:46.163487+00	1
913	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-23 18:40:20.475829+00	1
914	1	Administrador	POST	/refresh	172.19.0.1	200	2026-07-23 18:40:21.42366+00	1
915	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:41:37.152922+00	1
916	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:41:44.605805+00	1
917	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-07-23 18:42:03.612896+00	1
918	1	Administrador	DELETE	/70	172.19.0.1	200	2026-07-23 18:42:36.308042+00	1
919	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:42:56.21594+00	1
920	1	Administrador	POST	/54/return	172.19.0.1	201	2026-07-23 18:43:53.590846+00	1
921	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:44:51.186142+00	1
922	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:45:32.115749+00	1
923	1	Administrador	DELETE	/55	172.19.0.1	200	2026-07-23 18:46:44.791358+00	1
924	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:47:01.386255+00	1
925	1	Administrador	DELETE	/71	172.19.0.1	200	2026-07-23 18:47:22.052342+00	1
926	1	Administrador	DELETE	/54	172.19.0.1	200	2026-07-23 18:47:36.62076+00	1
927	1	Administrador	DELETE	/56	172.19.0.1	200	2026-07-23 18:57:07.180308+00	1
928	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:57:21.673953+00	1
929	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 18:57:26.170827+00	1
930	1	Administrador	DELETE	/73	172.19.0.1	200	2026-07-23 18:58:05.985873+00	1
931	1	Administrador	DELETE	/57	172.19.0.1	200	2026-07-23 18:58:12.173754+00	1
932	1	Administrador	PUT	/10	172.19.0.1	200	2026-07-23 18:58:33.887072+00	1
933	1	Administrador	PUT	/3	172.19.0.1	200	2026-07-23 18:58:46.28868+00	1
934	1	Administrador	PUT	/10	172.19.0.1	200	2026-07-23 18:59:45.943055+00	1
935	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:00:03.772145+00	1
936	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:00:48.52644+00	1
937	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:01:13.006244+00	1
938	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:01:31.505968+00	1
939	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:02:56.951039+00	1
940	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:03:03.988267+00	1
941	1	Administrador	DELETE	/76	172.19.0.1	200	2026-07-23 19:07:55.581288+00	1
942	1	Administrador	DELETE	/75	172.19.0.1	200	2026-07-23 19:08:02.768269+00	1
943	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:17:43.229785+00	1
944	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:18:17.850814+00	1
945	1	Administrador	DELETE	/59	172.19.0.1	200	2026-07-23 19:18:50.020934+00	1
946	1	Administrador	DELETE	/60	172.19.0.1	200	2026-07-23 19:18:52.105868+00	1
947	1	Administrador	DELETE	/61	172.19.0.1	200	2026-07-23 19:18:53.98535+00	1
948	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:27:15.870551+00	1
949	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:27:26.57148+00	1
950	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:27:56.727379+00	1
951	1	Administrador	DELETE	/63	172.19.0.1	200	2026-07-23 19:29:01.872853+00	1
952	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:29:14.465082+00	1
953	1	Administrador	DELETE	/64	172.19.0.1	200	2026-07-23 19:29:43.392505+00	1
954	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:29:57.562991+00	1
955	1	Administrador	DELETE	/65	172.19.0.1	200	2026-07-23 19:32:28.063767+00	1
956	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:35:25.982981+00	1
957	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:39:09.111091+00	1
958	1	Administrador	DELETE	/67	172.19.0.1	200	2026-07-23 19:39:49.914777+00	1
959	1	Administrador	DELETE	/66	172.19.0.1	200	2026-07-23 19:39:57.799374+00	1
960	1	Administrador	DELETE	/62	172.19.0.1	200	2026-07-23 19:41:23.491509+00	1
961	1	Administrador	DELETE	/58	172.19.0.1	200	2026-07-23 19:41:25.272229+00	1
962	1	Administrador	DELETE	/45	172.19.0.1	200	2026-07-23 19:41:53.152054+00	1
963	1	Administrador	DELETE	/45/permanent	172.19.0.1	200	2026-07-23 19:41:55.817445+00	1
964	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:46:45.630247+00	1
965	1	Administrador	DELETE	/34	172.19.0.1	200	2026-07-23 19:47:06.495341+00	1
966	1	Administrador	DELETE	/68	172.19.0.1	200	2026-07-23 19:47:23.403395+00	1
967	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:47:40.547572+00	1
968	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:50:36.945278+00	1
969	1	Administrador	DELETE	/79	172.19.0.1	200	2026-07-23 19:50:48.74005+00	1
970	1	Administrador	DELETE	/69	172.19.0.1	200	2026-07-23 19:59:20.410064+00	1
971	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 19:59:31.314962+00	1
972	1	Administrador	DELETE	/70	172.19.0.1	200	2026-07-23 19:59:56.602532+00	1
973	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:00:45.552762+00	1
974	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:00:50.703449+00	1
975	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:01:00.853177+00	1
976	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:01:32.542865+00	1
977	1	Administrador	DELETE	/81	172.19.0.1	200	2026-07-23 20:02:08.464435+00	1
978	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:03:04.63942+00	1
979	1	Administrador	DELETE	/82	172.19.0.1	200	2026-07-23 20:03:09.523736+00	1
980	1	Administrador	DELETE	/80	172.19.0.1	200	2026-07-23 20:03:14.371847+00	1
981	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:03:22.409776+00	1
982	1	Administrador	DELETE	/83	172.19.0.1	200	2026-07-23 20:03:45.737969+00	1
983	1	Administrador	PUT	/3	172.19.0.1	200	2026-07-23 20:24:43.957054+00	1
984	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:25:03.81384+00	1
985	1	Administrador	DELETE	/73	172.19.0.1	200	2026-07-23 20:31:35.507153+00	1
986	1	Administrador	DELETE	/72	172.19.0.1	200	2026-07-23 20:31:37.224821+00	1
987	1	Administrador	DELETE	/71	172.19.0.1	200	2026-07-23 20:31:39.506377+00	1
988	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:31:52.931513+00	1
989	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:32:06.024641+00	1
990	1	Administrador	DELETE	/84	172.19.0.1	200	2026-07-23 20:33:15.376905+00	1
991	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:39:51.373288+00	1
992	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:40:37.761117+00	1
993	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:40:53.010847+00	1
994	1	Administrador	DELETE	/86	172.19.0.1	200	2026-07-23 20:41:03.029087+00	1
995	1	Administrador	DELETE	/2	172.19.0.1	200	2026-07-23 20:45:52.404967+00	1
996	1	Administrador	PUT	/1/stock/3	172.19.0.1	200	2026-07-23 20:46:06.976495+00	1
997	1	Administrador	POST	/	172.19.0.1	500	2026-07-23 20:51:16.387171+00	1
998	1	Administrador	DELETE	/75	172.19.0.1	200	2026-07-23 20:51:21.225443+00	1
999	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:51:34.146241+00	1
1000	1	Administrador	POST	/	172.19.0.1	500	2026-07-23 20:51:37.495438+00	1
1001	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:54:48.486977+00	1
1002	1	Administrador	DELETE	/87	172.19.0.1	200	2026-07-23 20:56:35.032537+00	1
1003	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:57:06.9301+00	1
1004	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:58:07.049385+00	1
1005	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:58:21.988272+00	1
1006	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:58:27.81017+00	1
1007	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:58:39.772173+00	1
1008	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 20:58:45.099123+00	1
1009	1	Administrador	DELETE	/90	172.19.0.1	200	2026-07-23 20:58:58.154336+00	1
1010	1	Administrador	POST	/	172.19.0.1	201	2026-07-23 21:03:28.334859+00	1
1011	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 12:58:58.425367+00	1
1012	1	Administrador	PATCH	/79	172.19.0.1	500	2026-08-03 12:59:36.205806+00	1
1013	1	Administrador	PATCH	/79	172.19.0.1	500	2026-08-03 12:59:39.461068+00	1
1014	1	Administrador	PATCH	/79	172.19.0.1	500	2026-08-03 12:59:40.138151+00	1
1015	1	Administrador	PATCH	/79	172.19.0.1	500	2026-08-03 12:59:51.774379+00	1
1016	1	Administrador	DELETE	/79	172.19.0.1	200	2026-08-03 12:59:55.176215+00	1
1017	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 13:01:23.036141+00	1
1018	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-03 13:08:48.197755+00	1
1019	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-03 13:08:49.944576+00	1
1020	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-03 14:04:30.539783+00	1
1021	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:05:36.713556+00	1
1022	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:11:06.537801+00	1
1023	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:11:21.88612+00	1
1024	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:12:00.466452+00	1
1025	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:12:09.737479+00	1
1026	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:12:22.425156+00	1
1027	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:31:18.625493+00	1
1028	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:31:41.109152+00	1
1029	1	Administrador	PATCH	/37/receive	172.19.0.1	200	2026-08-03 14:35:33.844239+00	1
1030	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:36:29.145317+00	1
1031	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:36:32.890513+00	1
1032	1	Administrador	PATCH	/38	172.19.0.1	200	2026-08-03 14:36:48.02698+00	1
1033	1	Administrador	PATCH	/38/receive	172.19.0.1	200	2026-08-03 14:37:02.565613+00	1
1034	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:45:40.035539+00	1
1035	1	Administrador	POST	/	172.19.0.1	201	2026-08-03 14:46:17.14022+00	1
1036	1	Administrador	PATCH	/39	172.19.0.1	200	2026-08-03 14:46:20.50342+00	1
1037	1	Administrador	PATCH	/39	172.19.0.1	200	2026-08-03 14:46:38.810405+00	1
1038	1	Administrador	PATCH	/39/receive	172.19.0.1	200	2026-08-03 14:46:50.833348+00	1
1039	1	Administrador	POST	/5/close	172.19.0.1	200	2026-08-03 14:51:46.987404+00	1
1040	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-03 14:58:43.793183+00	1
1041	1	Administrador	DELETE	/20	172.19.0.1	400	2026-08-03 14:59:05.987323+00	1
1042	1	Administrador	DELETE	/20	172.19.0.1	400	2026-08-03 14:59:07.116012+00	1
1043	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-03 15:35:52.750266+00	1
1044	1	Administrador	POST	/	172.19.0.1	200	2026-08-03 15:39:35.909082+00	1
1045	1	Administrador	DELETE	/	172.19.0.1	200	2026-08-03 15:40:05.580968+00	1
1046	1	Administrador	POST	/open	172.19.0.1	201	2026-08-03 20:25:33.656894+00	1
1047	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-05 13:17:02.862981+00	1
1048	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 13:25:56.379719+00	1
1049	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 13:31:41.33859+00	1
1050	1	Administrador	POST	/84/credit	172.19.0.1	200	2026-08-05 13:31:47.664038+00	1
1051	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 13:49:22.804089+00	1
1052	1	Administrador	PATCH	/85	172.19.0.1	500	2026-08-05 13:49:42.835399+00	1
1053	2	Prueba	POST	/open	172.19.0.1	201	2026-08-05 13:51:10.14691+00	1
1054	2	Prueba	DELETE	/85	172.19.0.1	200	2026-08-05 13:51:21.34066+00	1
1055	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 13:57:11.057606+00	1
1056	1	Administrador	PATCH	/86	172.19.0.1	200	2026-08-05 13:57:42.747536+00	1
1057	1	Administrador	DELETE	/86	172.19.0.1	200	2026-08-05 13:58:58.204448+00	1
1058	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 14:00:38.286862+00	1
1059	1	Administrador	PATCH	/4/cancel	172.19.0.1	200	2026-08-05 14:01:37.993601+00	1
1060	1	Administrador	DELETE	/4	172.19.0.1	200	2026-08-05 14:01:40.083149+00	1
1061	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 14:05:04.529952+00	1
1062	1	Administrador	PATCH	/87	172.19.0.1	200	2026-08-05 14:05:37.76911+00	1
1063	1	Administrador	PATCH	/87	172.19.0.1	200	2026-08-05 14:05:57.087574+00	1
1064	1	Administrador	PATCH	/87	172.19.0.1	200	2026-08-05 14:06:14.946531+00	1
1065	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 14:06:29.102655+00	1
1066	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 14:09:32.116359+00	1
1067	1	Administrador	PATCH	/88	172.19.0.1	200	2026-08-05 14:09:41.379059+00	1
1068	2	Prueba	DELETE	/88	172.19.0.1	200	2026-08-05 14:09:59.670235+00	1
1069	1	Administrador	POST	/	172.19.0.1	200	2026-08-05 14:28:59.134001+00	1
1070	1	Administrador	PUT	/10	172.19.0.1	200	2026-08-05 14:57:35.493354+00	1
1071	1	Administrador	PUT	/10	172.19.0.1	200	2026-08-05 14:57:45.598327+00	1
1072	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 15:35:41.782552+00	1
1073	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 15:36:48.85056+00	1
1074	1	Administrador	PUT	/1/stock/16	172.19.0.1	200	2026-08-05 15:37:50.54534+00	1
1075	1	Administrador	POST	/	172.19.0.1	201	2026-08-05 15:40:03.200845+00	1
1076	1	Administrador	PUT	/1/stock/12	172.19.0.1	200	2026-08-05 15:52:23.030065+00	1
1077	1	Administrador	PUT	/1/stock/24	172.19.0.1	200	2026-08-05 15:52:26.807317+00	1
1078	1	Administrador	PUT	/1/stock/20	172.19.0.1	200	2026-08-05 15:52:44.205596+00	1
1079	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:34:34.437421+00	1
1080	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:34:35.051665+00	1
1081	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:34:45.902303+00	1
1082	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:34:46.939223+00	1
1083	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:34:49.250193+00	1
1084	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:34:49.77446+00	1
1085	1	Administrador	PUT	/	172.19.0.1	200	2026-08-05 16:35:06.932457+00	1
1086	1	Administrador	DELETE	/	172.19.0.1	200	2026-08-05 16:35:10.890316+00	1
1087	1	Administrador	POST	/	172.19.0.1	200	2026-08-05 16:35:11.732431+00	1
1088	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-05 16:47:23.254882+00	1
1089	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:51:43.697629+00	1
1090	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 16:51:44.239964+00	1
1091	1	Administrador	POST	/89/accept-order	172.19.0.1	200	2026-08-05 16:56:05.392125+00	1
1092	1	Administrador	DELETE	/89	172.19.0.1	200	2026-08-05 16:56:24.04416+00	1
1093	1	Administrador	PUT	/12	172.19.0.1	200	2026-08-05 16:56:59.718289+00	1
1094	1	Administrador	PUT	/	172.19.0.1	200	2026-08-05 16:57:52.138208+00	1
1095	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 17:05:06.332338+00	1
1096	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 17:05:07.535966+00	1
1097	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 17:05:10.089423+00	1
1098	1	Administrador	PUT	/23	172.19.0.1	200	2026-08-05 17:05:39.893769+00	1
1099	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 17:05:51.958633+00	1
1100	1	Administrador	PUT	/25	172.19.0.1	200	2026-08-05 17:06:02.617003+00	1
1101	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 17:06:04.111257+00	1
1102	1	Administrador	DELETE	/91	172.19.0.1	200	2026-08-05 17:13:03.438292+00	1
1103	1	Administrador	DELETE	/90	172.19.0.1	200	2026-08-05 17:13:04.410032+00	1
1104	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 18:21:42.995224+00	1
1105	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 18:49:11.284679+00	1
1106	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 18:49:12.189757+00	1
1107	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 18:49:22.07161+00	1
1108	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 19:42:42.396811+00	1
1109	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 19:42:43.437998+00	1
1110	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 19:42:44.03756+00	1
1111	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-05 19:42:44.327186+00	1
1112	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-05 19:47:55.900858+00	1
1113	1	Administrador	PUT	/	172.19.0.1	200	2026-08-06 15:25:16.692176+00	1
1114	1	Administrador	PUT	/	172.19.0.1	200	2026-08-06 15:27:05.453527+00	1
1115	1	Administrador	PUT	/	172.19.0.1	200	2026-08-06 15:27:40.170233+00	1
1116	1	Administrador	PUT	/	172.19.0.1	200	2026-08-06 15:28:20.222568+00	1
1117	1	Administrador	PUT	/	172.19.0.1	200	2026-08-06 15:29:08.695388+00	1
1118	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-06 15:41:21.43163+00	1
1119	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 16:04:44.511635+00	1
1120	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 16:38:04.463759+00	1
1121	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-06 16:39:07.720346+00	1
1122	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-06 16:39:10.088064+00	1
1123	1	Administrador	PATCH	/94	172.19.0.1	200	2026-08-06 16:44:36.73437+00	1
1124	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 16:44:40.153777+00	1
1125	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 16:44:56.687221+00	1
1126	1	Administrador	DELETE	/95	172.19.0.1	200	2026-08-06 16:46:22.055058+00	1
1127	1	Administrador	PATCH	/95	172.19.0.1	404	2026-08-06 16:46:32.8955+00	1
1128	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 16:46:33.032157+00	1
1129	1	Administrador	POST	/96/credit	172.19.0.1	200	2026-08-06 16:46:38.381408+00	1
1130	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 16:54:54.405262+00	1
1131	1	Administrador	POST	/97/claim	172.19.0.1	200	2026-08-06 16:54:57.649763+00	1
1132	1	Administrador	POST	/97/claim	172.19.0.1	200	2026-08-06 16:55:17.16418+00	1
1133	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 17:02:17.600624+00	1
1134	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 17:02:44.866319+00	1
1135	1	Administrador	DELETE	/100	172.19.0.1	200	2026-08-06 17:02:51.415786+00	1
1136	1	Administrador	DELETE	/99	172.19.0.1	200	2026-08-06 17:02:52.464037+00	1
1137	1	Administrador	DELETE	/97	172.19.0.1	200	2026-08-06 17:02:53.262006+00	1
1138	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 17:03:04.872024+00	1
1139	2	Prueba	DELETE	/101	172.19.0.1	200	2026-08-06 17:10:51.805825+00	1
1140	1	Administrador	DELETE	/39	172.19.0.1	200	2026-08-06 17:11:12.183377+00	1
1141	1	Administrador	DELETE	/38	172.19.0.1	200	2026-08-06 17:11:14.252599+00	1
1142	1	Administrador	DELETE	/37	172.19.0.1	200	2026-08-06 17:11:16.060982+00	1
1143	1	Administrador	DELETE	/36	172.19.0.1	200	2026-08-06 17:11:17.67697+00	1
1144	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 17:11:41.388407+00	1
1145	1	Administrador	PATCH	/40/receive	172.19.0.1	200	2026-08-06 17:12:02.968977+00	1
1146	1	Administrador	DELETE	/40	172.19.0.1	200	2026-08-06 17:12:14.157068+00	1
1147	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-06 18:30:01.604288+00	1
1148	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-06 18:30:20.652612+00	1
1149	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 18:35:51.093924+00	1
1150	1	Administrador	POST	/	172.19.0.1	201	2026-08-06 18:37:07.231548+00	1
1151	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-10 12:14:52.012366+00	1
1152	1	Administrador	PUT	/24	172.19.0.1	200	2026-08-10 12:15:34.508535+00	1
1153	1	Administrador	PUT	/10	172.19.0.1	200	2026-08-10 12:15:52.308848+00	1
1154	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:16:16.373473+00	1
1155	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:21:22.931444+00	1
1156	1	Administrador	DELETE	/100	172.19.0.1	200	2026-08-10 12:24:29.122317+00	1
1157	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:25:46.180006+00	1
1158	1	Administrador	DELETE	/101	172.19.0.1	200	2026-08-10 12:26:07.025779+00	1
1159	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:27:01.492697+00	1
1160	1	Administrador	DELETE	/102	172.19.0.1	200	2026-08-10 12:27:30.810061+00	1
1161	1	Administrador	DELETE	/47	172.19.0.1	200	2026-08-10 12:27:35.75041+00	1
1162	1	Administrador	DELETE	/47/permanent	172.19.0.1	200	2026-08-10 12:27:38.557549+00	1
1163	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:29:09.683709+00	1
1164	1	Administrador	PATCH	/41	172.19.0.1	200	2026-08-10 12:34:39.1426+00	1
1165	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:35:11.441056+00	1
1166	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:35:40.661519+00	1
1167	1	Administrador	DELETE	/104	172.19.0.1	200	2026-08-10 12:53:42.862962+00	1
1168	1	Administrador	DELETE	/103	172.19.0.1	200	2026-08-10 12:53:44.345888+00	1
1169	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:54:11.04251+00	1
1170	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:54:20.907137+00	1
1171	1	Administrador	DELETE	/106	172.19.0.1	200	2026-08-10 12:54:37.866991+00	1
1172	1	Administrador	DELETE	/105	172.19.0.1	200	2026-08-10 12:54:39.54311+00	1
1173	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:55:14.335919+00	1
1174	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:55:32.880462+00	1
1175	1	Administrador	DELETE	/108	172.19.0.1	200	2026-08-10 12:56:23.471244+00	1
1176	1	Administrador	DELETE	/107	172.19.0.1	200	2026-08-10 12:56:25.789245+00	1
1177	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 12:56:49.225236+00	1
1178	1	Administrador	DELETE	/48	172.19.0.1	200	2026-08-10 12:57:03.547961+00	1
1179	1	Administrador	DELETE	/48/permanent	172.19.0.1	200	2026-08-10 12:57:05.553176+00	1
1180	1	Administrador	DELETE	/109	172.19.0.1	200	2026-08-10 12:57:23.789296+00	1
1181	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 13:03:32.316327+00	1
1182	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 13:03:47.641063+00	1
1183	1	Administrador	POST	/refresh	172.19.0.1	500	2026-08-10 13:14:40.88608+00	1
1184	1	Administrador	PATCH	/41	172.19.0.1	200	2026-08-10 22:19:14.854181+00	1
1185	1	Administrador	PATCH	/41/receive	172.19.0.1	200	2026-08-10 22:19:26.610884+00	1
1186	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-10 22:23:39.674514+00	1
1187	1	Administrador	DELETE	/41	172.19.0.1	200	2026-08-10 22:24:18.287399+00	1
1188	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:25:37.488315+00	1
1189	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:26:31.875507+00	1
1190	1	Administrador	PATCH	/42	172.19.0.1	200	2026-08-10 22:26:40.646834+00	1
1191	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-10 22:28:30.083393+00	1
1192	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-10 22:30:14.134963+00	1
1193	1	Administrador	PATCH	/42/receive	172.19.0.1	500	2026-08-10 22:30:20.859765+00	1
1194	1	Administrador	PATCH	/42/receive	172.19.0.1	500	2026-08-10 22:30:21.962107+00	1
1195	1	Administrador	PATCH	/42/receive	172.19.0.1	500	2026-08-10 22:30:29.883156+00	1
1196	1	Administrador	PATCH	/42	172.19.0.1	200	2026-08-10 22:30:31.10285+00	1
1197	1	Administrador	PATCH	/42/receive	172.19.0.1	200	2026-08-10 22:30:31.842249+00	1
1198	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-10 22:30:50.85554+00	1
1199	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-10 22:31:00.105624+00	1
1200	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:31:09.25078+00	1
1201	1	Administrador	POST	/104/credit	172.19.0.1	200	2026-08-10 22:33:05.902471+00	1
1202	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:36:10.28937+00	1
1203	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:38:42.86874+00	1
1204	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:50:54.528323+00	1
1205	1	Administrador	PATCH	/46	172.19.0.1	200	2026-08-10 22:53:04.987389+00	1
1206	1	Administrador	PATCH	/46	172.19.0.1	200	2026-08-10 22:53:29.005157+00	1
1207	1	Administrador	DELETE	/46	172.19.0.1	200	2026-08-10 22:54:03.284144+00	1
1208	1	Administrador	DELETE	/42	172.19.0.1	200	2026-08-10 22:54:05.929374+00	1
1209	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:57:44.706899+00	1
1210	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:58:12.075854+00	1
1211	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:58:42.376256+00	1
1212	1	Administrador	DELETE	/114	172.19.0.1	200	2026-08-10 22:59:26.613336+00	1
1213	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 22:59:42.533223+00	1
1214	1	Administrador	DELETE	/115	172.19.0.1	200	2026-08-10 22:59:48.868143+00	1
1215	1	Administrador	DELETE	/113	172.19.0.1	200	2026-08-10 22:59:51.655507+00	1
1216	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:00:05.227832+00	1
1217	1	Administrador	DELETE	/117	172.19.0.1	200	2026-08-10 23:00:17.590622+00	1
1218	1	Administrador	DELETE	/116	172.19.0.1	200	2026-08-10 23:00:19.930542+00	1
1219	1	Administrador	DELETE	/105	172.19.0.1	200	2026-08-10 23:00:25.427818+00	1
1220	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:02:29.745643+00	1
1221	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:03:21.818055+00	1
1222	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:04:21.396569+00	1
1223	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:04:41.883471+00	1
1224	1	Administrador	PATCH	/47	172.19.0.1	200	2026-08-10 23:05:52.895322+00	1
1225	1	Administrador	PATCH	/47/receive	172.19.0.1	200	2026-08-10 23:05:55.794465+00	1
1226	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:21:33.031971+00	1
1227	1	Administrador	PATCH	/48	172.19.0.1	200	2026-08-10 23:21:52.318446+00	1
1228	1	Administrador	PATCH	/48	172.19.0.1	200	2026-08-10 23:22:13.757348+00	1
1229	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:26:23.398195+00	1
1230	1	Administrador	POST	/106/credit	172.19.0.1	200	2026-08-10 23:33:10.364228+00	1
1231	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:33:58.429091+00	1
1232	1	Administrador	DELETE	/106	172.19.0.1	200	2026-08-10 23:34:27.618082+00	1
1233	1	Administrador	PATCH	/48	172.19.0.1	200	2026-08-10 23:36:42.878468+00	1
1234	1	Administrador	PATCH	/48	172.19.0.1	200	2026-08-10 23:36:47.173747+00	1
1235	1	Administrador	PATCH	/48/confirm	172.19.0.1	200	2026-08-10 23:36:50.37988+00	1
1236	1	Administrador	PATCH	/48	172.19.0.1	200	2026-08-10 23:37:26.092614+00	1
1237	1	Administrador	PATCH	/48/receive	172.19.0.1	200	2026-08-10 23:37:34.917386+00	1
1238	1	Administrador	DELETE	/48	172.19.0.1	200	2026-08-10 23:37:44.660854+00	1
1239	1	Administrador	DELETE	/47	172.19.0.1	200	2026-08-10 23:37:47.742073+00	1
1240	1	Administrador	DELETE	/46	172.19.0.1	200	2026-08-10 23:40:34.497338+00	1
1241	1	Administrador	DELETE	/46/permanent	172.19.0.1	200	2026-08-10 23:40:37.265281+00	1
1242	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:50:53.34455+00	1
1243	1	Administrador	DELETE	/51	172.19.0.1	200	2026-08-10 23:51:23.601115+00	1
1244	1	Administrador	DELETE	/51/permanent	172.19.0.1	200	2026-08-10 23:51:26.16575+00	1
1245	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:52:56.764523+00	1
1246	1	Administrador	DELETE	/52	172.19.0.1	200	2026-08-10 23:58:59.863199+00	1
1247	1	Administrador	DELETE	/52/permanent	172.19.0.1	200	2026-08-10 23:59:01.483468+00	1
1248	1	Administrador	POST	/	172.19.0.1	201	2026-08-10 23:59:30.050053+00	1
1249	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:11:52.419769+00	1
1250	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:13:29.710394+00	1
1251	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:14:51.735991+00	1
1252	1	Administrador	DELETE	/120	172.19.0.1	200	2026-08-11 00:24:54.465498+00	1
1253	1	Administrador	DELETE	/119	172.19.0.1	200	2026-08-11 00:25:01.098306+00	1
1254	1	Administrador	PUT	/	172.19.0.1	200	2026-08-11 00:38:38.588768+00	1
1255	1	Administrador	PUT	/	172.19.0.1	200	2026-08-11 00:38:52.012331+00	1
1256	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:39:59.139732+00	1
1257	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:48:13.454599+00	1
1258	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:49:00.809566+00	1
1259	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:50:10.634767+00	1
1260	1	Administrador	POST	/	172.19.0.1	201	2026-08-11 00:51:22.351993+00	1
1261	1	Administrador	PATCH	/49	172.19.0.1	200	2026-08-11 00:55:31.614822+00	1
1262	1	Administrador	PATCH	/49	172.19.0.1	200	2026-08-11 00:56:32.695244+00	1
1263	1	Administrador	PATCH	/49	172.19.0.1	200	2026-08-11 00:57:48.074825+00	1
1264	1	Administrador	PATCH	/49	172.19.0.1	200	2026-08-11 00:59:43.779984+00	1
1265	1	Administrador	PATCH	/49/receive	172.19.0.1	200	2026-08-11 00:59:47.680145+00	1
1266	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-11 01:03:49.364743+00	1
1267	1	Administrador	POST	/	172.19.0.1	201	2026-08-12 19:37:17.827752+00	1
1268	1	Administrador	PATCH	/50/receive	172.19.0.1	200	2026-08-12 19:37:35.682339+00	1
1269	1	Administrador	POST	/	172.19.0.1	400	2026-08-12 19:39:30.295202+00	1
1270	1	Administrador	POST	/	172.19.0.1	201	2026-08-12 19:39:36.989161+00	1
1271	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-12 19:42:08.888278+00	1
1272	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-12 19:42:31.508155+00	1
1273	1	Administrador	PUT	/1/stock/25	172.19.0.1	200	2026-08-12 19:46:29.825368+00	1
1274	1	Administrador	POST	/	172.19.0.1	201	2026-08-12 19:48:29.098078+00	1
1275	1	Administrador	POST	/	172.19.0.1	201	2026-08-12 19:49:02.676072+00	1
1276	1	Administrador	PUT	/25	172.19.0.1	200	2026-08-12 19:55:00.568492+00	1
1277	1	Administrador	PUT	/25	172.19.0.1	200	2026-08-12 19:55:51.652189+00	1
1278	1	Administrador	POST	/7/close	172.19.0.1	200	2026-08-12 19:57:19.156617+00	1
1279	1	Administrador	POST	/open	172.19.0.1	201	2026-08-12 19:57:30.149568+00	1
1280	1	Administrador	POST	/	172.19.0.1	201	2026-08-12 19:57:37.915177+00	1
1281	1	Administrador	POST	/	172.19.0.1	201	2026-08-12 19:57:47.952197+00	1
1282	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-08-13 13:39:33.240184+00	1
1283	1	Administrador	PUT	/1/stock/3	172.19.0.1	200	2026-08-13 13:55:43.488069+00	1
1284	1	Administrador	PUT	/methods/1/toggle	172.19.0.1	200	2026-08-13 14:13:07.652001+00	1
1370	2	prueba	POST	/	172.19.0.1	201	2026-08-19 19:32:08.525509+00	1
1285	1	Administrador	PUT	/methods/1/toggle	172.19.0.1	200	2026-08-13 14:13:12.831674+00	1
1286	1	Administrador	PUT	/	172.19.0.1	200	2026-08-13 14:55:34.124162+00	1
1287	1	Administrador	PUT	/	172.19.0.1	200	2026-08-13 14:55:45.930792+00	1
1288	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-13 15:05:24.127901+00	1
1289	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-13 15:05:24.808786+00	1
1290	1	Administrador	DELETE	/53	172.19.0.1	200	2026-08-13 15:16:14.853873+00	1
1291	1	Administrador	DELETE	/53/permanent	172.19.0.1	200	2026-08-13 15:16:17.246798+00	1
1292	1	Administrador	POST	/	172.19.0.1	201	2026-08-13 18:06:48.711909+00	1
1293	1	Administrador	POST	/	172.19.0.1	201	2026-08-13 18:07:05.232489+00	1
1294	1	Administrador	PUT	/35	172.19.0.1	200	2026-08-13 18:07:22.571704+00	1
1295	1	Administrador	POST	/	172.19.0.1	201	2026-08-13 18:08:10.797086+00	1
1296	1	Administrador	PATCH	/51/receive	172.19.0.1	200	2026-08-13 18:08:47.868446+00	1
1297	1	Administrador	PUT	/35	172.19.0.1	200	2026-08-13 18:09:22.075855+00	1
1298	1	Administrador	DELETE	/51	172.19.0.1	200	2026-08-13 18:09:46.506784+00	1
1299	1	Administrador	POST	/	172.19.0.1	201	2026-08-13 18:10:06.380168+00	1
1300	1	Administrador	PATCH	/52/receive	172.19.0.1	200	2026-08-13 18:10:19.933048+00	1
1301	1	Administrador	POST	/110/accept-order	172.19.0.1	200	2026-08-14 12:48:17.34528+00	1
1302	1	Administrador	POST	/110/claim	172.19.0.1	200	2026-08-14 12:48:18.354242+00	1
1303	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-14 12:48:26.867057+00	1
1304	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-18 15:21:21.995943+00	1
1305	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-18 15:21:29.091721+00	1
1306	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:06.292634+00	1
1307	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:06.400498+00	1
1308	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:06.551054+00	1
1309	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:06.706961+00	1
1310	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:06.892716+00	1
1311	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:07.078811+00	1
1312	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:07.340949+00	1
1313	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:07.56546+00	1
1314	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:07.933708+00	1
1315	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:08.474554+00	1
1316	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-19 12:37:08.93235+00	1
1317	1	Administrador	DELETE	/110	172.19.0.1	200	2026-08-19 12:59:31.277498+00	1
1318	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 12:59:36.94478+00	1
1319	1	Administrador	POST	/114/claim	172.19.0.1	200	2026-08-19 13:00:47.6907+00	1
1320	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 13:00:58.28349+00	1
1321	1	Administrador	PATCH	/114	172.19.0.1	200	2026-08-19 13:01:01.023485+00	1
1322	1	Administrador	POST	/114/claim	172.19.0.1	200	2026-08-19 13:01:02.953129+00	1
1323	1	Administrador	DELETE	/114/claim	172.19.0.1	200	2026-08-19 13:02:48.682193+00	1
1324	1	Administrador	POST	/114/claim	172.19.0.1	200	2026-08-19 13:03:29.54607+00	1
1325	1	Administrador	PATCH	/114	172.19.0.1	200	2026-08-19 13:03:35.453318+00	1
1326	1	Administrador	POST	/114/claim	172.19.0.1	200	2026-08-19 13:03:37.861801+00	1
1327	1	Administrador	PATCH	/114	172.19.0.1	200	2026-08-19 13:03:50.269939+00	1
1328	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 13:04:07.130295+00	1
1329	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 13:12:06.75426+00	1
1330	1	Administrador	DELETE	/115	172.19.0.1	200	2026-08-19 13:13:25.978267+00	1
1331	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 13:45:07.556243+00	1
1332	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-19 13:53:49.280556+00	1
1333	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-19 15:47:03.006669+00	1
1334	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-19 15:47:04.195565+00	1
1335	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-19 15:47:05.046032+00	1
1336	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-19 15:47:05.685868+00	1
1337	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 16:12:55.882935+00	1
1338	1	Administrador	PATCH	/53/receive	172.19.0.1	500	2026-08-19 16:12:57.421935+00	1
1339	1	Administrador	DELETE	/53	172.19.0.1	200	2026-08-19 16:13:28.356467+00	1
1340	1	Administrador	POST	/	172.19.0.1	500	2026-08-19 16:23:22.21142+00	1
1341	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 16:23:23.965487+00	1
1342	1	Administrador	DELETE	/2	172.19.0.1	200	2026-08-19 16:36:21.16481+00	1
1343	1	Administrador	PUT	/roles/3	172.19.0.1	200	2026-08-19 18:23:25.846021+00	1
1344	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 18:50:29.287042+00	1
1345	1	Administrador	PUT	/3/employees	172.19.0.1	200	2026-08-19 18:50:32.181555+00	1
1346	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-08-19 18:51:05.833601+00	1
1347	2	prueba	POST	/1/stock	172.19.0.1	403	2026-08-19 18:52:26.486294+00	1
1348	2	prueba	POST	/1/stock	172.19.0.1	403	2026-08-19 18:52:26.588661+00	1
1349	2	prueba	POST	/transfer	172.19.0.1	403	2026-08-19 18:53:02.637688+00	1
1350	2	prueba	POST	/transfer	172.19.0.1	400	2026-08-19 18:53:02.786576+00	1
1351	2	prueba	POST	/1/sessions	172.19.0.1	403	2026-08-19 18:53:02.902466+00	1
1352	2	prueba	POST	/3/sessions	172.19.0.1	201	2026-08-19 18:53:03.078738+00	1
1353	2	prueba	POST	/	172.19.0.1	403	2026-08-19 18:53:03.229398+00	1
1354	2	prueba	PUT	/3	172.19.0.1	403	2026-08-19 18:53:03.335191+00	1
1355	2	prueba	POST	/	172.19.0.1	403	2026-08-19 18:59:59.680886+00	1
1356	2	prueba	POST	/	172.19.0.1	400	2026-08-19 19:00:00.190853+00	1
1357	2	prueba	POST	/	172.19.0.1	403	2026-08-19 19:00:00.437205+00	1
1358	1	admin	POST	/	172.19.0.1	400	2026-08-19 19:10:19.874039+00	1
1359	1	admin	POST	/	172.19.0.1	200	2026-08-19 19:10:20.150369+00	1
1360	1	admin	PUT	/3/users	172.19.0.1	200	2026-08-19 19:11:18.57245+00	1
1361	1	admin	POST	/	172.19.0.1	500	2026-08-19 19:11:20.497682+00	1
1362	1	admin	PUT	/1	172.19.0.1	400	2026-08-19 19:12:05.298586+00	1
1363	1	admin	DELETE	/3	172.19.0.1	200	2026-08-19 19:13:02.492339+00	1
1364	2	prueba	POST	/	172.19.0.1	400	2026-08-19 19:23:02.184161+00	1
1365	2	prueba	POST	/api/expenses	172.19.0.1	403	2026-08-19 19:23:02.325134+00	1
1366	2	prueba	POST	/	172.19.0.1	201	2026-08-19 19:23:02.601017+00	1
1367	1	admin	POST	/	172.19.0.1	201	2026-08-19 19:23:18.780011+00	1
1368	2	prueba	POST	/	172.19.0.1	400	2026-08-19 19:31:04.280525+00	1
1369	2	prueba	POST	/	172.19.0.1	400	2026-08-19 19:31:53.884518+00	1
1371	1	admin	DELETE	/57	172.19.0.1	200	2026-08-19 19:32:29.854803+00	1
1372	2	prueba	PATCH	/49/confirm	172.19.0.1	403	2026-08-19 19:32:53.207632+00	1
1373	2	prueba	PATCH	/49/receive	172.19.0.1	403	2026-08-19 19:32:53.29953+00	1
1374	2	prueba	PATCH	/49	172.19.0.1	403	2026-08-19 19:32:53.401147+00	1
1375	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-08-19 19:57:29.764062+00	1
1376	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-08-19 19:59:10.318888+00	1
1377	2	prueba	POST	/3/stock	172.19.0.1	200	2026-08-19 20:04:56.779697+00	1
1378	2	prueba	DELETE	/3/stock/1	172.19.0.1	200	2026-08-19 20:04:58.080343+00	1
1379	1	Administrador	PUT	/2	172.19.0.1	200	2026-08-19 20:10:04.253014+00	1
1380	1	admin	POST	/	172.19.0.1	500	2026-08-19 20:14:56.724317+00	1
1381	1	admin	POST	/	172.19.0.1	201	2026-08-19 20:15:58.667764+00	1
1382	1	Administrador	PUT	/35	172.19.0.1	200	2026-08-19 20:19:50.905794+00	1
1383	2	prueba	POST	/api/sales/74/returns	172.19.0.1	404	2026-08-19 20:34:14.953219+00	1
1384	2	prueba	POST	/74/return	172.19.0.1	500	2026-08-19 20:34:39.59644+00	1
1385	2	prueba	POST	/	172.19.0.1	500	2026-08-19 20:34:39.718686+00	1
1386	2	prueba	DELETE	/74	172.19.0.1	500	2026-08-19 20:44:21.228279+00	1
1387	2	prueba	POST	/74/credit	172.19.0.1	403	2026-08-19 20:44:21.392411+00	1
1388	2	prueba	POST	/74/return	172.19.0.1	403	2026-08-19 20:44:21.617973+00	1
1389	2	prueba	POST	/	172.19.0.1	500	2026-08-19 20:44:21.77296+00	1
1390	2	prueba	POST	/49/payments	172.19.0.1	201	2026-08-19 20:44:55.255562+00	1
1391	2	prueba	POST	/49/payments	172.19.0.1	403	2026-08-19 20:47:18.953317+00	1
1392	1	admin	DELETE	/35	172.19.0.1	200	2026-08-19 20:47:19.398246+00	1
1393	2	prueba	POST	/80/claim	172.19.0.1	400	2026-08-19 20:48:26.973021+00	1
1394	2	prueba	PATCH	/80	172.19.0.1	403	2026-08-19 20:48:27.513126+00	1
1395	2	prueba	POST	/80/claim	172.19.0.1	403	2026-08-19 20:52:05.648495+00	1
1396	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 21:00:21.642556+00	1
1397	1	Administrador	POST	/118/credit	172.19.0.1	200	2026-08-19 21:00:41.342269+00	1
1398	1	Administrador	POST	/	172.19.0.1	201	2026-08-19 21:00:49.540303+00	1
1399	1	Administrador	PUT	/2	172.19.0.1	200	2026-08-20 12:38:11.397024+00	1
1400	2	prueba	POST	/	172.19.0.1	403	2026-08-20 12:44:55.018451+00	1
1401	2	prueba	POST	/	172.19.0.1	201	2026-08-20 12:44:55.597847+00	1
1402	2	prueba	PUT	/1	172.19.0.1	403	2026-08-20 12:44:56.948348+00	1
1403	2	prueba	DELETE	/1	172.19.0.1	403	2026-08-20 12:44:57.095307+00	1
1404	1	admin	POST	/	172.19.0.1	201	2026-08-20 12:45:20.720359+00	1
1405	2	prueba	PUT	/7	172.19.0.1	403	2026-08-20 12:45:22.977587+00	1
1406	1	admin	POST	/	172.19.0.1	201	2026-08-20 12:52:44.035035+00	1
1407	1	admin	PUT	/2	172.19.0.1	200	2026-08-20 12:52:44.162997+00	1
1408	2	prueba	PUT	/1	172.19.0.1	403	2026-08-20 12:53:57.330492+00	1
1409	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-20 13:04:18.412434+00	1
1410	1	admin	PUT	/1	172.19.0.1	200	2026-08-20 13:13:24.603721+00	1
1411	1	Administrador	PUT	/2	172.19.0.1	200	2026-08-20 13:15:23.229407+00	1
1412	1	Administrador	POST	/	172.19.0.1	201	2026-08-20 13:15:35.169955+00	1
1413	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-20 13:15:53.472134+00	1
1414	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-20 13:19:08.932715+00	1
1415	2	prueba	POST	/	172.19.0.1	201	2026-08-20 13:21:04.230947+00	1
1416	2	prueba	POST	/	172.19.0.1	201	2026-08-20 13:21:05.333322+00	1
1417	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-08-20 13:22:54.051244+00	1
1418	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-08-20 13:28:29.302227+00	1
1419	1	admin	PUT	/roles/3	172.19.0.1	200	2026-08-20 13:56:59.008341+00	1
1420	2	caja	POST	/	172.19.0.1	400	2026-08-20 13:57:01.504628+00	1
1421	2	caja	DELETE	/74	172.19.0.1	403	2026-08-20 13:57:01.634363+00	1
1422	1	admin	PUT	/3	172.19.0.1	200	2026-08-20 14:39:43.696523+00	1
1423	1	admin	POST	/	172.19.0.1	500	2026-08-20 14:39:43.91896+00	1
1424	1	admin	POST	/	172.19.0.1	400	2026-08-20 14:39:44.157092+00	1
1425	1	admin	POST	/	172.19.0.1	201	2026-08-20 14:40:11.422144+00	1
1426	1	admin	POST	/transfer	172.19.0.1	201	2026-08-20 14:40:11.628224+00	1
1427	1	admin	DELETE	/58	172.19.0.1	200	2026-08-20 14:40:32.121426+00	1
1428	1	admin	POST	/transfer	172.19.0.1	201	2026-08-20 14:40:32.327152+00	1
1429	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 14:41:58.065667+00	1
1430	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 14:42:54.36145+00	1
1431	1	Administrador	POST	/9/close	172.19.0.1	200	2026-08-20 14:50:07.04836+00	1
1432	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 14:50:44.535433+00	1
1433	1	admin	POST	/	172.19.0.1	400	2026-08-20 14:54:22.191556+00	1
1434	1	admin	PUT	/1	172.19.0.1	400	2026-08-20 14:54:22.350961+00	1
1435	1	admin	PUT	/1	172.19.0.1	500	2026-08-20 14:54:22.498594+00	1
1436	1	admin	PUT	/1	172.19.0.1	200	2026-08-20 14:54:48.666525+00	1
1437	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-20 14:56:44.784383+00	1
1438	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-20 14:56:55.948161+00	1
1439	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 14:57:07.120775+00	1
1440	1	Administrador	POST	/open	172.19.0.1	201	2026-08-20 15:10:17.919885+00	1
1441	1	admin	POST	/	172.19.0.1	400	2026-08-20 15:13:24.471595+00	1
1442	1	admin	POST	/	172.19.0.1	201	2026-08-20 15:13:24.792362+00	1
1443	1	Administrador	POST	/	172.19.0.1	200	2026-08-20 15:29:27.718752+00	1
1444	1	Administrador	PUT	/3/employees	172.19.0.1	200	2026-08-20 15:31:02.33526+00	1
1445	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 15:32:53.34068+00	1
1446	1	Administrador	DELETE	/122	172.19.0.1	200	2026-08-20 15:33:05.924404+00	1
1447	1	Administrador	POST	/83/credit	172.19.0.1	200	2026-08-20 15:33:16.792798+00	1
1448	1	Administrador	POST	/80/credit	172.19.0.1	200	2026-08-20 15:33:22.140153+00	1
1449	1	admin	POST	/	172.19.0.1	201	2026-08-20 15:37:32.049264+00	1
1450	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 15:50:32.622846+00	1
1451	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 15:50:44.74986+00	1
1452	1	Administrador	POST	/118/return	172.19.0.1	201	2026-08-20 16:06:17.60007+00	1
1453	1	Administrador	POST	/	172.19.0.1	400	2026-08-20 16:06:17.645262+00	1
1454	1	Administrador	POST	/114/exchange	172.19.0.1	201	2026-08-20 16:14:19.265598+00	1
1455	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-08-20 16:17:52.088539+00	1
1456	1	Administrador	DELETE	/123	172.19.0.1	200	2026-08-20 16:27:04.978909+00	1
1457	1	Administrador	POST	/114/exchange	172.19.0.1	400	2026-08-20 16:27:48.366229+00	1
1458	1	Administrador	POST	/114/exchange	172.19.0.1	400	2026-08-20 16:28:13.822859+00	1
1459	1	Administrador	POST	/114/exchange	172.19.0.1	201	2026-08-20 16:32:12.637333+00	1
1460	1	Administrador	POST	/	172.19.0.1	201	2026-08-20 16:32:38.074045+00	1
1461	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-20 16:32:58.08794+00	1
1462	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-20 16:53:58.77244+00	1
1463	1	Administrador	POST	/	172.19.0.1	200	2026-08-20 16:55:10.547882+00	1
1464	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-20 16:55:20.124622+00	1
1465	1	Administrador	POST	/124/return	172.19.0.1	201	2026-08-20 16:55:32.010218+00	1
1466	1	Administrador	POST	/	172.19.0.1	400	2026-08-20 16:55:32.04519+00	1
1467	1	Administrador	POST	/109/return	172.19.0.1	201	2026-08-20 16:56:30.27981+00	1
1468	1	Administrador	POST	/	172.19.0.1	400	2026-08-20 16:56:30.379278+00	1
1469	1	Administrador	POST	/4/ranges	172.19.0.1	200	2026-08-20 16:57:20.838654+00	1
1470	1	Administrador	PUT	/4/users	172.19.0.1	200	2026-08-20 16:57:23.377734+00	1
1471	1	Administrador	PUT	/4/users	172.19.0.1	200	2026-08-20 16:57:23.819415+00	1
1472	1	Administrador	PUT	/4/users	172.19.0.1	200	2026-08-20 16:57:24.45299+00	1
1473	1	Administrador	PUT	/4/users	172.19.0.1	200	2026-08-20 16:57:24.83199+00	1
1474	1	Administrador	POST	/108/return	172.19.0.1	201	2026-08-20 16:57:46.11187+00	1
1475	1	Administrador	POST	/	172.19.0.1	400	2026-08-20 16:57:46.154813+00	1
1476	1	Administrador	POST	/107/return	172.19.0.1	201	2026-08-20 17:02:54.333524+00	1
1477	1	Administrador	POST	/	172.19.0.1	201	2026-08-20 17:02:54.394555+00	1
1478	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-20 17:59:28.319514+00	1
1479	1	Administrador	PUT	/23/annul	172.19.0.1	200	2026-08-20 18:44:38.436725+00	1
1480	1	Administrador	PUT	/22/annul	172.19.0.1	200	2026-08-20 18:45:19.578641+00	1
1481	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-08-20 18:45:43.037231+00	1
1482	1	Administrador	PUT	/21/annul	172.19.0.1	400	2026-08-20 18:45:56.295103+00	1
1483	1	Administrador	PUT	/19/annul	172.19.0.1	400	2026-08-20 18:46:02.505966+00	1
1484	1	Administrador	PUT	/19/annul	172.19.0.1	400	2026-08-20 18:46:06.126576+00	1
1485	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:46:11.276918+00	1
1486	1	Administrador	PUT	/19/annul	172.19.0.1	400	2026-08-20 18:46:13.554347+00	1
1487	1	Administrador	PUT	/19/annul	172.19.0.1	400	2026-08-20 18:46:14.4382+00	1
1488	1	Administrador	PUT	/15/annul	172.19.0.1	400	2026-08-20 18:46:20.34108+00	1
1489	1	Administrador	PUT	/14/annul	172.19.0.1	400	2026-08-20 18:46:26.510692+00	1
1490	1	Administrador	PUT	/14/annul	172.19.0.1	400	2026-08-20 18:46:29.883695+00	1
1491	1	Administrador	POST	/108/return	172.19.0.1	201	2026-08-20 18:47:06.282913+00	1
1492	1	Administrador	POST	/	172.19.0.1	201	2026-08-20 18:47:06.348666+00	1
1493	1	Administrador	PUT	/28/annul	172.19.0.1	200	2026-08-20 18:47:14.861567+00	1
1494	1	Administrador	DELETE	/124	172.19.0.1	200	2026-08-20 18:48:57.988561+00	1
1495	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:09.050599+00	1
1496	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:12.583061+00	1
1497	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:16.004169+00	1
1498	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:17.011158+00	1
1499	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:17.569581+00	1
1500	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:17.995589+00	1
1501	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:18.370594+00	1
1502	1	Administrador	PUT	/20/annul	172.19.0.1	400	2026-08-20 18:49:19.112061+00	1
1503	1	Administrador	PUT	/16	172.19.0.1	200	2026-08-21 13:03:31.805469+00	1
1504	1	Administrador	PUT	/16	172.19.0.1	200	2026-08-21 13:03:43.257703+00	1
1505	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-21 13:07:07.438936+00	1
1506	1	Administrador	POST	/	172.19.0.1	201	2026-08-21 13:07:37.175921+00	1
1507	1	Administrador	PATCH	/59	172.19.0.1	200	2026-08-21 13:08:04.486125+00	1
1508	1	Administrador	PUT	/16	172.19.0.1	200	2026-08-21 13:09:07.025275+00	1
1509	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-21 13:09:25.346674+00	1
1510	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-21 13:09:26.775457+00	1
1511	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-21 13:09:27.256271+00	1
1512	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-21 13:09:27.91948+00	1
1513	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-21 13:09:28.245404+00	1
1514	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-21 13:09:38.283751+00	1
1515	1	Administrador	PATCH	/59	172.19.0.1	200	2026-08-21 13:24:11.440932+00	1
1516	1	Administrador	POST	/	172.19.0.1	201	2026-08-21 14:45:57.786079+00	1
1517	1	Administrador	POST	/130/credit	172.19.0.1	200	2026-08-21 14:46:33.55402+00	1
1518	1	Administrador	POST	/	172.19.0.1	201	2026-08-21 14:50:10.562979+00	1
1519	1	Administrador	POST	/	172.19.0.1	201	2026-08-21 14:50:20.978317+00	1
1520	1	Administrador	POST	/logo	172.19.0.1	200	2026-08-21 15:25:43.450048+00	1
1521	1	Administrador	PUT	/	172.19.0.1	200	2026-08-21 15:25:44.962641+00	1
1522	1	Administrador	PUT	/	172.19.0.1	200	2026-08-21 15:44:49.458913+00	1
1523	1	Administrador	PUT	/	172.19.0.1	200	2026-08-21 15:45:25.273568+00	1
1524	1	Administrador	PUT	/	172.19.0.1	200	2026-08-21 15:48:10.855014+00	1
1525	1	Administrador	POST	/transfer	172.19.0.1	201	2026-08-21 19:50:45.161575+00	1
1526	1	Administrador	POST	/transfers/14/receive	172.19.0.1	200	2026-08-21 19:51:40.598643+00	1
1527	2	PRUEBA	DELETE	/3	172.19.0.1	403	2026-08-21 20:12:56.048851+00	1
1528	1	Administrador	PUT	/17	172.19.0.1	200	2026-08-21 20:18:06.722994+00	1
1529	1	Administrador	PUT	/28	172.19.0.1	200	2026-08-21 20:19:05.299712+00	1
1530	1	Administrador	PUT	/19	172.19.0.1	200	2026-08-21 20:19:38.194609+00	1
1531	1	Administrador	POST	/1/sessions/10/lines	172.19.0.1	201	2026-08-21 20:19:55.879047+00	1
1532	1	Administrador	POST	/1/sessions/10/lines	172.19.0.1	201	2026-08-21 20:19:59.287579+00	1
1533	1	Administrador	POST	/	172.19.0.1	201	2026-08-21 20:23:13.755698+00	1
1534	1	Administrador	POST	/	172.19.0.1	201	2026-08-21 20:26:01.383422+00	1
1535	1	Administrador	POST	/	172.19.0.1	201	2026-08-21 20:27:27.10555+00	1
1536	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 12:56:26.31465+00	1
1537	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-24 12:56:28.675831+00	1
1538	1	Administrador	DELETE	/59	172.19.0.1	200	2026-08-24 12:56:35.793424+00	1
1539	1	Administrador	DELETE	/59/permanent	172.19.0.1	200	2026-08-24 12:56:37.929872+00	1
1540	1	Administrador	DELETE	/58	172.19.0.1	200	2026-08-24 12:56:42.11403+00	1
1541	1	Administrador	DELETE	/58/permanent	172.19.0.1	200	2026-08-24 12:56:43.828023+00	1
1542	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 12:57:01.555269+00	1
1543	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 12:57:17.594518+00	1
1544	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 12:57:28.475513+00	1
1545	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 15:12:55.987696+00	1
1546	1	Administrador	DELETE	/134	172.19.0.1	200	2026-08-24 15:13:04.806126+00	1
1547	1	Administrador	PUT	/17	172.19.0.1	200	2026-08-24 15:17:26.795284+00	1
1548	1	Administrador	POST	/130/forgive	172.19.0.1	200	2026-08-24 15:21:28.387702+00	1
1549	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 15:24:05.750522+00	1
1550	1	Administrador	POST	/96/forgive	172.19.0.1	200	2026-08-24 15:24:14.359368+00	1
1551	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-24 15:34:35.242702+00	1
1552	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 15:38:40.190485+00	1
1553	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 15:40:17.836387+00	1
1554	1	Administrador	POST	/141/credit	172.19.0.1	200	2026-08-24 15:40:19.298116+00	1
1555	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 15:40:34.334955+00	1
1556	1	Administrador	POST	/142/credit	172.19.0.1	200	2026-08-24 15:40:36.123073+00	1
1557	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 15:58:37.492584+00	1
1558	1	Administrador	POST	/149/credit	172.19.0.1	200	2026-08-24 15:58:40.126167+00	1
1559	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 16:04:15.008707+00	1
1560	1	Administrador	DELETE	/150	172.19.0.1	200	2026-08-24 16:04:42.564134+00	1
1561	1	Administrador	DELETE	/149	172.19.0.1	200	2026-08-24 16:04:44.553743+00	1
1562	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 16:05:27.632521+00	1
1563	1	Administrador	DELETE	/152	172.19.0.1	200	2026-08-24 16:12:59.794291+00	1
1564	1	Administrador	DELETE	/151	172.19.0.1	200	2026-08-24 16:13:07.016592+00	1
1565	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 16:14:49.823505+00	1
1566	1	Administrador	DELETE	/156	172.19.0.1	200	2026-08-24 16:15:02.713812+00	1
1567	1	Administrador	DELETE	/155	172.19.0.1	200	2026-08-24 16:15:08.656779+00	1
1568	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 16:15:34.734848+00	1
1569	1	Administrador	POST	/149/forgive	172.19.0.1	200	2026-08-24 16:19:10.2032+00	1
1570	1	Administrador	DELETE	/batch/34fe407e-3a13-4e3d-8460-f7a0e51bd246	172.19.0.1	200	2026-08-24 16:21:02.658014+00	1
1571	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 16:21:41.268827+00	1
1572	1	Administrador	DELETE	/batch/285d0686-2f81-4058-b8a3-c62614d88855	172.19.0.1	200	2026-08-24 16:27:59.642602+00	1
1573	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 17:29:01.739355+00	1
1574	1	Administrador	POST	/10/close	172.19.0.1	200	2026-08-24 17:30:20.277044+00	1
1575	1	Administrador	POST	/open	172.19.0.1	201	2026-08-24 17:30:22.162132+00	1
1576	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 17:30:40.600953+00	1
1577	1	Administrador	POST	/160/credit	172.19.0.1	200	2026-08-24 17:30:42.989422+00	1
1578	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 17:30:59.299486+00	1
1579	1	Administrador	POST	/161/credit	172.19.0.1	200	2026-08-24 17:31:11.750498+00	1
1580	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 17:32:18.86736+00	1
1581	1	Administrador	DELETE	/batch/8be2ed49-cbbd-4ff1-8ced-4aefade7edf9	172.19.0.1	200	2026-08-24 17:32:36.268447+00	1
1582	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 17:33:45.09574+00	1
1583	1	Administrador	DELETE	/69	172.19.0.1	200	2026-08-24 17:34:01.077148+00	1
1584	1	Administrador	DELETE	/69/permanent	172.19.0.1	200	2026-08-24 17:34:02.937727+00	1
1585	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 17:34:34.932175+00	1
1586	1	Administrador	DELETE	/65	172.19.0.1	200	2026-08-24 17:35:37.24028+00	1
1587	1	Administrador	DELETE	/65/permanent	172.19.0.1	200	2026-08-24 17:35:39.08188+00	1
1588	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 17:46:19.551645+00	1
1589	1	Administrador	POST	/164/credit	172.19.0.1	200	2026-08-24 17:46:48.777672+00	1
1590	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 17:48:40.41855+00	1
1591	1	Administrador	DELETE	/74	172.19.0.1	200	2026-08-24 17:48:54.446365+00	1
1592	1	Administrador	DELETE	/177	172.19.0.1	200	2026-08-24 17:49:02.686001+00	1
1593	1	Administrador	DELETE	/74/permanent	172.19.0.1	200	2026-08-24 17:49:07.111949+00	1
1594	1	Administrador	POST	/164/forgive	172.19.0.1	200	2026-08-24 17:52:14.089427+00	1
1595	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 17:52:38.794586+00	1
1596	1	Administrador	POST	/165/credit	172.19.0.1	200	2026-08-24 18:02:44.554433+00	1
1597	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:03:06.691863+00	1
1598	1	Administrador	POST	/167/credit	172.19.0.1	200	2026-08-24 18:03:08.939051+00	1
1599	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 18:04:19.276103+00	1
1600	1	Administrador	DELETE	/77	172.19.0.1	200	2026-08-24 18:05:25.573604+00	1
1601	1	Administrador	DELETE	/77/permanent	172.19.0.1	200	2026-08-24 18:05:27.170685+00	1
1602	1	Administrador	DELETE	/76	172.19.0.1	200	2026-08-24 18:05:28.807702+00	1
1603	1	Administrador	DELETE	/76/permanent	172.19.0.1	200	2026-08-24 18:05:30.659951+00	1
1604	1	Administrador	DELETE	/batch/628d7408-b5b0-479e-a465-4dc88d1c4ba8	172.19.0.1	200	2026-08-24 18:05:56.390927+00	1
1605	1	Administrador	POST	/bulk	172.19.0.1	201	2026-08-24 18:09:07.840997+00	1
1606	1	Administrador	DELETE	/98	172.19.0.1	200	2026-08-24 18:10:17.144248+00	1
1607	1	Administrador	DELETE	/135	172.19.0.1	200	2026-08-24 18:10:54.48592+00	1
1608	1	Administrador	DELETE	/94	172.19.0.1	200	2026-08-24 18:11:14.670529+00	1
1609	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:31:33.19583+00	1
1610	1	Administrador	POST	/169/credit	172.19.0.1	200	2026-08-24 18:32:53.744389+00	1
1611	1	Administrador	PATCH	/59/receive	172.19.0.1	200	2026-08-24 18:42:02.924969+00	1
1612	1	Administrador	POST	/59/payments	172.19.0.1	201	2026-08-24 18:42:17.283714+00	1
1613	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:43:32.347533+00	1
1614	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:53:01.363933+00	1
1615	1	Administrador	DELETE	/186	172.19.0.1	200	2026-08-24 18:54:11.758731+00	1
1616	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:54:36.304671+00	1
1617	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:55:58.929737+00	1
1618	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:57:56.032675+00	1
1619	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 18:59:18.972467+00	1
1620	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:00:05.118438+00	1
1621	1	Administrador	DELETE	/189	172.19.0.1	200	2026-08-24 19:00:48.612659+00	1
1622	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:01:00.838801+00	1
1623	1	Administrador	DELETE	/190	172.19.0.1	200	2026-08-24 19:01:06.82974+00	1
1624	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:01:53.093651+00	1
1625	1	Administrador	DELETE	/191	172.19.0.1	200	2026-08-24 19:02:13.589511+00	1
1626	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:02:53.454635+00	1
1627	1	Administrador	DELETE	/192	172.19.0.1	200	2026-08-24 19:08:32.414235+00	1
1628	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:11:19.296471+00	1
1629	1	Administrador	DELETE	/36	172.19.0.1	200	2026-08-24 19:37:19.25428+00	1
1630	1	Administrador	POST	/59/payments	172.19.0.1	201	2026-08-24 19:37:28.034516+00	1
1631	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:37:59.651142+00	1
1632	1	Administrador	PATCH	/62	172.19.0.1	200	2026-08-24 19:38:09.211091+00	1
1633	1	Administrador	PATCH	/62/receive	172.19.0.1	200	2026-08-24 19:38:12.131781+00	1
1634	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:39:20.596341+00	1
1635	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:39:27.596109+00	1
1636	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:39:56.990279+00	1
1637	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:40:03.848862+00	1
1638	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:40:28.534145+00	1
1639	1	Administrador	DELETE	/197	172.19.0.1	200	2026-08-24 19:41:03.00609+00	1
1640	1	Administrador	DELETE	/89	172.19.0.1	200	2026-08-24 19:41:08.86891+00	1
1641	1	Administrador	DELETE	/89/permanent	172.19.0.1	200	2026-08-24 19:41:11.507985+00	1
1642	1	Administrador	DELETE	/88	172.19.0.1	200	2026-08-24 19:41:12.920229+00	1
1643	1	Administrador	DELETE	/88/permanent	172.19.0.1	200	2026-08-24 19:41:14.886169+00	1
1644	1	Administrador	POST	/	172.19.0.1	201	2026-08-24 19:41:31.181887+00	1
1645	1	Administrador	DELETE	/198	172.19.0.1	200	2026-08-24 19:48:27.641039+00	1
1646	1	Administrador	POST	/	172.19.0.1	201	2026-08-25 12:21:40.134377+00	1
1647	1	Administrador	POST	/	172.19.0.1	201	2026-08-25 12:22:01.043202+00	1
1648	1	Administrador	POST	/	172.19.0.1	201	2026-08-25 12:22:07.360214+00	1
1649	1	Administrador	DELETE	/178	172.19.0.1	200	2026-08-25 12:53:15.383484+00	1
1650	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 12:53:52.449326+00	1
1651	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 12:53:52.67479+00	1
1652	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 12:53:56.961326+00	1
1653	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 12:53:57.149385+00	1
1654	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 12:54:39.495296+00	1
1655	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 12:54:39.644001+00	1
1656	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 12:54:41.814361+00	1
1657	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 12:54:42.019144+00	1
1658	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 12:55:15.661063+00	1
1659	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 12:55:20.583859+00	1
1660	1	ADMINISTRADOR	POST	/177/claim	172.19.0.1	200	2026-08-25 12:56:35.778819+00	1
1661	1	ADMINISTRADOR	PATCH	/177	172.19.0.1	200	2026-08-25 12:56:35.951041+00	1
1662	1	ADMINISTRADOR	POST	/177/claim	172.19.0.1	200	2026-08-25 12:56:58.447954+00	1
1663	1	ADMINISTRADOR	PATCH	/177	172.19.0.1	200	2026-08-25 12:56:58.63463+00	1
1664	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:01:55.797298+00	1
1665	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:01:56.067286+00	1
1666	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:01:56.329436+00	1
1667	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:01:56.949365+00	1
1668	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-25 13:06:07.528826+00	1
1669	1	Administrador	POST	/refresh	172.19.0.1	200	2026-08-25 13:06:09.567117+00	1
1670	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:16:14.506957+00	1
1671	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:16:14.642522+00	1
1672	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 13:16:16.336915+00	1
1673	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 13:16:16.494934+00	1
1674	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 13:16:25.991757+00	1
1675	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 13:16:26.149913+00	1
1676	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:20:08.171518+00	1
1677	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:20:08.339262+00	1
1678	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:20:10.564335+00	1
1679	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:20:10.774413+00	1
1680	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:20:14.194298+00	1
1681	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:20:14.311981+00	1
1682	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:20:16.028264+00	1
1683	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:20:16.221596+00	1
1684	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:20:17.84429+00	1
1685	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:20:17.926214+00	1
1686	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:43:45.425676+00	1
1687	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:45:26.076497+00	1
1688	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:45:50.80683+00	1
1689	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 13:45:50.976797+00	1
1690	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 13:45:52.761725+00	1
1691	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 13:45:52.973254+00	1
1692	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 13:46:19.630005+00	1
1693	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 13:46:20.129392+00	1
1694	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 13:46:21.396836+00	1
1695	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 13:46:21.612833+00	1
1696	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 13:46:23.691066+00	1
1697	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 13:46:23.849924+00	1
1698	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 13:48:28.39235+00	1
1699	1	Administrador	DELETE	/177/claim	172.19.0.1	200	2026-08-25 13:53:13.252487+00	1
1700	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 14:07:08.005311+00	1
1701	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 14:08:23.61938+00	1
1702	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:10:21.475434+00	1
1703	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:10:51.457119+00	1
1704	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 14:21:45.934499+00	1
1705	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 14:21:46.105324+00	1
1706	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:21:47.249129+00	1
1707	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:21:47.534757+00	1
1708	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:21:50.251775+00	1
1709	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:21:50.495727+00	1
1710	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 14:21:53.794945+00	1
1711	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 14:21:53.94472+00	1
1712	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:21:56.973301+00	1
1713	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:21:57.130013+00	1
1714	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 14:21:58.870622+00	1
1715	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 14:23:09.467535+00	1
1716	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 14:23:38.67446+00	1
1717	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 14:23:38.978762+00	1
1718	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:23:39.884807+00	1
1719	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:23:40.055792+00	1
1720	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:23:44.246547+00	1
1721	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:23:47.677726+00	1
1722	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:24:02.187871+00	1
1723	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:24:02.351387+00	1
1724	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:24:11.978382+00	1
1725	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:24:12.553679+00	1
1726	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:24:16.455831+00	1
1727	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:24:16.851938+00	1
1728	1	Administrador	POST	/176/claim	172.19.0.1	200	2026-08-25 14:24:20.637934+00	1
1729	1	Administrador	PATCH	/176	172.19.0.1	200	2026-08-25 14:24:20.867207+00	1
1730	1	Administrador	DELETE	/176	172.19.0.1	200	2026-08-25 14:24:26.664816+00	1
1731	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 14:47:19.924093+00	1
1732	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 14:47:20.075435+00	1
1733	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 14:47:35.349459+00	1
1734	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 14:47:35.470503+00	1
1735	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 15:40:48.288896+00	1
1736	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 15:40:48.745434+00	1
1737	1	ADMIN	POST	/181/return	172.19.0.1	201	2026-08-25 15:41:14.159578+00	1
1738	1	ADMIN	PUT	/29/annul	172.19.0.1	200	2026-08-25 15:41:41.188757+00	1
1739	1	Administrador	POST	/	172.19.0.1	201	2026-08-25 15:42:35.078619+00	1
1740	1	Administrador	POST	/	172.19.0.1	201	2026-08-25 15:42:37.669815+00	1
1741	1	Administrador	POST	/	172.19.0.1	201	2026-08-25 15:42:54.704978+00	1
1742	1	Administrador	POST	/	172.19.0.1	201	2026-08-25 15:42:56.491586+00	1
1743	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 15:43:39.527443+00	1
1744	1	Administrador	PATCH	/177	172.19.0.1	200	2026-08-25 15:43:39.637574+00	1
1745	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 15:43:41.478683+00	1
1746	1	Administrador	PATCH	/182	172.19.0.1	200	2026-08-25 15:43:41.681233+00	1
1747	1	Administrador	POST	/183/claim	172.19.0.1	200	2026-08-25 15:43:43.951471+00	1
1748	1	Administrador	PATCH	/183	172.19.0.1	200	2026-08-25 15:43:44.068086+00	1
1749	1	Administrador	POST	/183/claim	172.19.0.1	200	2026-08-25 15:44:09.008761+00	1
1750	1	Administrador	PATCH	/183	172.19.0.1	200	2026-08-25 15:44:09.108868+00	1
1751	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 15:44:12.702614+00	1
1752	1	Administrador	PATCH	/182	172.19.0.1	200	2026-08-25 15:44:12.853235+00	1
1753	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 15:45:30.679929+00	1
1754	1	Administrador	PATCH	/182	172.19.0.1	200	2026-08-25 15:45:30.839446+00	1
1755	1	Administrador	POST	/183/claim	172.19.0.1	200	2026-08-25 15:45:33.732343+00	1
1756	1	Administrador	PATCH	/183	172.19.0.1	200	2026-08-25 15:45:33.916474+00	1
1757	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-25 15:46:46.916765+00	1
1758	1	Administrador	PUT	/32	172.19.0.1	200	2026-08-25 15:47:10.417267+00	1
1759	1	Administrador	POST	/183/claim	172.19.0.1	200	2026-08-25 15:48:07.681777+00	1
1760	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 15:49:52.597232+00	1
1761	1	Administrador	POST	/177/claim	172.19.0.1	200	2026-08-25 15:52:42.64975+00	1
1762	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 15:52:49.560057+00	1
1763	1	Administrador	PATCH	/182	172.19.0.1	200	2026-08-25 15:54:25.783997+00	1
1764	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 15:54:32.784294+00	1
1765	1	Administrador	PATCH	/182	172.19.0.1	200	2026-08-25 15:54:32.931068+00	1
1766	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 15:54:50.269339+00	1
1767	1	Administrador	DELETE	/182/claim	172.19.0.1	200	2026-08-25 16:03:36.42914+00	1
1768	1	Administrador	DELETE	/183/claim	172.19.0.1	200	2026-08-25 16:03:37.065631+00	1
1769	1	Administrador	DELETE	/177/claim	172.19.0.1	200	2026-08-25 16:03:37.082816+00	1
1770	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 16:14:40.290537+00	1
1771	1	ADMIN	POST	/	172.19.0.1	201	2026-08-25 16:14:40.630833+00	1
1772	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 16:16:26.632015+00	1
1773	1	Administrador	PATCH	/182	172.19.0.1	200	2026-08-25 16:16:26.787481+00	1
1774	1	Administrador	POST	/183/claim	172.19.0.1	200	2026-08-25 19:23:38.046693+00	1
1775	1	Administrador	PATCH	/183	172.19.0.1	200	2026-08-25 19:23:38.200954+00	1
1776	1	Administrador	POST	/183/claim	172.19.0.1	200	2026-08-25 19:23:38.402546+00	1
1777	1	Administrador	PATCH	/183	172.19.0.1	200	2026-08-25 19:23:40.283192+00	1
1778	1	Administrador	POST	/182/claim	172.19.0.1	200	2026-08-25 19:24:47.886478+00	1
1779	1	Administrador	PATCH	/182	172.19.0.1	200	2026-08-25 19:24:47.977687+00	1
1780	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-27 12:45:25.316674+00	1
1781	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-27 12:45:36.927423+00	1
1782	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-27 12:45:45.489784+00	1
1783	1	ADMIN	POST	/	172.19.0.1	201	2026-08-28 14:40:01.187274+00	1
1784	1	ADMIN	DELETE	/202	172.19.0.1	200	2026-08-28 14:40:24.844894+00	1
1785	1	admin	POST	/	127.0.0.1	201	2026-08-28 17:38:06.734583+00	1
1786	1	admin	DELETE	/5	127.0.0.1	200	2026-08-28 17:38:17.409081+00	1
1787	1	admin	PUT	/1/stock/3/pricing	127.0.0.1	200	2026-08-28 18:18:09.571141+00	1
1788	1	admin	PUT	/3/stock/3/pricing	127.0.0.1	200	2026-08-28 18:18:09.609975+00	1
1789	1	admin	POST	/	127.0.0.1	201	2026-08-28 18:18:40.362508+00	1
1790	1	admin	POST	/	127.0.0.1	201	2026-08-28 18:18:56.848793+00	1
1791	1	admin	POST	/	127.0.0.1	201	2026-08-28 18:18:56.964614+00	1
1792	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 18:18:56.997179+00	1
1793	1	admin	POST	/	127.0.0.1	201	2026-08-28 18:18:57.04471+00	1
1794	1	admin	DELETE	/3	127.0.0.1	200	2026-08-28 18:18:57.054822+00	1
1795	1	admin	PUT	/1/stock/3/pricing	127.0.0.1	200	2026-08-28 18:20:55.017568+00	1
1796	1	admin	PUT	/1/stock/3/pricing	127.0.0.1	200	2026-08-28 18:20:55.177387+00	1
1797	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-28 18:21:11.198889+00	1
1798	1	admin	PUT	/1/stock/3/pricing	127.0.0.1	200	2026-08-28 18:21:29.123045+00	1
1799	1	admin	PUT	/1/stock/3/pricing	127.0.0.1	200	2026-08-28 18:21:29.220072+00	1
1800	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-28 18:24:37.078727+00	1
1801	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-08-28 18:30:06.67437+00	1
1802	1	admin	POST	/	127.0.0.1	201	2026-08-28 18:32:15.160423+00	1
1803	1	admin	PUT	/api/purchases/63	127.0.0.1	404	2026-08-28 18:32:15.205219+00	1
1804	1	admin	PATCH	/63/confirm	127.0.0.1	200	2026-08-28 18:32:25.844787+00	1
1805	1	admin	PATCH	/63/receive	127.0.0.1	200	2026-08-28 18:32:25.931892+00	1
1806	1	admin	POST	/transfer	127.0.0.1	201	2026-08-28 18:32:43.052958+00	1
1807	1	admin	POST	/transfers/18/receive	127.0.0.1	200	2026-08-28 18:32:43.138911+00	1
1808	1	admin	POST	/	127.0.0.1	201	2026-08-28 18:33:07.21686+00	1
1809	1	admin	PATCH	/64/confirm	127.0.0.1	200	2026-08-28 18:33:07.284674+00	1
1810	1	admin	PATCH	/64/receive	127.0.0.1	200	2026-08-28 18:33:07.361339+00	1
1811	1	admin	POST	/	127.0.0.1	201	2026-08-28 18:33:07.463448+00	1
1812	1	Administrador	PUT	/2	172.19.0.1	200	2026-08-28 18:34:28.741394+00	1
1813	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-28 18:45:48.753586+00	1
1814	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-28 18:46:37.802173+00	1
1815	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-28 18:46:53.14947+00	1
1816	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-28 18:54:21.193562+00	1
1817	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-08-28 18:54:25.918519+00	1
1818	1	Administrador	POST	/	172.19.0.1	201	2026-08-28 18:56:22.55199+00	1
1819	1	Administrador	POST	/	172.19.0.1	201	2026-08-28 18:57:10.987273+00	1
1820	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 18:58:38.330841+00	1
1821	1	encargado	PUT	/3	127.0.0.1	200	2026-08-28 18:58:53.782003+00	1
1822	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 18:58:53.893087+00	1
1823	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 19:09:40.800671+00	1
1824	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 19:09:40.928425+00	1
1825	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 19:09:41.022482+00	1
1826	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 19:10:31.707524+00	1
1827	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 19:10:31.904914+00	1
1828	1	Administrador	DELETE	/183	172.19.0.1	200	2026-08-28 19:12:23.714851+00	1
1829	1	Administrador	DELETE	/182	172.19.0.1	200	2026-08-28 19:12:25.152373+00	1
1830	1	Administrador	DELETE	/177	172.19.0.1	200	2026-08-28 19:12:26.78851+00	1
1831	1	cajero	DELETE	/	127.0.0.1	403	2026-08-28 19:23:32.119457+00	1
1832	1	Administrador	PUT	/1	172.19.0.1	200	2026-08-28 19:32:56.724126+00	1
1833	1	Administrador	PUT	/3/employees	172.19.0.1	200	2026-08-28 19:33:02.554959+00	1
1834	1	Administrador	PUT	/3	172.19.0.1	200	2026-08-28 19:33:07.42786+00	1
1835	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 19:35:15.651906+00	1
1836	1	admin	PUT	/3	127.0.0.1	200	2026-08-28 19:35:15.773709+00	1
1837	2	PRUEBA	POST	/trigger	172.19.0.1	200	2026-08-28 19:37:27.057072+00	1
1838	2	PRUEBA	POST	/trigger	172.19.0.1	200	2026-08-28 19:37:30.407894+00	1
1839	2	PRUEBA	PUT	/	172.19.0.1	200	2026-08-28 19:37:47.573936+00	1
1840	1	Administrador	POST	/transfer	172.19.0.1	201	2026-08-28 19:44:13.060482+00	1
1841	2	PRUEBA	POST	/transfers/19/receive	172.19.0.1	200	2026-08-28 19:45:55.981691+00	1
1842	1	gerente	POST	/	127.0.0.1	403	2026-08-31 12:36:34.914976+00	1
1843	1	gerente	PUT	/1	127.0.0.1	403	2026-08-31 12:36:34.937888+00	1
1844	1	gerente	PUT	/3/employees	127.0.0.1	403	2026-08-31 12:36:34.947101+00	1
1845	1	gerente	DELETE	/3	127.0.0.1	403	2026-08-31 12:36:34.954895+00	1
1848	1	cajero	POST	/	127.0.0.1	201	2026-08-31 12:39:47.933168+00	1
1849	1	cajero	DELETE	/4	127.0.0.1	200	2026-08-31 12:39:48.015078+00	1
1850	1	cajero	POST	/	127.0.0.1	403	2026-08-31 12:39:48.03324+00	1
1851	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-31 15:40:01.266895+00	1
1852	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-08-31 15:40:04.933341+00	1
1853	1	admin	POST	/import	127.0.0.1	400	2026-09-02 14:23:18.318247+00	1
1854	1	admin	POST	/import	127.0.0.1	200	2026-09-02 14:23:18.65264+00	1
1855	1	admin	POST	/import	127.0.0.1	200	2026-09-02 14:25:46.829968+00	1
1856	1	ver	POST	/import	127.0.0.1	403	2026-09-02 14:26:15.712068+00	1
1857	1	admin	POST	/import	127.0.0.1	400	2026-09-02 14:32:30.221989+00	1
1858	1	admin	POST	/import	127.0.0.1	200	2026-09-02 14:32:40.697374+00	1
1859	1	admin	POST	/import	127.0.0.1	200	2026-09-02 14:35:42.429549+00	1
1860	1	Administrador	POST	/import	172.19.0.1	200	2026-09-02 14:38:31.994873+00	1
1861	1	Administrador	DELETE	/62	172.19.0.1	400	2026-09-02 14:39:41.264325+00	1
1862	1	Administrador	DELETE	/62	172.19.0.1	200	2026-09-02 14:49:29.799453+00	1
1863	1	Administrador	DELETE	/63	172.19.0.1	200	2026-09-02 14:49:45.597729+00	1
1864	1	admin	POST	/import	127.0.0.1	400	2026-09-02 14:53:23.458259+00	1
1865	1	admin	POST	/import	127.0.0.1	200	2026-09-02 14:53:23.546467+00	1
1866	1	Administrador	POST	/import	172.19.0.1	200	2026-09-02 14:57:37.331831+00	1
1867	1	Administrador	PUT	/65	172.19.0.1	200	2026-09-02 14:57:49.849921+00	1
1868	1	Administrador	POST	/import	172.19.0.1	200	2026-09-02 14:58:38.51934+00	1
1869	1	Administrador	PUT	/65	172.19.0.1	200	2026-09-02 14:58:58.569225+00	1
1870	1	Administrador	PUT	/65	172.19.0.1	200	2026-09-02 14:59:18.152694+00	1
1871	1	Administrador	PUT	/65	172.19.0.1	200	2026-09-02 14:59:28.652623+00	1
1872	1	Administrador	DELETE	/65	172.19.0.1	400	2026-09-02 15:00:34.330565+00	1
1873	1	admin	POST	/import	127.0.0.1	200	2026-09-02 15:00:51.298394+00	1
1874	1	admin	POST	/import	127.0.0.1	400	2026-09-02 15:05:49.07251+00	1
1875	1	admin	POST	/import	127.0.0.1	200	2026-09-02 15:05:50.049136+00	1
1876	1	Administrador	DELETE	/59	172.19.0.1	200	2026-09-02 15:17:53.170206+00	1
1877	1	Administrador	DELETE	/52	172.19.0.1	200	2026-09-02 15:17:55.516182+00	1
1878	1	Administrador	DELETE	/50	172.19.0.1	200	2026-09-02 15:17:57.273876+00	1
1879	1	Administrador	DELETE	/49	172.19.0.1	400	2026-09-02 15:17:58.924712+00	1
1880	1	Administrador	DELETE	/62	172.19.0.1	400	2026-09-02 15:18:01.250484+00	1
1881	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 15:31:05.053508+00	1
1882	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 15:40:32.726759+00	1
1883	1	Administrador	PUT	/28	172.19.0.1	200	2026-09-02 16:28:22.611134+00	1
1884	1	Administrador	DELETE	/220	172.19.0.1	200	2026-09-02 16:29:22.138647+00	1
1885	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 16:55:08.630817+00	1
1886	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 16:56:42.032921+00	1
1887	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 16:57:46.991346+00	1
1888	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 16:58:18.289088+00	1
1889	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 16:58:35.559033+00	1
1890	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 17:00:53.913267+00	1
1891	1	admin	POST	/	127.0.0.1	201	2026-09-02 18:42:13.965881+00	1
1892	1	admin	PATCH	/65/confirm	127.0.0.1	400	2026-09-02 18:42:14.011229+00	1
1893	1	admin	PATCH	/65/receive	127.0.0.1	400	2026-09-02 18:42:14.027752+00	1
1894	1	admin	PATCH	/65	127.0.0.1	200	2026-09-02 18:42:14.07021+00	1
1895	1	admin	PATCH	/65/confirm	127.0.0.1	200	2026-09-02 18:42:14.100853+00	1
1896	1	admin	PUT	/	127.0.0.1	200	2026-09-02 19:17:22.300486+00	1
1897	1	admin	PUT	/	127.0.0.1	200	2026-09-02 19:17:22.389718+00	1
1898	1	Administrador	DELETE	/	172.19.0.1	200	2026-09-02 20:35:41.702706+00	1
1899	1	Administrador	POST	/	172.19.0.1	200	2026-09-02 20:35:42.672945+00	1
1900	1	Administrador	DELETE	/posdb_20260902_140159.sql.gz	172.19.0.1	200	2026-09-02 20:35:56.099583+00	1
1901	1	Administrador	DELETE	/posdb_20260831_123609.sql.gz	172.19.0.1	200	2026-09-02 20:35:56.530976+00	1
1902	1	Administrador	DELETE	/posdb_20260831_123535.sql.gz	172.19.0.1	200	2026-09-02 20:35:56.804158+00	1
1903	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 20:57:40.447014+00	1
1904	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 21:00:07.654169+00	1
1905	1	Administrador	POST	/	172.19.0.1	500	2026-09-02 21:00:07.753133+00	1
1906	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 21:02:47.188738+00	1
1907	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 21:02:47.299886+00	1
1910	1	Administrador	DELETE	/3	172.19.0.1	200	2026-09-02 21:03:27.274458+00	1
1911	1	Administrador	DELETE	/8	172.19.0.1	200	2026-09-02 21:03:27.430624+00	1
1912	1	Administrador	DELETE	/10	172.19.0.1	200	2026-09-02 21:03:27.520959+00	1
1913	1	Administrador	POST	/	172.19.0.1	201	2026-09-02 21:08:15.274974+00	1
1914	1	Administrador	PUT	/	172.19.0.1	200	2026-09-02 21:08:58.952202+00	1
1915	1	Administrador	DELETE	/	172.19.0.1	200	2026-09-02 21:09:12.152141+00	1
1916	1	Administrador	POST	/	172.19.0.1	200	2026-09-02 21:09:13.027776+00	1
1917	1	Administrador	PUT	/24	172.19.0.1	200	2026-09-03 12:44:17.508655+00	1
1918	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 12:44:33.116754+00	1
1919	1	Administrador	PUT	/4	172.19.0.1	200	2026-09-03 12:44:36.87173+00	1
1920	1	Administrador	PUT	/4	172.19.0.1	200	2026-09-03 12:44:37.456998+00	1
1921	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:12.750252+00	1
1922	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:20.957011+00	1
1923	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:23.504912+00	1
1924	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:24.691159+00	1
1925	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:25.267996+00	1
1926	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:32.621971+00	1
1927	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:33.812275+00	1
1928	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:36.739686+00	1
1929	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:37.918669+00	1
1930	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:39.098469+00	1
1931	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:42.682316+00	1
1932	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:43.669626+00	1
1933	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 12:46:45.238353+00	1
1934	1	Administrador	PUT	/7	172.19.0.1	200	2026-09-03 12:50:38.85699+00	1
1935	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 12:50:52.58842+00	1
1936	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 12:51:45.699686+00	1
1937	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:33:07.749457+00	1
1938	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:33:40.984687+00	1
1939	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:33:49.554054+00	1
1940	1	Administrador	PUT	/reorder	172.19.0.1	200	2026-09-03 13:34:02.275639+00	1
1941	1	Administrador	POST	/logo	172.19.0.1	200	2026-09-03 13:34:44.877585+00	1
1942	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:34:54.448441+00	1
1943	1	Administrador	POST	/logo	172.19.0.1	200	2026-09-03 13:36:35.827305+00	1
1944	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:36:39.233002+00	1
1945	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:15.400509+00	1
1946	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:52.011781+00	1
1947	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:55.109422+00	1
1948	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:56.614859+00	1
1949	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:56.95073+00	1
1950	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:57.127912+00	1
1951	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:57.274226+00	1
1952	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:57.41194+00	1
1953	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:57.561635+00	1
1954	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:37:57.676298+00	1
1955	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 13:39:59.2658+00	1
1956	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:43:22.726309+00	1
1957	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:43:38.007837+00	1
1958	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:43:38.622359+00	1
1959	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:49:58.193024+00	1
1960	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:52:26.520985+00	1
1961	1	Administrador	DELETE	/5	172.19.0.1	200	2026-09-03 13:57:07.993311+00	1
1962	1	Administrador	DELETE	/4	172.19.0.1	200	2026-09-03 13:57:09.850533+00	1
1963	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:58:19.814031+00	1
1964	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:58:27.844738+00	1
1965	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:58:30.133645+00	1
1966	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 13:58:43.736959+00	1
1967	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 13:58:43.836218+00	1
1969	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 13:58:52.600626+00	1
1970	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 13:58:58.203782+00	1
1971	1	Administrador	PUT	/68	172.19.0.1	500	2026-09-03 13:59:18.988438+00	1
1972	1	Administrador	PUT	/68	172.19.0.1	500	2026-09-03 13:59:19.175149+00	1
1973	1	Administrador	PUT	/68	172.19.0.1	200	2026-09-03 14:05:08.793042+00	1
1974	1	Administrador	PUT	/68	172.19.0.1	200	2026-09-03 14:05:08.995008+00	1
1975	1	Administrador	PUT	/68	172.19.0.1	200	2026-09-03 14:05:09.137377+00	1
1976	1	Administrador	PUT	/68	172.19.0.1	200	2026-09-03 14:05:09.211296+00	1
1977	1	Administrador	DELETE	/68	172.19.0.1	200	2026-09-03 14:07:03.731491+00	1
1978	1	Administrador	DELETE	/1	172.19.0.1	200	2026-09-03 14:07:03.830286+00	1
1979	1	Administrador	DELETE	/2	172.19.0.1	200	2026-09-03 14:07:03.916895+00	1
1980	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:15:16.733764+00	1
1981	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:15:16.80619+00	1
1982	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:15:17.057042+00	1
1983	1	Administrador	DELETE	/69	172.19.0.1	200	2026-09-03 14:16:46.446376+00	1
1984	1	Administrador	DELETE	/4	172.19.0.1	200	2026-09-03 14:16:46.516181+00	1
1985	1	Administrador	DELETE	/5	172.19.0.1	200	2026-09-03 14:16:46.587664+00	1
1986	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 14:24:37.108949+00	1
1987	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:26:54.891737+00	1
1988	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:27:03.799532+00	1
1989	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:27:17.501352+00	1
1990	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:40:06.036596+00	1
1991	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:40:30.603966+00	1
1992	1	Administrador	POST	/223/return	172.19.0.1	201	2026-09-03 14:40:52.565472+00	1
1993	1	Administrador	POST	/logo	172.19.0.1	200	2026-09-03 14:44:14.323578+00	1
1994	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:44:18.3119+00	1
1995	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:44:51.004868+00	1
1996	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:51:19.373579+00	1
1997	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 14:51:37.356863+00	1
1998	1	Administrador	DELETE	/17	172.19.0.1	400	2026-09-03 14:53:55.652732+00	1
1999	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:55:37.189193+00	1
2000	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:55:41.858761+00	1
2001	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:55:45.870415+00	1
2002	1	Administrador	PUT	/70	172.19.0.1	200	2026-09-03 14:56:05.297947+00	1
2003	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 14:57:43.366977+00	1
2004	1	Administrador	DELETE	/3/stock/17	172.19.0.1	200	2026-09-03 14:57:57.125988+00	1
2005	1	Administrador	DELETE	/3/stock/3	172.19.0.1	200	2026-09-03 14:57:58.797966+00	1
2006	1	Administrador	PUT	/3/stock/70	172.19.0.1	200	2026-09-03 14:58:03.509651+00	1
2007	1	Administrador	PUT	/70	172.19.0.1	200	2026-09-03 14:59:56.885314+00	1
2008	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 15:08:51.924236+00	1
2009	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 15:09:04.070484+00	1
2010	1	Administrador	PUT	/71	172.19.0.1	200	2026-09-03 15:09:14.907218+00	1
2011	1	Administrador	PATCH	/catalog-visibility	172.19.0.1	200	2026-09-03 15:16:53.26793+00	1
2012	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 15:27:09.165261+00	1
2013	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 15:29:54.19533+00	1
2014	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 15:33:30.675234+00	1
2015	1	Administrador	PUT	/6	172.19.0.1	200	2026-09-03 15:40:19.098674+00	1
2016	1	Administrador	PUT	/10	172.19.0.1	200	2026-09-03 15:47:27.191233+00	1
2017	1	Administrador	PUT	/24	172.19.0.1	200	2026-09-03 15:47:32.220417+00	1
2018	1	Administrador	PUT	/1	172.19.0.1	200	2026-09-03 15:47:39.398435+00	1
2019	1	Administrador	PUT	/26	172.19.0.1	200	2026-09-03 15:47:47.330124+00	1
2020	1	Administrador	PUT	/31	172.19.0.1	200	2026-09-03 15:47:55.981481+00	1
2021	1	Administrador	PUT	/1	172.19.0.1	200	2026-09-03 15:53:44.765905+00	1
2022	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 15:55:01.702356+00	1
2023	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 15:55:19.75815+00	1
2024	1	Administrador	PUT	/19	172.19.0.1	200	2026-09-03 15:55:26.72146+00	1
2025	1	Administrador	PUT	/28	172.19.0.1	200	2026-09-03 15:55:30.818954+00	1
2026	1	Administrador	PUT	/25	172.19.0.1	200	2026-09-03 15:55:35.434531+00	1
2027	1	Administrador	PUT	/32	172.19.0.1	200	2026-09-03 15:55:50.339463+00	1
2028	1	Administrador	PUT	/16	172.19.0.1	200	2026-09-03 15:56:29.758235+00	1
2029	1	Administrador	POST	/227/accept-order	172.19.0.1	200	2026-09-03 16:00:45.677308+00	1
2030	1	Administrador	DELETE	/227	172.19.0.1	200	2026-09-03 16:01:02.464559+00	1
2031	1	Administrador	POST	/	172.19.0.1	200	2026-09-03 16:05:38.49256+00	1
2032	1	Administrador	PUT	/2	172.19.0.1	200	2026-09-03 16:32:48.860273+00	1
2033	1	Administrador	PUT	/2	172.19.0.1	200	2026-09-03 16:33:40.687102+00	1
2034	1	Administrador	PUT	/2	172.19.0.1	200	2026-09-03 16:33:53.000459+00	1
2035	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 16:35:15.060705+00	1
2036	1	Administrador	PUT	/35	172.19.0.1	200	2026-09-03 16:46:56.593255+00	1
2037	1	Administrador	PUT	/65	172.19.0.1	200	2026-09-03 16:47:39.728419+00	1
2038	1	Administrador	PUT	/65	172.19.0.1	200	2026-09-03 16:48:27.116335+00	1
2039	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 16:49:44.343611+00	1
2040	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 16:52:07.379974+00	1
2041	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 16:55:57.935138+00	1
2042	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 16:59:49.331202+00	1
2043	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 17:00:21.374183+00	1
2044	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 17:32:42.799279+00	1
2045	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 17:34:32.979537+00	1
2046	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 17:44:47.550572+00	1
2047	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 17:45:12.261593+00	1
2048	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 17:48:30.521575+00	1
2049	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 17:49:54.218364+00	1
2050	1	Administrador	PUT	/2	172.19.0.1	200	2026-09-03 17:52:01.459842+00	1
2051	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 17:54:47.989933+00	1
2052	1	Administrador	POST	/3/sessions	172.19.0.1	201	2026-09-03 17:57:28.216031+00	1
2053	1	Administrador	POST	/3/sessions/13/lines	172.19.0.1	201	2026-09-03 17:57:28.303013+00	1
2054	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-03 17:57:37.03863+00	1
2055	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 18:00:11.752689+00	1
2056	1	Administrador	PUT	/	172.19.0.1	200	2026-09-03 18:01:51.031594+00	1
2057	1	Administrador	PUT	/34	172.19.0.1	200	2026-09-03 20:54:12.71761+00	1
2058	1	Administrador	PUT	/29	172.19.0.1	200	2026-09-03 20:54:42.932686+00	1
2059	1	Administrador	POST	/	172.19.0.1	201	2026-09-03 20:55:37.75405+00	1
2060	1	Administrador	POST	/231/credit	172.19.0.1	200	2026-09-03 20:55:38.818259+00	1
2061	1	Administrador	POST	/230/accept-order	172.19.0.1	200	2026-09-03 21:00:13.008103+00	1
2062	1	Administrador	POST	/230/claim	172.19.0.1	200	2026-09-03 21:00:16.865207+00	1
2063	1	Administrador	PATCH	/230	172.19.0.1	200	2026-09-03 21:00:26.194665+00	1
2064	1	Administrador	DELETE	/230	172.19.0.1	200	2026-09-04 12:36:05.579691+00	1
2065	1	Administrador	POST	/refresh	172.19.0.1	200	2026-09-04 13:17:44.571068+00	1
2066	1	Administrador	PUT	/34	172.19.0.1	200	2026-09-04 13:44:22.724198+00	1
2067	1	Administrador	PUT	/	172.19.0.1	200	2026-09-04 13:49:10.723289+00	1
2068	1	Administrador	PUT	/	172.19.0.1	200	2026-09-04 14:01:34.561817+00	1
2069	1	Administrador	PUT	/	172.19.0.1	200	2026-09-04 14:01:43.668+00	1
2070	1	Administrador	PUT	/	172.19.0.1	200	2026-09-04 14:15:23.986326+00	1
2071	1	Administrador	POST	/	172.19.0.1	201	2026-09-04 15:39:43.796068+00	1
2072	1	Administrador	PUT	/methods/5	172.19.0.1	200	2026-09-04 15:39:59.720799+00	1
2073	1	Administrador	PUT	/methods/5	172.19.0.1	200	2026-09-04 15:40:30.577483+00	1
2074	1	Administrador	DELETE	/232	172.19.0.1	200	2026-09-04 16:14:07.699845+00	1
2075	1	Administrador	POST	/11/close	172.19.0.1	200	2026-09-04 17:01:47.913668+00	1
2076	1	Administrador	POST	/open	172.19.0.1	201	2026-09-04 17:01:55.729985+00	1
2077	1	Administrador	POST	/	172.19.0.1	200	2026-09-04 17:03:06.934522+00	1
2078	1	Administrador	PUT	/9/users	172.19.0.1	200	2026-09-04 17:03:23.399083+00	1
2079	1	Administrador	PUT	/9/users	172.19.0.1	200	2026-09-04 17:03:23.870257+00	1
2080	1	Administrador	PUT	/9/users	172.19.0.1	200	2026-09-04 17:03:24.531139+00	1
2081	1	Administrador	PUT	/9/users	172.19.0.1	200	2026-09-04 17:03:25.528302+00	1
2082	1	Administrador	POST	/9/ranges	172.19.0.1	200	2026-09-04 17:03:31.094986+00	1
2083	1	Administrador	POST	/	172.19.0.1	201	2026-09-04 17:04:56.540962+00	1
2084	1	Administrador	POST	/	172.19.0.1	201	2026-09-04 17:06:11.967138+00	1
2085	1	Administrador	PUT	/roles/3	172.19.0.1	200	2026-09-04 17:28:37.135109+00	1
2086	1	Administrador	PUT	/2	172.19.0.1	200	2026-09-04 17:28:45.484295+00	1
2087	1	Administrador	PUT	/roles/3	172.19.0.1	200	2026-09-04 17:29:39.75202+00	1
2088	1	Administrador	POST	/12/close	172.19.0.1	200	2026-09-04 19:16:18.852472+00	1
2089	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-04 19:43:39.386192+00	1
2090	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-09-04 20:04:48.562938+00	1
2091	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-09-04 20:05:09.956683+00	1
2092	1	Administrador	PUT	/2	172.19.0.1	200	2026-09-04 20:05:23.324628+00	1
2093	1	Administrador	POST	/refresh	172.19.0.1	200	2026-09-04 20:06:27.811647+00	1
2094	1	Administrador	PUT	/3	172.19.0.1	200	2026-09-04 20:09:52.447371+00	1
2095	1	Administrador	POST	/	172.19.0.1	201	2026-09-04 20:10:32.92577+00	1
2096	10	GERENTE A	POST	/	172.19.0.1	201	2026-09-04 20:12:20.737121+00	1
2097	10	GERENTE A	POST	/open	172.19.0.1	201	2026-09-04 20:12:31.919701+00	1
2098	10	GERENTE A	PATCH	/1/credit	172.19.0.1	200	2026-09-04 20:14:52.866523+00	1
\.


--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.banks (id, name, code, active, sort_order, created_at, company_id) FROM stdin;
1	Banco de Venezuela	0102	t	0	2026-05-18 13:53:31.63267+00	1
3	Banco Mercantil	0105	t	2	2026-05-18 13:53:31.63267+00	1
4	BBVA Provincial	0108	t	3	2026-05-18 13:53:31.63267+00	1
2	Efectivo $	efec_$	t	0	2026-05-18 13:53:31.63267+00	1
5	BANCO BS	bs	t	0	2026-08-20 13:15:35.137+00	1
\.


--
-- Data for Name: cash_session_journals; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.cash_session_journals (id, session_id, journal_id, opening_amount, closing_amount, expected_amount, difference, company_id) FROM stdin;
6	4	1	0.00	13450.00	13450.00	0.00	1
7	4	2	0.00	0.00	0.00	0.00	1
10	6	1	0.00	\N	\N	\N	1
11	6	2	0.00	\N	\N	\N	1
8	5	1	0.00	66650.00	66648.30	1.70	1
9	5	2	0.00	0.00	0.00	0.00	1
14	8	1	0.00	\N	\N	\N	1
15	8	2	0.00	\N	\N	\N	1
12	7	1	0.00	0.00	92804.16	-92804.16	1
13	7	2	0.00	0.00	39.51	-39.51	1
16	9	1	2000.00	55551.85	55551.85	0.00	1
17	9	2	0.00	0.00	0.00	0.00	1
18	10	1	0.00	105000.00	104432.28	567.72	1
19	10	2	0.00	22.98	22.80	0.18	1
20	11	1	0.00	40980.00	40980.00	0.00	1
21	11	2	0.00	147.00	147.00	0.00	1
22	12	1	0.00	0.00	0.00	0.00	1
23	12	2	0.00	0.00	0.00	0.00	1
24	13	8	0.00	\N	\N	\N	1
\.


--
-- Data for Name: cash_sessions; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.cash_sessions (id, employee_id, warehouse_id, status, notes, opened_at, closed_at, company_id) FROM stdin;
4	1	1	closed	\N	2026-05-25 18:39:23.678+00	2026-05-25 18:57:23.408+00	1
6	1	\N	open	\N	2026-06-12 18:32:43.632+00	\N	1
5	1	1	closed	\N	2026-05-29 18:18:54.586+00	2026-08-03 14:51:46.958+00	1
8	2	1	open	\N	2026-08-05 13:51:10.048+00	\N	1
7	1	1	closed	\N	2026-08-03 20:25:33.375+00	2026-08-12 19:57:19.125+00	1
9	1	1	closed	\N	2026-08-12 19:57:30.118+00	2026-08-20 14:50:06.944+00	1
10	1	1	closed	\N	2026-08-20 15:10:17.723+00	2026-08-24 17:30:20.184+00	1
11	1	1	closed	\N	2026-08-24 17:30:22.118+00	2026-09-04 17:01:47.868+00	1
12	1	3	closed	\N	2026-09-04 17:01:55.683+00	2026-09-04 19:16:18.797+00	1
13	10	3	open	\N	2026-09-04 20:12:31.89+00	\N	1
\.


--
-- Data for Name: catalog_banners; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.catalog_banners (id, title, image_filename, image_mobile_filename, link_url, alt_text, sort_order, active, company_id, created_at, updated_at) FROM stdin;
6	PROBANDO JAJA	banner_1788447079364_vn1uh9.webp	\N	\N	PRUEBA YA	0	t	1	2026-09-03 14:51:19.365+00	2026-09-03 15:40:19.09+00
\.


--
-- Data for Name: catalog_benefit_tags; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.catalog_benefit_tags (id, name, company_id, created_at, updated_at) FROM stdin;
6	Reparacion	1	2026-09-03 14:55:37.157+00	2026-09-03 14:55:37.157+00
7	Nutricion	1	2026-09-03 14:55:41.847+00	2026-09-03 14:55:41.847+00
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.categories (id, name, color, company_id, image_filename, short_description) FROM stdin;
2	TEST	#4ffb2d	1	\N	\N
6	Víveres	\N	1	\N	\N
7	Charcutería	#fabd2f	1	category_1788439838843_91f652.jpeg	\N
11	POCION	#fabd2f	1	category_1788447463359_6f9mnq.webp	\N
12	SHAMPO	#fabd2f	1	category_1788448144060_7ikqi3.webp	\N
1	LICORES	#2dfb45	1	category_1788450824758_g5i4rq.jfif	CERVEZAS Y BOTELLAS
3	ALMUERZOS	#fabd2f	1	category_1788450901687_9xxb2f.jfif	TODOS NUESTROS PLATOS
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.companies (id, name, tax_id, address, phone, email, active, logo_url, created_at, updated_at, plan_name, subscription_status, expires_at, max_users, catalog_enabled) FROM stdin;
1	Empresa Principal	\N	\N	\N	\N	t	\N	2026-05-18 13:53:32.861285+00	2026-05-18 13:53:32.861285+00	Ilimitado	Activa	\N	0	t
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.currencies (id, code, name, symbol, exchange_rate, is_base, active, updated_at, company_id) FROM stdin;
1	USD	Dólar Americano	Ref.	1.000000	t	t	2026-05-22 14:36:47.077537+00	1
2	VES	Bolívar Venezolano	Bs.	807.386200	f	t	2026-09-04 20:06:27.798764+00	1
\.


--
-- Data for Name: customer_credit_movements; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.customer_credit_movements (id, customer_id, warehouse_id, amount, reason, sale_id, return_id, employee_id, company_id, created_at) FROM stdin;
1	1	\N	12.000000	saldo_inicial	\N	\N	\N	1	2026-09-04 17:30:29.450727+00
2	1	\N	-12.000000	ajuste_manual	\N	\N	10	1	2026-09-04 20:14:52.839+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.customers (id, type, name, phone, email, address, rif, tax_name, tax_regime, notes, created_at, updated_at, company_id, credit_balance) FROM stdin;
2	proveedor	CHINO SASA	\N	\N	3001 Av Lara	V-11111111	\N	\N	\N	2026-05-18 14:34:51.223+00	2026-05-25 19:18:28.496584+00	1	0.000000
3	cliente	LEO	\N	\N	\N	V-31066289	\N	\N	\N	2026-06-10 15:26:11.435+00	2026-08-24 15:56:12.992677+00	1	0.000000
9	cliente	MESA 03	\N	\N	\N	V-03	\N	\N	\N	2026-08-25 15:42:35.057+00	2026-08-25 15:42:35.057+00	1	0.000000
10	cliente	MESA 02	\N	\N	\N	V-02	\N	\N	\N	2026-08-25 15:42:54.686+00	2026-08-25 15:42:54.686+00	1	0.000000
11	cliente	LEOMAR	\N	\N	\N	V-30410687	\N	\N	\N	2026-09-02 15:31:05.032+00	2026-09-02 15:31:05.032+00	1	0.000000
17	cliente	TEST PROMO	04141234567	\N	\N	V-99999999	\N	\N	\N	2026-09-04 13:02:30.158+00	2026-09-04 13:02:30.159+00	1	0.000000
1	cliente	JOSE MUJICA	04261521817	\N	BARQUISIMETO	V-29531224	\N	\N	\N	2026-05-18 14:10:30.24+00	2026-09-04 20:14:52.836158+00	1	0.000000
4	cliente	REBECA RODRIGUEZ	04122429071	\N	\N	V-17572729	\N	\N	\N	2026-08-05 17:11:22.351+00	2026-08-05 17:11:22.351+00	1	0.000000
5	proveedor	LARENSE	\N	\N	\N	J-1	\N	\N	\N	2026-08-10 22:38:42.844+00	2026-08-10 22:38:42.845+00	1	0.000000
6	cliente	MESA 01	\N	\N	\N	V-1	\N	\N	\N	2026-08-19 13:00:58.23+00	2026-08-19 13:00:58.23+00	1	0.000000
\.


--
-- Data for Name: employee_warehouses; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.employee_warehouses (employee_id, warehouse_id, company_id) FROM stdin;
1	1	1
1	3	1
2	1	1
10	3	1
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.employees (id, username, password_hash, full_name, email, phone, role_id, active, created_at, updated_at, is_superuser, company_id) FROM stdin;
1	admin	$2a$10$Z9MxwHHrTrhOCvd.58SMROpIoqqjQ8gGFQEiZGYiWK7DbXYS2moFa	Administrador	admin@mitienda.com	\N	1	t	2026-05-18 13:53:31.63267+00	2026-05-25 18:11:10.766664+00	t	1
2	prueba	$2a$10$PPBrJzhuVA0RMKUAPHgsu.AzBhVQQUdUxdgVlZp3vYYQcNfAAgej2	PRUEBA	\N	\N	2	t	2026-05-25 15:28:08.692+00	2026-09-04 20:05:23.282087+00	f	1
10	gerente	$2a$10$ysYadJQ93OrqU.hUOX8wxuEDFif2m.hMoGdUVsj.MsnesSZrB54Au	GERENTE A	\N	\N	2	t	2026-09-04 20:10:32.9+00	2026-09-04 20:10:32.9+00	f	1
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.expense_categories (id, name, active, company_id) FROM stdin;
1	Servicios Básicos	t	1
2	Alquiler	t	1
3	Nómina / Personal	t	1
4	Impuestos	t	1
5	Mantenimiento	t	1
6	Transporte	t	1
7	Suministros	t	1
8	Otros	t	1
9	Pagos a Proveedores	t	1
10	Cambio / Vuelto	t	1
11	Devolución de Crédito	t	1
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.expenses (id, reference, description, amount, currency_id, rate, category_id, payment_journal_id, employee_id, notes, status, created_at, updated_at, company_id, date, warehouse_id) FROM stdin;
79	\N	Cambio entregado (parte) — cobro conjunto de 2 facturas	1.000000	1	1.000000	10	2	1	Vuelto repartido en 2 cajas	activo	2026-08-24 18:09:07.787+00	2026-08-24 18:09:07.787+00	1	2026-08-24 04:00:00+00	1
80	\N	Cambio entregado (parte) — cobro conjunto de 2 facturas	0.637216	2	784.663300	10	1	1	Vuelto repartido en 2 cajas	activo	2026-08-24 18:09:07.806+00	2026-08-24 18:09:07.806+00	1	2026-08-24 04:00:00+00	1
70	\N	Cambio entregado — cobro conjunto de 2 facturas	0.254886	2	784.663300	10	1	1	\N	activo	2026-08-24 17:33:45.063+00	2026-08-24 17:33:45.063+00	1	2026-08-24 04:00:00+00	1
84	\N	Cambio entregado (parte) — Factura A-0078	2.000000	1	1.000000	10	2	1	Vuelto repartido en 2 cajas	activo	2026-08-24 18:43:32.303+00	2026-08-24 18:43:32.303+00	1	2026-08-24 04:00:00+00	1
85	\N	Cambio entregado (parte) — Factura A-0078	0.662705	2	784.663300	10	1	1	Vuelto repartido en 2 cajas	activo	2026-08-24 18:43:32.322+00	2026-08-24 18:43:32.322+00	1	2026-08-24 04:00:00+00	1
86	\N	Cambio entregado — Factura A-0079	0.637216	2	784.663300	10	1	1	\N	activo	2026-08-24 18:57:56.001+00	2026-08-24 18:57:56.001+00	1	2026-08-24 04:00:00+00	1
87	purchase_payment:37	Pago a proveedor — CHINO SASA (Compra #59)	6.000000	1	1.000000	9	2	1	Ref: #59	activo	2026-08-24 19:37:28.012+00	2026-08-24 19:37:28.012+00	1	2026-08-24 04:00:00+00	1
71	\N	PAGO PROVEEDOR	1.401875	2	784.663300	9	1	1	\N	activo	2026-08-24 17:34:34.906+00	2026-08-24 17:34:34.906+00	1	2026-08-24 04:00:00+00	1
91	\N	Cambio entregado (parte) — Factura A-0086	1.000000	1	1.000000	10	2	1	Vuelto repartido en 2 cajas	activo	2026-09-02 17:00:53.887+00	2026-09-02 17:00:53.887+00	1	2026-09-02 04:00:00+00	1
92	\N	Cambio entregado (parte) — Factura A-0086	0.300000	2	800.000000	10	1	1	Vuelto repartido en 2 cajas	activo	2026-09-02 17:00:53.904+00	2026-09-02 17:00:53.904+00	1	2026-09-02 04:00:00+00	1
\.


--
-- Data for Name: income_categories; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.income_categories (id, name, active, company_id) FROM stdin;
1	Ventas Externas	t	1
2	Transferencia de Cuentas	t	1
3	Préstamo / Capital	t	1
4	Devolución de Proveedor	t	1
5	Comisiones	t	1
6	Otros	t	1
7	Ventas Externas	t	6
8	Transferencia de Cuentas	t	6
9	Préstamo / Capital	t	6
10	Devolución de Proveedor	t	6
11	Comisiones	t	6
12	Otros	t	6
\.


--
-- Data for Name: incomes; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.incomes (id, reference, description, amount, currency_id, rate, category_id, payment_journal_id, employee_id, company_id, notes, status, created_at, updated_at, date, warehouse_id) FROM stdin;
6	\N	Pago 	2.564260	2	779.952200	5	1	1	1	\N	activo	2026-08-24 12:56:26.264+00	2026-08-24 12:56:26.264+00	2026-08-24 04:00:00+00	1
\.


--
-- Data for Name: payment_journals; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.payment_journals (id, name, type, bank_id, currency_id, bank, color, active, sort_order, company_id, warehouse_id) FROM stdin;
2	Caja Divisa	efectivo	2	1	\N	#4ed813	t	0	1	1
1	CAJA BS	efectivo	5	2	\N	#1431c2	t	0	1	1
7	PUNTO DE VENTA BDV	punto_venta	1	2	\N	#0003c7	t	0	1	\N
8	BS EFECTIVO	efectivo	5	2	\N	#6366f1	t	0	1	3
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.payment_methods (id, name, code, color, active, sort_order, created_at, company_id, allows_outflow) FROM stdin;
2	Transferencia	transferencia	#5dade2	t	1	2026-05-18 13:53:31.63267+00	1	t
3	Pago Móvil	pago_movil	#f0a500	t	2	2026-05-18 13:53:31.63267+00	1	t
4	Zelle	zelle	#9b59b6	t	3	2026-05-18 13:53:31.63267+00	1	t
1	Efectivo	efectivo	#27ae60	t	0	2026-05-18 13:53:31.63267+00	1	t
5	Punto de Venta	punto_venta	#e74c3c	t	0	2026-05-18 13:53:31.63267+00	1	f
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.payments (id, sale_id, customer_id, amount, currency_id, exchange_rate, payment_journal_id, employee_id, reference_date, reference_number, notes, created_at, change_given, change_journal_id, company_id, idempotency_key, batch_id) FROM stdin;
85	74	1	12.197079	2	737.881600	1	1	2026-07-23	\N	\N	2026-07-23 20:39:51.341+00	\N	\N	1	\N	\N
173	160	1	2.616161	2	784.663300	1	1	2026-08-24	\N	Cobro conjunto de 2 facturas · Incluye sobrante en caja 0.00	2026-08-24 17:33:45.016+00	0.254886	1	1	2c81f9be-6453-4f6b-8553-e5aa84b2b984-160	2c81f9be-6453-4f6b-8553-e5aa84b2b984
88	76	1	16.756482	2	737.881600	1	1	2026-07-23	\N	\N	2026-07-23 20:57:06.896+00	\N	\N	1	\N	\N
89	77	1	16.756482	2	737.881600	1	1	2026-07-23	\N	\N	2026-07-23 20:58:27.79+00	\N	\N	1	\N	\N
91	78	1	20.328465	2	737.881600	1	1	2026-07-23	\N	\N	2026-07-23 21:03:28.282+00	\N	\N	1	\N	\N
92	81	1	5.341977	2	748.786400	1	1	2026-08-03	\N	\N	2026-08-03 14:11:06.51+00	\N	\N	1	\N	\N
93	81	1	1.005627	2	748.786400	1	1	2026-08-03	\N	\N	2026-08-03 14:11:21.865+00	\N	\N	1	\N	\N
94	82	1	13.354943	2	748.786400	1	1	2026-08-03	\N	\N	2026-08-03 14:12:09.72+00	\N	\N	1	\N	\N
95	82	1	4.229110	2	748.786400	1	1	2026-08-03	\N	\N	2026-08-03 14:12:22.41+00	\N	\N	1	\N	\N
96	87	1	12.197082	2	755.155200	1	1	2026-08-05	\N	\N	2026-08-05 14:06:29.085+00	\N	\N	1	\N	\N
97	84	1	3.351289	2	755.900100	1	1	2026-08-06	\N	\N	2026-08-06 16:04:44.465+00	\N	\N	1	\N	\N
99	102	1	22.000000	1	1.000000	2	1	2026-08-06	\N	\N	2026-08-06 18:37:07.187+00	1.640428	1	1	\N	\N
170	142	1	8.117190	2	784.663300	1	1	2026-08-24	\N	Cobro conjunto de 2 facturas	2026-08-24 17:29:01.668+00	\N	\N	1	06078cf8-d2b9-4dd1-8627-7487a0b8580c-142	06078cf8-d2b9-4dd1-8627-7487a0b8580c
169	141	1	12.910938	2	784.663300	1	1	2026-08-24	\N	Cobro conjunto de 2 facturas	2026-08-24 17:29:01.622+00	0.700938	1	1	06078cf8-d2b9-4dd1-8627-7487a0b8580c-141	06078cf8-d2b9-4dd1-8627-7487a0b8580c
174	161	1	3.246226	2	784.663300	1	1	2026-08-24	\N	Cobro conjunto de 2 facturas	2026-08-24 17:33:45.035+00	\N	\N	1	2c81f9be-6453-4f6b-8553-e5aa84b2b984-161	2c81f9be-6453-4f6b-8553-e5aa84b2b984
182	165	1	16.940000	1	1.000000	2	1	2026-08-24	\N	Cobro conjunto de 2 facturas · Incluye sobrante en caja 0.00	2026-08-24 18:09:07.63+00	1.637216	2	1	36804a01-86f0-41e7-880b-b9bc4dc446c7-165	36804a01-86f0-41e7-880b-b9bc4dc446c7
110	103	1	66.003063	2	757.540600	1	1	2026-08-10	\N	\N	2026-08-10 13:03:32.284+00	\N	\N	1	\N	\N
111	103	1	5.808270	2	757.540600	1	1	2026-08-10	\N	Incluye sobrante de 18.07 (no aplicado a factura)	2026-08-10 13:03:47.623+00	\N	\N	1	\N	\N
112	104	1	16.262730	2	757.560400	1	1	2026-08-10	\N	\N	2026-08-10 22:36:10.267+00	\N	\N	1	\N	\N
60	33	1	-0.380000	1	1.000000	\N	\N	2026-07-20	ANUL-33	Reembolso automático por anulación de factura	2026-07-20 13:44:41.766+00	\N	\N	1	\N	\N
61	31	1	-1.350000	1	1.000000	\N	\N	2026-07-20	ANUL-31	Reembolso automático por anulación de factura	2026-07-20 13:44:51.516+00	\N	\N	1	\N	\N
185	169	1	20.000000	1	1.000000	2	1	2026-08-24	\N	\N	2026-08-24 18:43:32.268+00	2.662705	2	1	bd83678c-8855-4609-8d4f-0dc5cea7194a	\N
183	167	1	3.060000	1	1.000000	2	1	2026-08-24	\N	Cobro conjunto de 2 facturas	2026-08-24 18:09:07.686+00	\N	\N	1	36804a01-86f0-41e7-880b-b9bc4dc446c7-167	36804a01-86f0-41e7-880b-b9bc4dc446c7
121	107	1	12.197053	2	760.000000	1	1	2026-08-10	\N	\N	2026-08-11 00:39:59.096+00	\N	\N	1	\N	\N
122	108	1	8.141026	2	780.000000	1	1	2026-08-12	\N	Incluye sobrante de 7.52 (no aplicado a factura)	2026-08-12 19:49:02.655+00	\N	\N	1	\N	\N
123	109	1	8.141026	2	780.000000	1	1	2026-08-12	\N	Incluye sobrante de 7.52 (no aplicado a factura)	2026-08-12 19:57:47.934+00	\N	\N	1	\N	\N
187	96	1	20.000000	1	1.000000	2	1	2026-08-24	\N	Incluye sobrante de 0.20 (no aplicado a factura)	2026-08-24 18:54:36.276+00	\N	\N	1	0e81ddf4-8745-47ac-bcfe-9ade11eaecc1	\N
125	114	1	40.656914	2	773.312500	1	1	2026-08-19	\N	\N	2026-08-19 13:04:07.07+00	\N	\N	1	\N	\N
188	171	1	21.000000	1	1.000000	2	1	2026-08-24	\N	\N	2026-08-24 18:57:55.961+00	0.637216	1	1	2d2600a8-b5c3-4558-a040-d3a0c3004416	\N
128	118	1	20.328423	2	775.335600	1	1	2026-08-19	\N	\N	2026-08-19 21:00:49.505+00	\N	\N	1	fe63334a-d9b5-4894-aaa3-abc4d3ba92fd	\N
132	131	1	82.595831	2	779.952200	1	1	2026-08-21	\N	\N	2026-08-21 14:50:20.937+00	\N	\N	1	61723885-842b-436c-89d8-d9df9823a0b9	\N
133	132	1	10.399971	2	779.952200	1	1	2026-08-21	\N	\N	2026-08-21 20:27:27.07+00	\N	\N	1	aacf12d1-46ba-4e48-a854-c4aaf81b1a7c	\N
134	133	1	20.327190	2	784.663300	1	1	2026-08-24	\N	\N	2026-08-24 12:57:28.445+00	\N	\N	1	480da7e9-67d7-4b8b-b363-fd34b20d842d	\N
194	172	1	5.000000	1	1.000000	2	1	2026-08-24	\N	\N	2026-08-24 19:11:19.273+00	\N	\N	1	e6cd093a-05cd-46fd-8022-c84f4d7c3c0d	\N
195	174	1	30.000000	1	1.000000	2	1	2026-08-24	\N	\N	2026-08-24 19:39:27.574+00	\N	\N	1	40f2d80d-1eae-4298-b853-443c3a49dcc8	\N
196	175	1	30.000000	1	1.000000	2	1	2026-08-24	\N	\N	2026-08-24 19:40:03.827+00	\N	\N	1	f5f1eb74-e136-4b15-bcd8-457b6895e8bd	\N
141	80	1	1.330000	1	1.000000	2	1	2026-08-24	\N	Cobro conjunto de 2 facturas	2026-08-24 15:38:40.112+00	\N	\N	1	4d932d8e-d448-4f50-b8af-1db23b5fbe04-80	4d932d8e-d448-4f50-b8af-1db23b5fbe04
142	83	1	1.670000	1	1.000000	2	1	2026-08-24	\N	Cobro conjunto de 2 facturas	2026-08-24 15:38:40.166+00	\N	\N	1	4d932d8e-d448-4f50-b8af-1db23b5fbe04-83	4d932d8e-d448-4f50-b8af-1db23b5fbe04
203	188	1	36.000000	2	795.000000	1	1	2026-08-28	\N	\N	2026-08-28 18:57:10.94+00	\N	\N	1	8e1a0904-aaca-4fbc-b9c3-f400f115f711	\N
215	221	1	1.025000	2	800.000000	1	1	2026-09-02	\N	Incluye sobrante de 4.36 (no aplicado a factura)	2026-09-02 16:56:42.001+00	\N	\N	1	ef5d4627-093b-47f4-999d-7cb3173829d0	\N
216	222	1	11.000000	1	1.000000	2	1	2026-09-02	\N	Incluye sobrante de 0.80 (vuelto redondeado, no aplicado a factura)	2026-09-02 16:58:18.265+00	\N	\N	1	d1193fed-9f56-4ec3-8617-bbe8cc55dcbd	\N
217	223	1	12.500000	2	800.000000	1	1	2026-09-02	\N	\N	2026-09-02 17:00:53.788+00	1.300000	2	1	e78de2f2-f717-4351-b88f-835aa7f972da	\N
218	233	1	50.000855	2	807.386200	7	1	2026-09-04	\N	Incluye sobrante de 0.68 (no aplicado a factura)	2026-09-04 17:06:11.936+00	\N	\N	1	0c903965-11ee-4e14-a3b1-3ae43785ecda	\N
\.


--
-- Data for Name: product_benefit_tags; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.product_benefit_tags (product_id, benefit_tag_id) FROM stdin;
\.


--
-- Data for Name: product_combo_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.product_combo_items (id, combo_id, product_id, quantity, company_id) FROM stdin;
33	22	21	16.000	1
38	19	28	24.000	1
39	29	34	1.000	1
\.


--
-- Data for Name: product_lots; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.product_lots (id, product_id, warehouse_id, lot_number, expiration_date, qty, created_at, updated_at, company_id) FROM stdin;
\.


--
-- Data for Name: product_stock; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.product_stock (warehouse_id, product_id, qty, company_id, price, min_stock, cost_price) FROM stdin;
1	19	0.000	1	\N	\N	22.3512
1	16	2.000	1	6.00000	\N	\N
1	35	0.000	1	\N	\N	0.0000
3	71	2.000	1	\N	\N	\N
1	29	0.000	1	2.60000	\N	2.0000
1	65	48.000	1	1.08000	\N	0.8333
1	34	9.700	1	0.00000	\N	\N
3	70	8.000	1	\N	\N	\N
1	12	140.000	1	\N	\N	\N
1	21	0.000	1	\N	\N	\N
1	22	0.000	1	\N	\N	\N
1	23	0.000	1	\N	\N	\N
1	1	8.000	1	\N	\N	\N
1	27	0.000	1	\N	\N	\N
1	26	12.000	1	\N	\N	\N
1	30	12.000	1	\N	\N	\N
1	31	24.000	1	\N	\N	\N
1	32	12.000	1	\N	\N	\N
1	24	9.000	1	\N	\N	\N
1	20	10.000	1	\N	\N	\N
1	25	5.000	1	\N	\N	\N
1	10	36.000	1	\N	\N	\N
1	28	76.000	1	\N	100.000	\N
1	17	2381.000	1	\N	\N	\N
1	3	254.000	1	\N	\N	\N
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.products (id, name, price, stock, unit, qty_step, category_id, image_filename, cost_price, profit_margin, min_stock, package_size, package_unit, created_at, updated_at, is_service, is_combo, barcode, company_id, bulk_price, visible_in_catalog, sellable, brand, short_description, description) FROM stdin;
10	AZUCAR	1.62500	36.000	UNIDAD	1.000	6	product_1786364152281.webp	1.2500	30.00	0.000	24.000	BULTO	2026-05-29 15:47:14.676358+00	2026-09-03 15:47:27.11234+00	f	f	\N	1	30.00000	t	t	\N	\N	\N
26	mayonesa kemy 445g 	2.70200	12.000	UNIDAD	1.000	6	\N	2.4125	12.00	0.000	12.000	BULTO	2026-08-10 22:25:37.470266+00	2026-09-03 15:47:47.30871+00	f	f	\N	1	28.95000	t	t	\N	\N	\N
34	SACO DE CARAOTA	2.60000	9.700	KG	1.000	\N	\N	2.0000	30.00	0.000	50.000	SACO	2026-08-13 18:06:48.674399+00	2026-09-04 13:44:22.666362+00	f	f	\N	1	100.00000	f	f	\N	\N	\N
31	MAYONESA MAVESA 175G	2.43750	24.000	UNIDAD	1.000	6	\N	1.8750	30.00	0.000	24.000	CAJA	2026-08-11 00:49:00.793216+00	2026-09-03 15:47:55.968916+00	f	f	\N	1	45.00000	t	t	\N	\N	\N
28	CERVEZA DE LATA	1.50000	76.000	UNIDAD	1.000	1	product_1787343545248.jfif	0.9313	61.07	0.000	24.000	CAJA	2026-08-10 23:03:21.792983+00	2026-09-03 15:55:30.790233+00	f	f	\N	1	22.35000	t	t	\N	\N	\N
25	COCA COLA 2L	1.50000	5.000	UNIDAD	1.000	1	product_1785949562601.jpg	1.0000	30.00	10.000	6.000	BULTO	2026-08-03 14:46:17.127281+00	2026-09-03 15:55:35.398126+00	f	f	\N	1	6.00000	t	t	\N	\N	\N
32	POLLO BROSTER	7.00000	12.000	UNIDAD	1.000	3	product_1787672830401.jpg	3.7642	85.96	0.000	12.000	CAJA	2026-08-11 00:50:10.61895+00	2026-09-03 15:55:50.27736+00	f	f	\N	1	45.17000	t	t	\N	\N	\N
29	CARAOTA DETALLADA	2.60000	0.000	KG	1.000	\N	\N	0.9021	30.00	0.000	24.000	PAQUETE	2026-08-10 23:04:21.378845+00	2026-09-04 13:44:22.666362+00	f	t	\N	1	21.65000	t	t	\N	\N	\N
16	BICTECK SALTEADO	0.00000	2.000	KG	1.000	3	product_1788450989734.jfif	5.0000	\N	0.000	10.000	UNIDAD	2026-06-12 18:27:31.725804+00	2026-09-03 16:01:02.37461+00	f	f	\N	1	50.00000	t	t	\N	\N	\N
35	PURE CON ESALADA RUSA	1.50000	0.000	UNIDAD	1.000	3	product_1788454016567.jfif	\N	50.00	0.000	\N	\N	2026-08-13 18:07:05.214449+00	2026-09-03 16:46:56.563343+00	f	f	\N	1	\N	t	t	\N	\N	\N
70	Poción Go	25.00000	8.000	UNIDAD	1.000	11	product_1788447365277.webp	\N	\N	0.000	\N	\N	2026-09-03 14:55:45.835248+00	2026-09-04 17:04:56.421518+00	f	f	\N	1	\N	t	t	Pocion	+Reparación +Nutrición	Poción Go es la versión portátil de nuestro icónico Kit de Reparación. Incluye 4 sachets de 60 ml (Shampoo, Tratamiento, Mascarilla Ancestral y Crema para Peinar Dual) ideales para llevar en viajes, escapadas o probar el sistema completo de reparación donde quieras. Su tamaño compacto cumple con las normativas de líquidos para vuelos, haciéndolo perfecto para equipaje de mano.
3	MILANESA PARMESANA	6.00000	254.000	UNIDAD	1.000	3	product_1788457794197.png	3.0000	100.00	30.000	1.000	UNIDAD	2026-05-18 14:34:01.475608+00	2026-09-03 17:54:47.962255+00	f	f	00002	1	3.00000	t	t	\N	\N	\N
12	PAPEL ALISOF	0.58906	140.000	UNIDAD	1.000	\N	product_1781792023254.jpg	0.4531	30.00	0.000	48.000	BULTO	2026-06-09 20:06:36.565966+00	2026-09-03 15:16:53.254178+00	f	f	\N	1	21.75000	t	t	\N	\N	\N
17	CERVEZA	1.01955	2381.000	UNIDAD	1.000	2	product_1787343486658.jpg	0.6389	59.58	0.000	36.000	CAJA	2026-06-12 18:28:07.644929+00	2026-09-03 15:16:53.254178+00	f	f	\N	1	23.00000	t	t	\N	\N	\N
21	Pañal	0.56542	0.000	UNIDAD	1.000	\N	\N	0.4792	18.00	0.000	96.000	BULTO	2026-07-20 13:08:56.74184+00	2026-09-03 15:16:53.254178+00	f	f	1	1	46.00000	t	t	\N	\N	\N
30	MAYONESA KRAFT 445GR	4.55000	12.000	UNIDAD	1.000	\N	\N	3.5000	30.00	0.000	12.000	CAJA	2026-08-11 00:48:13.408169+00	2026-09-03 15:16:53.254178+00	f	f	\N	1	42.00000	t	t	\N	\N	\N
22	Paquete de Pañal	9.05000	0.000	UNIDAD	1.000	\N	\N	\N	18.00	0.000	\N	\N	2026-07-20 13:24:37.280433+00	2026-09-03 15:16:53.254178+00	f	t	2	1	\N	t	t	\N	\N	\N
23	PASTA CORTA	3.90000	0.000	UNIDAD	1.000	\N	product_1785949539856.jpg	3.0000	30.00	0.000	12.000	BULTO	2026-08-03 14:31:18.591511+00	2026-09-03 15:16:53.254178+00	f	f	\N	1	36.00000	t	t	\N	\N	\N
65	PASTICHO EJECUTIVO	1.85000	48.000	UNIDAD	1.000	3	product_1788454059709.jfif	1.2000	54.17	12.000	24.000	BULTO	2026-09-02 14:57:37.293305+00	2026-09-04 12:36:05.521631+00	f	f	7591234567890	1	20.00000	t	t	\N	\N	PASTICHO DE CARNE MOLIDA + PAN AL AJILLO
27	SUERO MI FINCA	1.71600	0.000	UNIDAD	1.000	\N	\N	1.3200	30.00	0.000	1.000	UNIDAD	2026-08-10 23:02:29.679462+00	2026-09-03 15:16:53.254178+00	f	f	\N	1	1.32000	t	t	\N	\N	\N
20	corte de cabello	10.00000	10.000	UNIDAD	1.000	\N	\N	\N	\N	0.000	\N	\N	2026-06-12 18:57:09.408999+00	2026-09-03 15:16:53.254178+00	t	f	\N	1	\N	t	t	\N	\N	\N
24	CAFE AMANECER	2.60000	9.000	UNIDAD	1.000	6	product_1786364134413.webp	2.0000	30.00	0.000	1.000	UNIDAD	2026-08-03 14:36:29.126505+00	2026-09-03 15:47:32.192127+00	f	f	\N	1	2.00000	t	t	AMANECER	CAFE DE 50GR	\N
1	Harina Pan	1.67565	8.000	UNIDAD	1.000	6	product_1781789347323.webp	1.3000	28.90	20.000	20.000	BULTO	2026-05-18 14:07:12.984569+00	2026-09-03 15:47:39.377215+00	f	f	00001	1	26.00000	t	t	\N	\N	\N
19	CAJA DE CERVEZA LATA	36.00000	0.000	UNIDAD	1.000	1	product_1787343578150.jfif	\N	61.07	0.000	\N	\N	2026-06-12 18:55:33.798654+00	2026-09-03 15:55:26.695621+00	f	t	\N	1	\N	t	t	\N	\N	\N
71	Shampoo Biorepolarizador	15.00000	2.000	UNIDAD	1.000	12	product_1788448131885.webp	\N	\N	0.000	\N	\N	2026-09-03 15:08:51.886348+00	2026-09-03 17:57:28.273096+00	f	f	\N	1	\N	t	t	MILAGROS	+Nutricion +Brillo	Reparación profunda, crecimiento y brillo en cada lavado\r\n\r\nDevuélvele la vida a tu cabello con el Shampoo Bio-Repolarizador Capilar de Milagros, una fórmula avanzada diseñada para reconstruir, fortalecer y revitalizar el cabello dañado desde la raíz hasta las puntas.\r\n\r\nIdeal para cabellos maltratados por tintes, decoloraciones, calor o procesos químicos, este shampoo actúa profundamente en la fibra capilar, ayudando a recuperar su salud, suavidad y brillo natural desde la primera aplicación.
33	AZUCAR DETALLADA	1.00000	0.000	UNIDAD	1.000	\N	\N	\N	\N	0.000	\N	\N	2026-08-12 19:39:36.975217+00	2026-08-12 19:39:36.975+00	f	f	\N	1	\N	f	t	\N	\N	\N
\.


--
-- Data for Name: promotion_products; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.promotion_products (promotion_id, product_id) FROM stdin;
2	17
2	28
\.


--
-- Data for Name: promotions; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.promotions (id, name, type, discount_pct, buy_qty, get_qty, starts_at, ends_at, active, company_id, created_at, updated_at, warehouse_id) FROM stdin;
2	12 cervezas por 10	buy_x_get_y	\N	10	2	2026-08-21 00:00:00+00	2026-09-24 00:00:00+00	t	1	2026-08-21 20:23:13.709+00	2026-09-03 16:33:52.984+00	1
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.purchase_items (id, purchase_id, product_id, product_name, package_unit, package_qty, package_size, package_price, unit_cost, profit_margin, sale_price, total_units, subtotal, lot_number, expiration_date, update_price) FROM stdin;
145	49	12	PAPEL ALISOF	BULTO	3.000	48.000	21.75000	0.45313	30.00	0.58906	144.000	65.25000	\N	\N	t
146	49	26	mayonesa kemy 445g 	BULTO	1.000	12.000	28.95000	2.41250	12.00	2.70200	12.000	28.95000	\N	\N	t
147	49	30	MAYONESA KRAFT 445GR	CAJA	1.000	12.000	42.00000	3.50000	30.00	4.55000	12.000	42.00000	\N	\N	t
148	49	31	MAYONESA MAVESA 175G	CAJA	1.000	24.000	45.00000	1.87500	30.00	2.43750	24.000	45.00000	\N	\N	t
149	49	32	MAYONESA MAVESA 445	CAJA	1.000	12.000	45.17000	3.76417	30.00	4.89342	12.000	45.17000	\N	\N	t
164	62	17	CERVEZA	CAJA	96.000	36.000	23.00000	0.63889	59.58	1.01955	3456.000	2208.00000	\N	\N	t
\.


--
-- Data for Name: purchase_payments; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.purchase_payments (id, purchase_id, amount, currency_id, exchange_rate, payment_journal_id, employee_id, reference_date, reference_number, notes, created_at, company_id) FROM stdin;
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.purchases (id, supplier_id, supplier_name, notes, total, employee_id, warehouse_id, created_at, payment_status, company_id, status, currency_id, exchange_rate) FROM stdin;
49	5	LARENSE	\N	226.37	1	1	2026-08-11 00:51:22.284+00	pendiente	1	recibido	2	757.540700
62	2	CHINO SASA	\N	2208.00	1	1	2026-08-24 19:37:59.594+00	pendiente	1	recibido	2	784.663300
\.


--
-- Data for Name: quotation_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.quotation_items (id, quotation_id, product_id, product_name, quantity, price, subtotal) FROM stdin;
3	3	3	Harina Juana	3.0000	1.3500	4.05
5	5	1	Harina Pan	5.0000	1.6757	8.38
6	5	3	Harina Juana	3.0000	4.0657	12.20
7	5	16	Carne Molida	1.0000	4.0657	4.07
8	6	3	Harina Juana	8.0000	4.0657	32.53
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.quotations (id, customer_id, customer_name, customer_rif, employee_id, warehouse_id, currency_id, exchange_rate, discount_amount, subtotal, total, status, notes, converted_sale_id, company_id, created_at, updated_at) FROM stdin;
3	1	JOSE MUJICA	V-29531224	1	1	1	1.000000	0.00	4.05	4.05	convertida	\N	41	1	2026-07-20 14:02:15.646+00	2026-07-20 14:02:41.624+00
5	1	JOSE MUJICA	V-29531224	1	1	1	1.000000	0.00	24.65	24.65	pendiente	\N	\N	1	2026-08-05 14:00:38.258+00	2026-08-05 14:00:38.258+00
6	1	JOSE MUJICA	V-29531224	1	1	2	773.312500	0.00	32.53	32.53	pendiente	\N	\N	1	2026-08-19 13:45:07.488+00	2026-08-19 13:45:07.488+00
\.


--
-- Data for Name: return_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.return_items (id, return_id, product_id, name, price, qty, subtotal, sale_item_id, company_id) FROM stdin;
10	10	3	Harina Juana	1.35000	1.000	1.350000	44	1
11	11	3	Harina Juana	1.35000	5.000	6.750000	46	1
12	12	3	Harina Juana	1.35000	5.000	6.750000	47	1
13	13	3	Harina Juana	1.35000	6.000	8.100000	49	1
14	14	3	Harina Juana	1.35000	10.000	13.500000	57	1
15	15	3	Harina Juana	4.06570	5.000	20.330000	146	1
16	16	3	Harina Juana	4.06570	5.000	20.330000	143	1
19	19	3	Harina Juana	4.06570	5.000	20.330000	143	1
20	20	35	CARAOTA 1/2KG	1.50000	20.000	30.000000	151	1
21	21	3	Harina Juana	4.06570	2.000	8.130000	137	1
22	22	3	Harina Juana	4.06570	2.000	8.130000	136	1
23	23	3	Harina Juana	4.06570	3.000	12.200000	135	1
28	28	3	Harina Juana	4.06570	2.000	8.130000	136	1
30	30	3	AREPA	6.00000	2.000	12.000000	264	1
\.


--
-- Data for Name: returns; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.returns (id, sale_id, employee_id, reason, total, created_at, company_id, nc_number, status, annulled_at, annulled_by) FROM stdin;
10	41	1	Error	1.350000	2026-07-20 14:03:42.114+00	1	NC-0004	activo	\N	\N
11	43	1	\N	6.750000	2026-07-20 14:19:56.556+00	1	NC-0005	activo	\N	\N
12	44	1	\N	6.750000	2026-07-20 14:23:58.473+00	1	NC-0006	activo	\N	\N
13	46	1	\N	8.100000	2026-07-20 14:38:51.699+00	1	NC-0007	activo	\N	\N
14	54	1	\N	13.500000	2026-07-23 18:43:53.53+00	1	NC-0008	activo	\N	\N
15	118	1	PRODUCTO VENCIDO	20.330000	2026-08-20 16:06:17.459+00	1	NCA-0009	activo	\N	\N
16	114	1	error de compra	20.330000	2026-08-20 16:14:18.901+00	1	NCA-0010	activo	\N	\N
19	114	1	Cambio de producto	20.330000	2026-08-20 16:32:12.444+00	1	NCA-0011	activo	\N	\N
20	124	1	\N	30.000000	2026-08-20 16:55:31.865+00	1	\N	activo	\N	\N
21	109	1	\N	8.130000	2026-08-20 16:56:30.122+00	1	\N	activo	\N	\N
23	107	1	\N	12.200000	2026-08-20 17:02:54.227+00	1	NCB-0000002	anulado	2026-08-20 18:44:38.339+00	1
22	108	1	\N	8.130000	2026-08-20 16:57:46.01+00	1	NCB-0000001	anulado	2026-08-20 18:45:19.517+00	1
28	108	1	\N	8.130000	2026-08-20 18:47:06.179+00	1	NCB-0000003	anulado	2026-08-20 18:47:14.804+00	1
30	223	1	\N	12.000000	2026-09-03 14:40:52.495+00	1	NCB-0000004	activo	\N	\N
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.roles (id, name, label, permissions) FROM stdin;
1	admin	Administrador	{"all": true}
4	warehouse	Almacén	{"reports.view": true, "products.edit": true, "products.view": true, "purchases.pay": true, "inventory.view": true, "purchases.edit": true, "purchases.view": true, "products.create": true, "inventory.adjust": true, "purchases.create": true, "purchases.delete": true, "inventory.receive": true, "purchases.receive": true, "inventory.transfer": true}
3	cashier	Cajero	{"sales.cash": true, "sales.edit": true, "sales.view": true, "sales.void": true, "config.view": true, "reports.view": true, "sales.create": true, "sales.credit": true, "sales.return": true, "products.edit": true, "products.view": true, "purchases.pay": true, "customers.edit": true, "customers.view": true, "inventory.view": true, "purchases.edit": true, "purchases.view": true, "accounting.view": true, "accounting.void": true, "currencies.view": true, "products.create": true, "customers.create": true, "customers.credit": true, "inventory.adjust": true, "purchases.create": true, "purchases.delete": true, "accounting.income": true, "currencies.manage": true, "inventory.receive": true, "purchases.receive": true, "accounting.expense": true, "inventory.transfer": true}
2	manager	Gerente	{"sales.cash": true, "sales.edit": true, "sales.view": true, "sales.void": true, "config.edit": true, "config.view": true, "series.view": true, "reports.view": true, "sales.create": true, "sales.credit": true, "sales.return": true, "journals.view": true, "products.edit": true, "products.view": true, "purchases.pay": true, "reports.audit": true, "sales.forgive": true, "series.manage": true, "customers.edit": true, "customers.view": true, "employees.edit": true, "employees.view": true, "inventory.view": true, "purchases.edit": true, "purchases.view": true, "accounting.view": true, "accounting.void": true, "currencies.view": true, "journals.manage": true, "products.create": true, "products.delete": true, "customers.create": true, "customers.credit": true, "customers.delete": true, "employees.create": true, "employees.delete": true, "inventory.adjust": true, "purchases.create": true, "purchases.delete": true, "accounting.delete": true, "accounting.income": true, "currencies.manage": true, "inventory.receive": true, "purchases.receive": true, "accounting.expense": true, "inventory.transfer": true}
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.sale_items (id, sale_id, product_id, name, price, quantity, discount, cost_price, note) FROM stdin;
29	26	10	ARROZ 	0.98000	1.000	0.00000	\N	\N
30	27	3	Harina Juana	1.00000	3.000	0.00000	\N	\N
31	28	1	Harina Pan	2.00000	5.000	0.00000	\N	\N
32	29	20	corte de cabello	10.00000	10.000	0.00000	\N	\N
33	30	20	corte de cabello	10.00000	1.000	0.00000	\N	\N
34	31	3	Harina Juana	1.35000	1.000	0.00000	\N	\N
35	32	16	Carne Molida	6.50000	2.000	0.00000	\N	\N
36	33	12	PAPEL ALISOF	0.19000	2.000	0.00000	\N	\N
37	34	1	Harina Pan	1.68000	1.000	0.00000	\N	\N
38	35	16	Carne Molida	6.50000	1.000	0.00000	\N	\N
39	36	12	PAPEL ALISOF	0.19000	2.000	0.00000	\N	\N
40	37	16	Carne Molida	6.50000	0.500	0.00000	\N	\N
41	38	3	Harina Juana	1.35000	1.000	0.00000	\N	\N
42	39	20	corte de cabello	10.00000	2.000	0.00000	\N	\N
43	40	3	Harina Juana	1.35000	2.000	0.00000	\N	\N
44	41	3	Harina Juana	1.35000	3.000	0.00000	\N	\N
45	42	1	Harina Pan	1.68000	1.000	0.00000	\N	\N
46	43	3	Harina Juana	1.35000	5.000	0.00000	\N	\N
47	44	3	Harina Juana	1.35000	5.000	0.00000	\N	\N
48	45	1	Harina Pan	1.68000	5.000	0.00000	\N	\N
49	46	3	Harina Juana	1.35000	6.000	0.00000	\N	\N
50	47	16	Carne Molida	4.06569	1.000	0.00000	\N	\N
51	48	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
52	49	16	Carne Molida	4.06569	1.000	0.00000	\N	\N
53	50	16	Carne Molida	4.06569	1.000	0.00000	\N	\N
54	51	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
55	52	16	Carne Molida	4.06569	2.000	0.00000	\N	\N
56	53	16	Carne Molida	4.06569	1.000	0.00000	\N	\N
57	54	3	Harina Juana	1.35000	10.000	0.00000	\N	\N
58	55	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
59	56	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
60	57	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
61	58	3	Harina Juana	1.35523	2.000	0.00000	\N	\N
62	59	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
63	60	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
64	61	16	Carne Molida	4.06569	2.000	0.00000	\N	\N
65	62	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
66	63	16	Carne Molida	4.06569	2.000	0.00000	\N	\N
67	64	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
68	65	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
69	66	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
70	67	16	Carne Molida	4.06569	2.000	0.00000	\N	\N
71	68	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
72	69	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
73	70	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
74	71	16	Carne Molida	4.06569	3.000	0.00000	\N	\N
75	72	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
76	73	3	Harina Juana	4.06569	3.000	0.00000	\N	\N
77	74	3	Harina Juana	4.06569	3.000	0.00000	\N	\N
78	75	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
79	76	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
80	77	1	Harina Pan	1.67565	10.000	0.00000	\N	\N
81	78	3	Harina Juana	4.06569	5.000	0.00000	\N	\N
82	79	16	Carne Molida	4.06569	0.350	0.00000	\N	\N
83	80	16	Carne Molida	4.06569	0.326	0.00000	\N	\N
84	81	1	Harina Pan	1.67565	3.000	0.00000	\N	\N
85	81	16	Carne Molida	4.06569	0.325	0.00000	\N	\N
86	82	3	Harina Juana	4.06569	3.000	0.00000	\N	\N
87	82	16	Carne Molida	4.06569	1.325	0.00000	\N	\N
88	83	1	Harina Pan	1.67565	1.000	0.00000	1.30000	\N
89	84	1	Harina Pan	1.67565	2.000	0.00000	1.30000	\N
90	85	3	Harina Juana	4.06569	3.000	0.00000	1.04000	\N
101	87	16	Carne Molida	4.06569	2.000	0.00000	5.00000	\N
102	87	3	Harina Juana	4.06569	1.000	0.00000	1.04000	\N
120	94	1	Harina Pan	1.67565	8.000	0.00000	1.30000	\N
121	94	16	Carne Molida	4.06569	1.000	0.00000	5.00000	\N
123	96	12	PAPEL ALISOF	1.00000	20.000	0.00000	0.15000	\N
128	102	3	Harina Juana	4.06569	5.000	0.00000	1.04000	\N
129	103	3	Harina Juana	4.06569	2.000	0.00000	1.04000	\N
130	103	16	Carne Molida	4.06569	1.000	0.00000	5.00000	\N
131	103	10	AZUCAR	19.86347	3.000	0.00000	1.25000	\N
132	104	3	Harina Juana	4.06569	4.000	0.00000	1.04000	\N
133	105	3	Harina Juana	4.06569	5.000	0.00000	1.04000	\N
134	106	3	Harina Juana	4.06569	10.000	0.00000	1.04000	\N
135	107	3	Harina Juana	4.06569	3.000	0.00000	1.04000	\N
136	108	3	Harina Juana	4.06569	2.000	0.00000	1.04000	\N
137	109	3	Harina Juana	4.06569	2.000	0.00000	1.04000	\N
143	114	3	Harina Juana	4.06569	10.000	0.00000	1.04000	\N
146	118	3	Harina Juana	4.06569	5.000	0.00000	1.04000	\N
150	123	10	AZUCAR	1.62500	15.000	0.00000	\N	\N
151	124	35	CARAOTA 1/2KG	1.50000	20.000	0.00000	\N	\N
159	130	3	Harina Juana	4.06569	10.000	0.00000	1.04000	\N
160	131	3	Harina Juana	4.06569	20.000	0.00000	1.04000	\N
161	132	17	CERVEZA	1.00000	12.000	0.16667	0.63890	\N
162	133	3	Harina Juana	4.06569	5.000	0.00000	1.04000	\N
164	141	3	Harina Juana	4.06569	3.000	0.00000	1.04000	\N
165	142	3	Harina Juana	4.06569	2.000	0.00000	1.04000	\N
166	149	3	Harina Juana	4.06569	3.000	0.00000	1.04000	\N
173	160	12	PAPEL ALISOF	0.58906	4.000	0.00000	0.45310	\N
174	161	10	AZUCAR	1.62500	2.000	0.00000	1.25000	\N
175	164	17	CERVEZA	1.01955	20.000	0.00000	0.63890	\N
176	165	17	CERVEZA	1.01955	15.000	0.00000	0.63890	\N
177	167	17	CERVEZA	1.01955	3.000	0.00000	0.63890	\N
178	169	17	CERVEZA	1.01955	17.000	0.00000	0.63890	\N
179	171	17	CERVEZA	1.01955	20.000	0.00000	0.63890	\N
180	172	17	CERVEZA	1.01955	5.000	0.00000	0.63890	\N
181	174	17	CERVEZA	1.01955	36.000	0.00000	0.63890	\N
182	175	17	CERVEZA	1.01955	36.000	0.00000	0.63890	\N
253	188	19	CAJA DE CERVEZA LATA	36.00000	1.000	0.00000	22.35120	\N
262	221	17	CERVEZA	1.01955	1.000	0.00000	0.63890	\N
263	222	17	CERVEZA	1.01955	10.000	0.00000	0.63890	\N
264	223	3	AREPA	6.00000	2.000	0.00000	3.00000	\N
272	231	29	CARAOTA DETALLADA	1.17271	0.300	0.00000	2.00000	\N
275	233	70	Poción Go	25.00000	2.000	0.00000	\N	\N
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.sales (id, total, paid, change, status, customer_id, employee_id, currency_id, exchange_rate, discount_amount, payment_method, payment_method_id, payment_journal_id, warehouse_id, serie_id, serie_range_id, correlative_number, invoice_number, created_at, company_id, idempotency_key, credit_applied, web_customer_name, web_customer_phone, web_note, held_by_employee_id, held_at, service_charge, service_charge_label, forgiven_amount, forgiven_reason, forgiven_by, forgiven_at, requested_warehouse_id) FROM stdin;
42	1.68000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	24	A-0024	2026-07-20 14:03:42.141+00	1	\N	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
41	4.05000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	23	A-0023	2026-07-20 14:02:41.6+00	1	d43d464c-570f-41c6-a63b-3d8ef6a1b026	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
39	20.00000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-20 13:42:29.795+00	1	291bcb85-484d-4ccc-a6fb-8af255fdd387	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
38	1.35000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-06 20:16:06.414+00	1	01bcb13f-1473-44cf-a2b8-d03b772385d3	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
37	3.25000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-06 20:15:52.547+00	1	495b605a-f290-414c-8d14-a4024f247e5f	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
36	0.38000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-06 20:15:38.137+00	1	01a45ac6-fbf7-4142-b82b-0e46de935f77	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
35	6.50000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-06 20:15:29.713+00	1	2ec0e51b-3fd8-4ef4-a970-6b46d316265d	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
34	1.68000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-06 20:15:19.116+00	1	c2ac5c33-9383-4844-94e2-d18d9fa4ff77	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
33	0.38000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	18	A-0018	2026-07-06 20:14:15.826+00	1	83bd0517-506c-47cf-8a78-f7bc4f2d5997	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
32	13.00000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-06 20:14:06.116+00	1	55edc1ca-4761-446d-adc7-6d1d8792d2fb	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
31	1.35000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	21	A-0021	2026-07-06 20:13:54.175+00	1	ced07f22-09e4-4c72-8aa1-f008eaf81ffb	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
28	10.00000	0.00	0.00	anulado	3	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	17	A-0017	2026-06-10 18:27:18.584+00	1	5b370462-e641-407a-8cd8-e1cf72c09c56	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
30	10.00000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	20	A-0020	2026-07-06 20:13:35.843+00	1	729af1f2-f04d-4317-b4c9-ae9b497dc5ce	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
29	100.00000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	19	A-0019	2026-06-12 18:58:28.04+00	1	7644404b-7683-4230-aa04-df897686ff64	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
27	3.00000	0.00	0.00	anulado	3	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	16	A-0016	2026-06-10 18:08:00.19+00	1	0bc7d899-8d8f-4623-9bcf-300af2620c0b	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
26	0.98000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	15	A-0015	2026-06-10 18:06:54.33+00	1	f5b37156-07d8-462c-a5d1-fabf76e81402	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
40	2.70000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	22	A-0022	2026-07-20 14:00:29.871+00	1	64c7119a-bc82-4145-850b-d1e2074f1f2a	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
47	4.06569	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 17:47:06.656+00	1	cea43b78-3357-44f2-8d05-b792935ec67c	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
61	8.14000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:18:17.784+00	1	997c6b87-4650-4429-9e4d-6621e2074e43	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
49	4.07000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 18:05:37.87+00	1	6b10a642-7c34-41b9-8cd4-29508f67143e	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
48	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 18:05:17.021+00	1	3bac7492-4b69-4c46-9548-c04cb85d7cc3	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
64	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:29:14.43+00	1	7e926a3e-a65f-4e2e-bbb7-334c4cdced48	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
51	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 18:15:11.291+00	1	1b16809f-d688-428b-b0f3-a26cbcdaca3e	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
46	8.10000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	28	A-0028	2026-07-20 14:38:19.705+00	1	bc0d42f1-f72c-4ab6-8eaa-8b6560845c0e	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
45	8.38000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	27	A-0027	2026-07-20 14:36:52.38+00	1	67295998-bd34-4ce0-b9d6-d4794795708b	6.750000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
43	6.75000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	25	A-0025	2026-07-20 14:19:27.695+00	1	00740106-2689-4088-a399-6c751c436093	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
44	6.75000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	26	A-0026	2026-07-20 14:20:26.942+00	1	7cd3d516-2c2c-4906-bd62-c72f46d2aff9	6.750000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
50	4.07000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	29	A-0029	2026-07-23 18:08:56.628+00	1	8e369d03-8c32-47d5-b74e-7a8524319f83	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
52	8.14000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 18:16:53.467+00	1	50c65b8d-482d-4c5c-b622-697573d28a5c	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
53	4.07000	0.00	0.00	anulado	1	1	2	737.881600	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 18:20:07.655+00	1	f3dbbb17-4d0a-4245-a3fb-aa43621fec4d	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
57	16.80000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	32	A-0032	2026-07-23 18:57:21.639+00	1	28ebe2d7-cfd4-4f65-b4fe-9e77ca263642	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
58	2.72000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	33	A-0033	2026-07-23 19:00:03.743+00	1	e5dd8773-4483-432d-aeee-6895862b345d	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
55	16.80000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	31	A-0031	2026-07-23 18:44:51.147+00	1	6f05d6b6-fb89-4ea7-84de-4768f516ee72	13.500000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
54	13.50000	0.00	0.00	anulado	1	1	2	737.881600	0.00	efectivo	\N	\N	1	1	1	30	A-0030	2026-07-23 18:41:37.105+00	1	fc03e688-7013-4e1b-bb5c-87c8d180955b	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
56	16.80000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 18:47:01.342+00	1	0b9eb935-95ff-4839-be98-37bf306c9ece	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
63	8.14000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:27:56.597+00	1	c8521dc4-1624-4e93-9ccc-22f99acb15cc	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
59	16.80000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	34	A-0034	2026-07-23 19:01:12.969+00	1	8be993e9-cb03-46f9-9a8c-5bf8c974713d	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
60	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	35	A-0035	2026-07-23 19:02:56.901+00	1	a06e9a71-9e6d-428e-a791-47e9979a4b67	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
65	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:29:57.536+00	1	4909a6c1-cb85-473a-920b-81ecd7cc75f6	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
67	8.14000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:39:09.03+00	1	f1ba2ae7-26d3-44e5-abf6-45afa2fd0787	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
66	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:35:25.931+00	1	b58c7318-f966-4581-bf32-d465ead37c6c	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
62	16.80000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	36	A-0036	2026-07-23 19:27:15.782+00	1	1964622b-e56a-4fb4-b72c-366bd1aba9a4	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
68	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:46:45.573+00	1	8ca7cf49-9271-473c-867e-9589559ef5a6	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
69	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	37	A-0037	2026-07-23 19:47:40.503+00	1	190c5a41-2ee7-426e-bf57-1525bdd232db	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
70	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 19:59:31.262+00	1	307d829b-a953-4b29-914e-d008d0fbbf00	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
71	12.21000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	38	A-0038	2026-07-23 20:00:45.507+00	1	d92218d6-2049-4954-a38a-239dabca6225	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
233	50.00000	0.00	0.00	pagado	1	1	2	807.386200	0.00	efectivo	\N	\N	3	9	4	1	B-0001	2026-09-04 17:04:56.447+00	1	201e6be1-ff18-4589-b7c1-5041c2e85420	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
160	2.36000	0.00	0.00	pagado	1	1	2	784.663300	0.00	efectivo	\N	\N	1	1	1	73	A-0073	2026-08-24 17:30:40.465+00	1	bf5469bd-ed6e-4027-bc0d-73170ab490e0	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
161	3.26000	0.00	0.00	pagado	1	1	2	784.663300	0.00	efectivo	\N	\N	1	1	1	74	A-0074	2026-08-24 17:30:59.243+00	1	7a0aeefc-3921-4068-8b64-d7bdeff43012	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
175	36.72000	0.00	0.00	parcial	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	82	A-0082	2026-08-24 19:39:56.934+00	1	17898e72-f13a-40ef-91c1-2998d5905b0f	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
164	20.00000	0.00	0.00	exonerado	1	1	1	1.000000	0.40	efectivo	\N	\N	1	1	1	75	A-0075	2026-08-24 17:46:19.45+00	1	d09b08fa-3b6b-4385-9bef-8288728609e6	0.000000	\N	\N	\N	\N	\N	0.00000	\N	20.000000	ERROR DE COBRO	1	2026-08-24 17:52:14.078+00	\N
149	12.21000	0.00	0.00	exonerado	4	1	2	784.663300	0.00	efectivo	\N	\N	1	1	1	72	A-0072	2026-08-24 15:58:37.346+00	1	524560e8-5e07-4f0a-8178-a0a8169d1c17	0.000000	\N	\N	\N	\N	\N	0.00000	\N	12.210000	Deuda vieja	1	2026-08-24 16:19:10.159+00	\N
188	36.00000	0.00	0.00	pagado	1	1	2	800.000000	0.00	efectivo	\N	\N	1	1	1	83	A-0083	2026-08-28 18:56:22.476+00	1	51aeaf9f-7210-4fe6-bc6e-8e27b8951196	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
141	12.21000	0.00	0.00	pagado	1	1	2	784.663300	0.00	efectivo	\N	\N	1	1	1	70	A-0070	2026-08-24 15:40:17.756+00	1	714729bc-b53d-4159-8546-40b9bddf847e	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
142	8.14000	0.00	0.00	pagado	1	1	2	784.663300	0.00	efectivo	\N	\N	1	1	1	71	A-0071	2026-08-24 15:40:34.281+00	1	ba67abf6-5417-439b-9d28-546a714526d2	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
172	5.10000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	80	A-0080	2026-08-24 18:59:18.87+00	1	5ed9ca48-afd7-43e8-b5c5-85ccdfce07a0	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
174	30.00000	0.00	0.00	pagado	1	1	1	1.000000	6.72	efectivo	\N	\N	1	1	1	81	A-0081	2026-08-24 19:39:20.519+00	1	aa5ab684-1fb2-4550-bcb7-8a6ddddb7693	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
222	10.20000	0.00	0.00	pagado	1	1	2	800.000000	0.00	efectivo	\N	\N	1	1	1	85	A-0085	2026-09-02 16:57:46.938+00	1	7aa4689d-0d37-4871-b882-7bcf4a2f6b4e	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
231	0.35000	0.00	0.00	pendiente	1	1	2	800.000000	0.00	efectivo	\N	\N	1	1	1	87	A-0087	2026-09-03 20:55:37.713+00	1	6f85e098-440a-4ae3-b17b-886d2525ca1d	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
80	1.33000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	63	A-0063	2026-08-03 13:01:22.94+00	1	b60d654c-b9d2-4fdb-a87a-952eb0371e1e	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
83	1.68000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	62	A-0062	2026-08-05 13:25:56.316+00	1	dad13e7d-6ea4-4b06-9800-1e9e9edcdd89	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
73	12.20000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-07-23 20:25:03.756+00	1	c4b288c5-378a-4f32-bc4f-a361940dadcd	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
72	16.80000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	39	A-0039	2026-07-23 20:01:00.801+00	1	3096ceb5-cedb-49fc-ad5d-46f666406b6b	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
85	12.21000	0.00	0.00	anulado	\N	1	1	1.000000	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-08-05 13:49:22.714+00	1	\N	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
74	12.21000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	40	A-0040	2026-07-23 20:31:52.898+00	1	b6de3d16-e4a9-4ad0-94dd-d81ab41b16c5	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
75	16.80000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	41	A-0041	2026-07-23 20:40:37.724+00	1	e2029201-a362-4c0c-b587-0204afbb7ac0	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
102	20.35000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	51	A-0051	2026-08-06 18:35:50.981+00	1	42d5c741-b417-4e28-8ad2-ae47428dfedf	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
87	12.21000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	48	A-0048	2026-08-05 14:05:04.451+00	1	\N	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
76	16.80000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	42	A-0042	2026-07-23 20:51:34.112+00	1	3a1e1869-570b-46d2-863a-c5f5f7c00d12	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
77	16.80000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	43	A-0043	2026-07-23 20:58:21.95+00	1	fdd86880-e04e-4908-9ea8-48e6ec40e2b2	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
78	20.35000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	44	A-0044	2026-07-23 20:58:39.74+00	1	f5ee4c05-cce2-4e86-9c00-1d034d01c5c2	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
79	1.42000	0.00	0.00	anulado	1	1	2	737.881600	0.00	efectivo	\N	\N	1	1	\N	\N	\N	2026-08-03 12:58:58.359+00	1	55bd0965-3b24-4f07-9f71-af2cba7abdcb	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
81	6.36000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	45	A-0045	2026-08-03 14:05:36.608+00	1	63980973-77c8-48d3-8ccc-70ae3f9d7458	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
106	40.70000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	55	A-0055	2026-08-10 23:26:23.329+00	1	f19f33da-71fd-4000-80b3-56d847571a05	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
82	17.60000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	46	A-0046	2026-08-03 14:12:00.408+00	1	66b37fde-b22e-4c87-b6c7-6e4febe41f60	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
84	3.36000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	47	A-0047	2026-08-05 13:31:41.262+00	1	fbf64e59-5175-4346-a082-8280a670fa1b	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
165	15.30000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	76	A-0076	2026-08-24 17:52:38.725+00	1	1dadf1c0-f681-4773-a832-3d9e2899bfe1	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
167	3.06000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	77	A-0077	2026-08-24 18:03:06.582+00	1	f5affac4-226b-4800-ae6b-625600b5c759	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
103	71.79000	0.00	0.00	pagado	1	1	2	757.540600	0.00	efectivo	\N	\N	1	1	1	52	A-0052	2026-08-10 12:16:16.243+00	1	cdbf8ba8-5351-45d6-845f-42afeb922a78	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
96	20.00000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	50	A-0050	2026-08-06 16:46:32.975+00	1	6af465c2-3026-4ae2-b3f9-b45df40a7db7	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.200000	Pago	1	2026-08-24 15:24:14.329+00	\N
169	17.34000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	78	A-0078	2026-08-24 18:31:33.069+00	1	15236b72-9432-4cec-8055-6abaf69ae342	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
94	17.51000	0.00	0.00	anulado	\N	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	49	A-0049	2026-08-06 16:38:04.296+00	1	\N	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
104	16.28000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	53	A-0053	2026-08-10 22:31:09.166+00	1	e0732089-c336-42c8-ae34-28622a9bebd7	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
171	20.40000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	79	A-0079	2026-08-24 18:55:58.854+00	1	8bd3e1ae-1320-4dac-845c-3a6adf4f43b4	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
105	20.35000	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	54	A-0054	2026-08-10 22:57:44.636+00	1	9949487f-e451-4bb9-b15f-7ce107eef671	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
221	1.02000	0.00	0.00	pagado	1	1	2	800.000000	0.00	efectivo	\N	\N	1	1	1	84	A-0084	2026-09-02 16:55:08.568+00	1	5c303db7-e623-4064-ae4e-fc96427b372a	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
223	12.00000	0.00	0.00	devuelto	1	1	2	800.000000	0.00	efectivo	\N	\N	1	1	1	86	A-0086	2026-09-02 16:58:35.505+00	1	1895c42c-1728-49f4-9d2e-5d511b60bd53	0.800000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
118	20.35000	0.00	0.00	devuelto	1	1	2	775.335600	0.00	efectivo	\N	\N	1	1	1	61	A-0061	2026-08-19 21:00:21.539+00	1	0e7574e0-f0c7-4217-ba58-0c5df52a827b	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
123	24.37500	0.00	0.00	anulado	1	1	2	773.312500	0.00	efectivo	\N	\N	1	1	1	64	A-0064	2026-08-20 16:14:19.079+00	1	\N	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
131	82.68000	0.00	0.00	pagado	1	1	2	779.952200	0.00	efectivo	\N	\N	1	1	1	67	A-0067	2026-08-21 14:50:10.476+00	1	c27fcca5-e933-4d21-8f4c-fd29d5e81d25	0.000000	\N	\N	\N	\N	\N	1.28213	Servicio	0.000000	\N	\N	\N	\N
114	40.70000	0.00	0.00	devuelto	1	1	2	773.312500	0.00	efectivo	\N	\N	1	1	1	60	A-0060	2026-08-19 12:59:36.857+00	1	\N	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
108	8.14000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	57	A-0057	2026-08-12 19:48:29.05+00	1	ea081457-e03e-4535-a030-cd10eb342a91	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
124	30.00000	20.33	0.00	anulado	1	1	2	773.312500	0.00	efectivo	\N	\N	1	1	1	65	A-0065	2026-08-20 16:32:12.586+00	1	\N	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
109	8.14000	0.00	0.00	devuelto	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	58	A-0058	2026-08-12 19:57:37.875+00	1	e14f582b-5a9d-4206-8c2d-abbcbdf8a773	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
107	12.21000	0.00	0.00	pagado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	56	A-0056	2026-08-11 00:11:52.326+00	1	5a85c09d-3dba-489f-a43b-4a8ba3962e82	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
132	10.40000	0.00	0.00	pagado	1	1	2	779.952200	0.60	efectivo	\N	\N	1	1	1	68	A-0068	2026-08-21 20:26:01.256+00	1	2d54c268-4327-4860-bdb4-65a588696d15	0.000000	\N	\N	\N	\N	\N	1.00000	Servicio	0.000000	\N	\N	\N	\N
133	20.35000	0.00	0.00	pagado	1	1	2	784.663300	0.00	efectivo	\N	\N	1	1	1	69	A-0069	2026-08-24 12:57:17.506+00	1	0844b83d-343c-49a9-a85b-55099ff5d638	0.000000	\N	\N	\N	\N	\N	0.00000	\N	0.000000	\N	\N	\N	\N
130	40.70000	0.00	0.00	exonerado	1	1	2	779.952200	0.00	efectivo	\N	\N	1	1	1	66	A-0066	2026-08-21 14:45:57.563+00	1	64e956d8-a228-4100-b000-eea179b90b6d	0.000000	\N	\N	\N	\N	\N	0.00256	Delivery	40.700000	PAGADA CON TRABAJO	1	2026-08-24 15:21:28.368+00	\N
\.


--
-- Data for Name: serie_ranges; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.serie_ranges (id, serie_id, start_number, end_number, current_number, active, created_at) FROM stdin;
3	4	1	10	5	t	2026-08-20 16:57:20.818+00
1	1	1	100	88	t	2026-05-18 14:04:11.977+00
4	9	1	10	2	t	2026-09-04 17:03:31.081+00
2	2	1	100	12	t	2026-05-18 19:27:48.572+00
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.series (id, name, prefix, padding, active, created_at, company_id, type, warehouse_id, nc_serie_id) FROM stdin;
2	NC	NCA	4	t	2026-05-18 19:27:39.537+00	1	nc	1	\N
4	NCB	NCB	7	t	2026-08-20 16:55:10.517+00	1	nc	1	\N
1	A	A	4	t	2026-05-18 14:04:00.269+00	1	factura	1	4
9	B	B	4	t	2026-09-04 17:03:06.918+00	1	factura	3	\N
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.settings (key, value, company_id) FROM stdin;
logo_filename	logo_1_1788446654313.jpeg	1
public_catalog_slug	vintage-beauty	1
base_currency	USD	1
brand_color	#14b897	1
catalog_orders_enabled	true	1
catalog_whatsapp	584220368184	1
printer_width	58	1
public_catalog_token	c980ad02d8f7417aa51050e2320d40e6	1
receipt_footer	VUELVA PRONTO	1
receipt_show_header	true	1
sales_doc_name	Documento de Venta	1
store_address	Carretera Lara Falcon Km11	1
store_city	Barquisimeto	1
store_name	VINTAGE BEAUTY	1
store_phone	04261521817	1
store_rif	J-222222222	1
store_slogan	Productos de Calidad Con Facilidad	1
tax_name	IVA	1
tax_rate	16	1
catalog_theme	boutique	1
catalog_brand_color	#f05184	1
catalog_panel_color	#FDF2F8	1
catalog_bg_color	#e996c3	1
catalog_announcement_text	ENVIOS GRATIS A TODO EL PAIS	1
catalog_announcement_link		1
catalog_instagram	https://instagram.com/elgranterminal	1
catalog_facebook		1
catalog_menu	[{"category_id":3,"label":"","badge":""},{"category_id":1,"label":"","badge":""}]	1
catalog_highlights	["NUESTRO MEJORES PRODUCTOS"]	1
\.


--
-- Data for Name: stock_session_lines; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.stock_session_lines (id, session_id, warehouse_id, product_id, product_name, qty_before, qty_adjusted, qty_after, type, reason, notes, created_at, updated_at) FROM stdin;
1	1	1	3	Harina Juana	48.0000	8.0000	56.0000	in	compra	\N	2026-05-29 16:24:52.301+00	2026-05-29 16:24:52.301+00
2	3	1	10	ARROZ 	4.0000	-4.0000	0.0000	out	vencimiento	\N	2026-06-10 15:55:11.516+00	2026-06-10 15:55:11.516+00
3	4	1	10	ARROZ 	24.0000	-24.0000	0.0000	out	merma	\N	2026-06-10 16:37:03.042+00	2026-06-10 16:37:03.042+00
4	5	1	10	ARROZ 	0.0000	2.0000	2.0000	in	compra	\N	2026-06-10 16:41:04.59+00	2026-06-10 16:41:04.59+00
5	5	1	10	ARROZ 	2.0000	-2.0000	0.0000	out	merma	\N	2026-06-10 16:41:13.911+00	2026-06-10 16:41:13.911+00
6	6	1	10	ARROZ 	0.0000	24.0000	24.0000	in	compra	\N	2026-06-10 16:41:50.476+00	2026-06-10 16:41:50.476+00
7	7	1	10	ARROZ 	0.0000	16.0000	16.0000	in	compra	\N	2026-06-10 18:17:16.084+00	2026-06-10 18:17:16.084+00
8	7	1	12	PAPEL ALISOF	0.0000	20.0000	20.0000	in	compra	\N	2026-06-10 18:17:19.616+00	2026-06-10 18:17:19.616+00
9	7	1	13	Paquete de Papel 	0.0000	5.0000	5.0000	in	compra	\N	2026-06-10 18:17:24.599+00	2026-06-10 18:17:24.599+00
10	8	1	13	Paquete de Papel 	5.0000	-1.0000	4.0000	out	merma	\N	2026-06-10 18:18:15.594+00	2026-06-10 18:18:15.594+00
11	9	1	12	PAPEL ALISOF	20.0000	-4.0000	16.0000	out	merma	\N	2026-06-10 18:42:14.95+00	2026-06-10 18:42:14.95+00
12	10	1	17	CERVEZA	0.0000	100.0000	100.0000	in	compra	\N	2026-08-21 20:19:55.814+00	2026-08-21 20:19:55.814+00
13	10	1	28	CERVEZA DE LATA	0.0000	100.0000	100.0000	in	compra	\N	2026-08-21 20:19:59.271+00	2026-08-21 20:19:59.271+00
14	13	3	71	Shampoo Biorepolarizador	0.0000	2.0000	2.0000	in	compra	\N	2026-09-03 17:57:28.287+00	2026-09-03 17:57:28.287+00
\.


--
-- Data for Name: stock_sessions; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.stock_sessions (id, warehouse_id, employee_id, company_id, status, opened_at, closed_at, notes, created_at, updated_at) FROM stdin;
1	1	1	1	closed	2026-05-29 16:20:17.459+00	2026-05-29 16:25:04.257+00	\N	2026-05-29 16:20:17.46+00	2026-05-29 16:25:04.258+00
2	1	1	1	closed	2026-05-29 16:25:22.945+00	2026-05-29 16:25:24.55+00	\N	2026-05-29 16:25:22.946+00	2026-05-29 16:25:24.55+00
3	1	1	1	closed	2026-06-10 15:55:11.449+00	2026-06-10 15:55:23.152+00	\N	2026-06-10 15:55:11.451+00	2026-06-10 15:55:23.152+00
4	1	1	1	closed	2026-06-10 16:37:02.976+00	2026-06-10 16:37:05.686+00	\N	2026-06-10 16:37:02.977+00	2026-06-10 16:37:05.687+00
5	1	1	1	closed	2026-06-10 16:41:04.511+00	2026-06-10 16:41:19.662+00	\N	2026-06-10 16:41:04.512+00	2026-06-10 16:41:19.663+00
6	1	1	1	closed	2026-06-10 16:41:50.43+00	2026-06-10 16:41:53.593+00	\N	2026-06-10 16:41:50.43+00	2026-06-10 16:41:53.593+00
7	1	1	1	closed	2026-06-10 18:17:16.028+00	2026-06-10 18:17:31.855+00	\N	2026-06-10 18:17:16.029+00	2026-06-10 18:17:31.855+00
8	1	1	1	closed	2026-06-10 18:18:15.543+00	2026-06-10 18:18:30.2+00	\N	2026-06-10 18:18:15.543+00	2026-06-10 18:18:30.2+00
9	1	1	1	closed	2026-06-10 18:42:14.881+00	2026-06-10 18:42:16.788+00	\N	2026-06-10 18:42:14.883+00	2026-06-10 18:42:16.788+00
10	1	1	1	open	2026-08-13 13:39:33.207+00	\N	\N	2026-08-13 13:39:33.209+00	2026-08-13 13:39:33.209+00
13	3	1	1	open	2026-09-03 17:57:28.19+00	\N	\N	2026-09-03 17:57:28.191+00	2026-09-03 17:57:28.191+00
\.


--
-- Data for Name: stock_transfer_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.stock_transfer_items (id, transfer_id, product_id, product_name, unit, qty_sent, qty_received, diff_reason, diff_resolution, resolved_at, created_at, updated_at, unit_cost) FROM stdin;
2	14	3	Harina Juana	UNIDAD	5.0000	5.0000	\N	\N	\N	2026-08-21 19:50:45.109+00	2026-08-21 19:51:40.562+00	\N
7	19	17	CERVEZA	UNIDAD	1000.0000	1000.0000	\N	\N	\N	2026-08-28 19:44:13.037+00	2026-08-28 19:45:55.965+00	0.6389
\.


--
-- Data for Name: stock_transfers; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.stock_transfers (id, from_warehouse_id, to_warehouse_id, product_id, product_name, qty, note, employee_id, created_at, company_id, code, status, difference_status, dispatched_at, received_by, received_at, receipt_note, cancelled_by, cancelled_at, cancel_reason) FROM stdin;
14	1	3	\N	\N	\N	\N	1	2026-08-21 19:50:45.041+00	1	TR-000001	received	none	2026-08-21 19:50:45.03+00	1	2026-08-21 19:51:40.566+00	\N	\N	\N	\N
19	1	3	\N	\N	\N	PARA QUE TENGAS PARA VENDER	1	2026-08-28 19:44:12.963+00	1	TR-000002	received	none	2026-08-28 19:44:12.96+00	2	2026-08-28 19:45:55.967+00	COMPLETA LA MERCANCIA	\N	\N	\N
\.


--
-- Data for Name: user_series; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.user_series (user_id, serie_id, company_id) FROM stdin;
1	1	1
1	2	1
1	4	1
2	4	1
2	9	1
1	9	1
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.warehouses (id, name, description, active, sort_order, created_at, company_id, sells, parent_warehouse_id) FROM stdin;
1	CENTRO	Almacén Principal	t	0	2026-05-18 13:53:31.63267+00	1	t	\N
3	OESTE	\N	t	0	2026-08-19 18:50:29.201+00	1	t	\N
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 2098, true);


--
-- Name: banks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.banks_id_seq', 5, true);


--
-- Name: cash_session_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.cash_session_journals_id_seq', 24, true);


--
-- Name: cash_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.cash_sessions_id_seq', 13, true);


--
-- Name: catalog_banners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.catalog_banners_id_seq', 6, true);


--
-- Name: catalog_benefit_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.catalog_benefit_tags_id_seq', 7, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.categories_id_seq', 12, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.companies_id_seq', 6, true);


--
-- Name: currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.currencies_id_seq', 14, true);


--
-- Name: customer_credit_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.customer_credit_movements_id_seq', 2, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.customers_id_seq', 17, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.employees_id_seq', 10, true);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 19, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.expenses_id_seq', 92, true);


--
-- Name: income_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.income_categories_id_seq', 12, true);


--
-- Name: incomes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.incomes_id_seq', 7, true);


--
-- Name: payment_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.payment_journals_id_seq', 8, true);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 10, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.payments_id_seq', 218, true);


--
-- Name: product_combo_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.product_combo_items_id_seq', 39, true);


--
-- Name: product_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.product_lots_id_seq', 1, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.products_id_seq', 71, true);


--
-- Name: promotions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.promotions_id_seq', 5, true);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.purchase_items_id_seq', 167, true);


--
-- Name: purchase_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.purchase_payments_id_seq', 37, true);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.purchases_id_seq', 65, true);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.quotation_items_id_seq', 8, true);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.quotations_id_seq', 6, true);


--
-- Name: return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.return_items_id_seq', 30, true);


--
-- Name: returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.returns_id_seq', 30, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- Name: sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.sale_items_id_seq', 275, true);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.sales_id_seq', 233, true);


--
-- Name: serie_ranges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.serie_ranges_id_seq', 4, true);


--
-- Name: series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.series_id_seq', 9, true);


--
-- Name: stock_session_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.stock_session_lines_id_seq', 14, true);


--
-- Name: stock_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.stock_sessions_id_seq', 13, true);


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.stock_transfer_items_id_seq', 7, true);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.stock_transfers_id_seq', 19, true);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 4, true);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banks banks_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_pkey PRIMARY KEY (id);


--
-- Name: cash_session_journals cash_session_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_pkey PRIMARY KEY (id);


--
-- Name: cash_sessions cash_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_pkey PRIMARY KEY (id);


--
-- Name: catalog_banners catalog_banners_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.catalog_banners
    ADD CONSTRAINT catalog_banners_pkey PRIMARY KEY (id);


--
-- Name: catalog_benefit_tags catalog_benefit_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.catalog_benefit_tags
    ADD CONSTRAINT catalog_benefit_tags_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: customer_credit_movements customer_credit_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customer_credit_movements
    ADD CONSTRAINT customer_credit_movements_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: employee_warehouses employee_warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_pkey PRIMARY KEY (employee_id, warehouse_id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employees employees_username_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_username_key UNIQUE (username);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: income_categories income_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.income_categories
    ADD CONSTRAINT income_categories_pkey PRIMARY KEY (id);


--
-- Name: incomes incomes_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_pkey PRIMARY KEY (id);


--
-- Name: payment_journals payment_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: product_benefit_tags product_benefit_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_benefit_tags
    ADD CONSTRAINT product_benefit_tags_pkey PRIMARY KEY (product_id, benefit_tag_id);


--
-- Name: product_combo_items product_combo_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_pkey PRIMARY KEY (id);


--
-- Name: product_lots product_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_pkey PRIMARY KEY (id);


--
-- Name: product_stock product_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_pkey PRIMARY KEY (warehouse_id, product_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: promotion_products promotion_products_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotion_products
    ADD CONSTRAINT promotion_products_pkey PRIMARY KEY (promotion_id, product_id);


--
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_payments purchase_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: return_items return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_pkey PRIMARY KEY (id);


--
-- Name: returns returns_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sales sales_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: serie_ranges serie_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.serie_ranges
    ADD CONSTRAINT serie_ranges_pkey PRIMARY KEY (id);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key, company_id);


--
-- Name: stock_session_lines stock_session_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_session_lines
    ADD CONSTRAINT stock_session_lines_pkey PRIMARY KEY (id);


--
-- Name: stock_sessions stock_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions
    ADD CONSTRAINT stock_sessions_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: user_series user_series_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_pkey PRIMARY KEY (user_id, serie_id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: banks_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX banks_name_company_id_unique ON public.banks USING btree (name, company_id);


--
-- Name: catalog_banners_company_active_order; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX catalog_banners_company_active_order ON public.catalog_banners USING btree (company_id, active, sort_order);


--
-- Name: catalog_benefit_tags_company_name; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX catalog_benefit_tags_company_name ON public.catalog_benefit_tags USING btree (company_id, name);


--
-- Name: categories_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX categories_name_company_id_unique ON public.categories USING btree (name, company_id);


--
-- Name: currencies_code_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX currencies_code_company_id_unique ON public.currencies USING btree (code, company_id);


--
-- Name: customer_credit_movements_customer_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX customer_credit_movements_customer_id_idx ON public.customer_credit_movements USING btree (customer_id);


--
-- Name: customer_credit_movements_customer_warehouse_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX customer_credit_movements_customer_warehouse_idx ON public.customer_credit_movements USING btree (customer_id, warehouse_id);


--
-- Name: customers_email_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX customers_email_company_id_unique ON public.customers USING btree (email, company_id);


--
-- Name: customers_rif_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX customers_rif_company_id_unique ON public.customers USING btree (rif, company_id);


--
-- Name: expenses_warehouse_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX expenses_warehouse_id_idx ON public.expenses USING btree (warehouse_id);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_employee; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_audit_employee ON public.audit_logs USING btree (employee_id);


--
-- Name: idx_customers_name; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_customers_name ON public.customers USING btree (name);


--
-- Name: idx_customers_rif; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_customers_rif ON public.customers USING btree (rif);


--
-- Name: idx_employees_username; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_employees_username ON public.employees USING btree (username);


--
-- Name: idx_payments_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_payments_created_at ON public.payments USING btree (created_at DESC);


--
-- Name: idx_payments_customer; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_payments_customer ON public.payments USING btree (customer_id);


--
-- Name: idx_payments_sale_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_payments_sale_id ON public.payments USING btree (sale_id);


--
-- Name: idx_product_lots_expiry; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_lots_expiry ON public.product_lots USING btree (expiration_date);


--
-- Name: idx_product_lots_lot; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_lots_lot ON public.product_lots USING btree (lot_number);


--
-- Name: idx_product_lots_product_warehouse; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_lots_product_warehouse ON public.product_lots USING btree (product_id, warehouse_id);


--
-- Name: idx_product_stock_product; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_stock_product ON public.product_stock USING btree (product_id);


--
-- Name: idx_product_stock_warehouse; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_stock_warehouse ON public.product_stock USING btree (warehouse_id);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_products_category ON public.products USING btree (category_id);


--
-- Name: idx_purchase_items_purch; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_purchase_items_purch ON public.purchase_items USING btree (purchase_id);


--
-- Name: idx_purchases_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_purchases_created_at ON public.purchases USING btree (created_at DESC);


--
-- Name: idx_sale_items_sale; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sale_items_sale ON public.sale_items USING btree (sale_id);


--
-- Name: idx_sales_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_created_at ON public.sales USING btree (created_at DESC);


--
-- Name: idx_sales_customer; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_customer ON public.sales USING btree (customer_id);


--
-- Name: idx_sales_employee; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_employee ON public.sales USING btree (employee_id);


--
-- Name: idx_sales_journal; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_journal ON public.sales USING btree (payment_journal_id);


--
-- Name: idx_stock_transfer_items_transfer; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_stock_transfer_items_transfer ON public.stock_transfer_items USING btree (transfer_id);


--
-- Name: idx_stock_transfers_company_code; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX idx_stock_transfers_company_code ON public.stock_transfers USING btree (company_id, code);


--
-- Name: idx_stock_transfers_company_status; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_stock_transfers_company_status ON public.stock_transfers USING btree (company_id, status);


--
-- Name: idx_stock_transfers_dest_status; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_stock_transfers_dest_status ON public.stock_transfers USING btree (to_warehouse_id, status);


--
-- Name: idx_transfers_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_transfers_created_at ON public.stock_transfers USING btree (created_at DESC);


--
-- Name: idx_warehouses_parent; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_warehouses_parent ON public.warehouses USING btree (parent_warehouse_id);


--
-- Name: incomes_warehouse_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX incomes_warehouse_id_idx ON public.incomes USING btree (warehouse_id);


--
-- Name: payment_journals_warehouse_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX payment_journals_warehouse_id_idx ON public.payment_journals USING btree (warehouse_id);


--
-- Name: payment_methods_code_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX payment_methods_code_company_id_unique ON public.payment_methods USING btree (code, company_id);


--
-- Name: payment_methods_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX payment_methods_name_company_id_unique ON public.payment_methods USING btree (name, company_id);


--
-- Name: payments_batch_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX payments_batch_id_idx ON public.payments USING btree (batch_id);


--
-- Name: payments_idempotency_key_key; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX payments_idempotency_key_key ON public.payments USING btree (idempotency_key);


--
-- Name: products_barcode_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX products_barcode_company_id_unique ON public.products USING btree (barcode, company_id);


--
-- Name: return_items_sale_item_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX return_items_sale_item_id ON public.return_items USING btree (sale_item_id);


--
-- Name: returns_status_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX returns_status_idx ON public.returns USING btree (status);


--
-- Name: sales_company_invoice_number_key; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX sales_company_invoice_number_key ON public.sales USING btree (company_id, invoice_number);


--
-- Name: sales_held_by_employee_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX sales_held_by_employee_id_idx ON public.sales USING btree (held_by_employee_id);


--
-- Name: sales_requested_warehouse_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX sales_requested_warehouse_id_idx ON public.sales USING btree (requested_warehouse_id);


--
-- Name: series_warehouse_id_idx; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX series_warehouse_id_idx ON public.series USING btree (warehouse_id);


--
-- Name: stock_session_lines_session_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX stock_session_lines_session_id ON public.stock_session_lines USING btree (session_id);


--
-- Name: stock_sessions_company_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX stock_sessions_company_id ON public.stock_sessions USING btree (company_id);


--
-- Name: stock_sessions_warehouse_id_status; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX stock_sessions_warehouse_id_status ON public.stock_sessions USING btree (warehouse_id, status);


--
-- Name: warehouses_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX warehouses_name_company_id_unique ON public.warehouses USING btree (name, company_id);


--
-- Name: currencies trg_currencies_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_currencies_updated_at BEFORE UPDATE ON public.currencies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: customers trg_customers_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: employees trg_employees_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: products trg_products_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: audit_logs audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: banks banks_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: cash_session_journals cash_session_journals_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: cash_session_journals cash_session_journals_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES public.payment_journals(id) ON DELETE SET NULL;


--
-- Name: cash_session_journals cash_session_journals_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.cash_sessions(id) ON DELETE CASCADE;


--
-- Name: cash_sessions cash_sessions_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: cash_sessions cash_sessions_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: cash_sessions cash_sessions_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: categories categories_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: currencies currencies_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: customer_credit_movements customer_credit_movements_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customer_credit_movements
    ADD CONSTRAINT customer_credit_movements_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_credit_movements customer_credit_movements_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customer_credit_movements
    ADD CONSTRAINT customer_credit_movements_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: customer_credit_movements customer_credit_movements_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customer_credit_movements
    ADD CONSTRAINT customer_credit_movements_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.returns(id) ON DELETE SET NULL;


--
-- Name: customer_credit_movements customer_credit_movements_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customer_credit_movements
    ADD CONSTRAINT customer_credit_movements_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE SET NULL;


--
-- Name: customer_credit_movements customer_credit_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customer_credit_movements
    ADD CONSTRAINT customer_credit_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: customers customers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: employee_warehouses employee_warehouses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: employee_warehouses employee_warehouses_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_warehouses employee_warehouses_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: employees employees_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: employees employees_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: expense_categories expense_categories_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.expense_categories(id);


--
-- Name: expenses expenses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: expenses expenses_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: expenses expenses_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id);


--
-- Name: expenses expenses_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE RESTRICT;


--
-- Name: incomes incomes_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.income_categories(id);


--
-- Name: incomes incomes_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: incomes incomes_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: incomes incomes_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id);


--
-- Name: incomes incomes_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE RESTRICT;


--
-- Name: payment_journals payment_journals_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.banks(id) ON DELETE SET NULL;


--
-- Name: payment_journals payment_journals_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: payment_journals payment_journals_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id) ON DELETE SET NULL;


--
-- Name: payment_journals payment_journals_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE RESTRICT;


--
-- Name: payment_methods payment_methods_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: payments payments_change_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_change_journal_id_fkey FOREIGN KEY (change_journal_id) REFERENCES public.payment_journals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: payments payments_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id) ON DELETE SET NULL;


--
-- Name: payments payments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: payments payments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: payments payments_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id) ON DELETE SET NULL;


--
-- Name: payments payments_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: product_benefit_tags product_benefit_tags_benefit_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_benefit_tags
    ADD CONSTRAINT product_benefit_tags_benefit_tag_id_fkey FOREIGN KEY (benefit_tag_id) REFERENCES public.catalog_benefit_tags(id) ON DELETE CASCADE;


--
-- Name: product_benefit_tags product_benefit_tags_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_benefit_tags
    ADD CONSTRAINT product_benefit_tags_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_combo_items product_combo_items_combo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_combo_id_fkey FOREIGN KEY (combo_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_combo_items product_combo_items_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: product_combo_items product_combo_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_lots product_lots_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: product_lots product_lots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_lots product_lots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_stock product_stock_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: product_stock product_stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_stock product_stock_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: products products_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: promotion_products promotion_products_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotion_products
    ADD CONSTRAINT promotion_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: promotion_products promotion_products_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotion_products
    ADD CONSTRAINT promotion_products_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES public.promotions(id) ON DELETE CASCADE;


--
-- Name: promotions promotions_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: purchase_items purchase_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: purchase_items purchase_items_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE CASCADE;


--
-- Name: purchase_payments purchase_payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: purchase_payments purchase_payments_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: purchase_payments purchase_payments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: purchase_payments purchase_payments_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id);


--
-- Name: purchase_payments purchase_payments_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: purchases purchases_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: purchases purchases_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: quotation_items quotation_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: quotation_items quotation_items_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_quotation_id_fkey FOREIGN KEY (quotation_id) REFERENCES public.quotations(id) ON DELETE CASCADE;


--
-- Name: quotations quotations_converted_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_converted_sale_id_fkey FOREIGN KEY (converted_sale_id) REFERENCES public.sales(id);


--
-- Name: quotations quotations_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: quotations quotations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: quotations quotations_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: quotations quotations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: return_items return_items_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: return_items return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: return_items return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.returns(id) ON DELETE CASCADE;


--
-- Name: return_items return_items_sale_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_sale_item_id_fkey FOREIGN KEY (sale_item_id) REFERENCES public.sale_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: returns returns_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: returns returns_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: returns returns_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: sale_items sale_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: sale_items sale_items_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: sales sales_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: sales sales_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id) ON DELETE SET NULL;


--
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: sales sales_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: sales sales_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id) ON DELETE SET NULL;


--
-- Name: sales sales_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id) ON DELETE SET NULL;


--
-- Name: sales sales_requested_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_requested_warehouse_id_fkey FOREIGN KEY (requested_warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: sales sales_serie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_serie_id_fkey FOREIGN KEY (serie_id) REFERENCES public.series(id) ON DELETE SET NULL;


--
-- Name: sales sales_serie_range_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_serie_range_id_fkey FOREIGN KEY (serie_range_id) REFERENCES public.serie_ranges(id) ON DELETE SET NULL;


--
-- Name: sales sales_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: serie_ranges serie_ranges_serie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.serie_ranges
    ADD CONSTRAINT serie_ranges_serie_id_fkey FOREIGN KEY (serie_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: series series_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: series series_nc_serie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_nc_serie_id_fkey FOREIGN KEY (nc_serie_id) REFERENCES public.series(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: series series_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE RESTRICT;


--
-- Name: settings settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: stock_session_lines stock_session_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_session_lines
    ADD CONSTRAINT stock_session_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.stock_sessions(id) ON DELETE CASCADE;


--
-- Name: stock_sessions stock_sessions_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions
    ADD CONSTRAINT stock_sessions_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: stock_sessions stock_sessions_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions
    ADD CONSTRAINT stock_sessions_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_transfer_items stock_transfer_items_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES public.stock_transfers(id) ON DELETE CASCADE;


--
-- Name: stock_transfers stock_transfers_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: stock_transfers stock_transfers_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_from_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_from_warehouse_id_fkey FOREIGN KEY (from_warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_received_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_received_by_fkey FOREIGN KEY (received_by) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_to_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_to_warehouse_id_fkey FOREIGN KEY (to_warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: user_series user_series_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: user_series user_series_serie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_serie_id_fkey FOREIGN KEY (serie_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: user_series user_series_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: warehouses warehouses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: warehouses warehouses_parent_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_parent_warehouse_id_fkey FOREIGN KEY (parent_warehouse_id) REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 9GKPv3L0hu2RbuLMxPdoQeeUqu2EdlTTmkKi1hZLw0qM1BglWVTI7yw3J5F1kpC

