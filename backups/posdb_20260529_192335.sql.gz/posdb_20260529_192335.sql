--
-- PostgreSQL database dump
--

\restrict GeGoulK4Zn2Hm9hktZ3fjtSBvylAm48JegQucnrFnNpcFe5qt2EennVp3czSCqb

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: posuser
--

CREATE FUNCTION public.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at() OWNER TO posuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO posuser;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    employee_id integer,
    employee_name character varying(200),
    method character varying(10) NOT NULL,
    path character varying(500) NOT NULL,
    ip character varying(60),
    status_code integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO posuser;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO posuser;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: banks; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.banks (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(10),
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.banks OWNER TO posuser;

--
-- Name: banks_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.banks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.banks_id_seq OWNER TO posuser;

--
-- Name: banks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.banks_id_seq OWNED BY public.banks.id;


--
-- Name: cash_session_journals; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.cash_session_journals (
    id integer NOT NULL,
    session_id integer,
    journal_id integer,
    opening_amount numeric(12,2) DEFAULT 0 NOT NULL,
    closing_amount numeric(12,2),
    expected_amount numeric(12,2),
    difference numeric(12,2),
    company_id integer NOT NULL
);


ALTER TABLE public.cash_session_journals OWNER TO posuser;

--
-- Name: cash_session_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.cash_session_journals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_session_journals_id_seq OWNER TO posuser;

--
-- Name: cash_session_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.cash_session_journals_id_seq OWNED BY public.cash_session_journals.id;


--
-- Name: cash_sessions; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.cash_sessions (
    id integer NOT NULL,
    employee_id integer,
    warehouse_id integer,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    notes text,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    company_id integer NOT NULL
);


ALTER TABLE public.cash_sessions OWNER TO posuser;

--
-- Name: cash_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.cash_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_sessions_id_seq OWNER TO posuser;

--
-- Name: cash_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.cash_sessions_id_seq OWNED BY public.cash_sessions.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20) DEFAULT NULL::character varying,
    company_id integer NOT NULL
);


ALTER TABLE public.categories OWNER TO posuser;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO posuser;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    tax_id character varying(50),
    address text,
    phone character varying(20),
    email character varying(150),
    active boolean DEFAULT true NOT NULL,
    logo_url character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    plan_name character varying(50) DEFAULT 'Básico'::character varying NOT NULL,
    subscription_status character varying(20) DEFAULT 'Demo'::character varying NOT NULL,
    expires_at timestamp with time zone,
    max_users integer DEFAULT 5 NOT NULL
);


ALTER TABLE public.companies OWNER TO posuser;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companies_id_seq OWNER TO posuser;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.currencies (
    id integer NOT NULL,
    code character varying(3) NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(5) NOT NULL,
    exchange_rate numeric(12,6) DEFAULT 1.0 NOT NULL,
    is_base boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.currencies OWNER TO posuser;

--
-- Name: currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.currencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.currencies_id_seq OWNER TO posuser;

--
-- Name: currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.currencies_id_seq OWNED BY public.currencies.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    type character varying(20) DEFAULT 'cliente'::character varying NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20),
    email character varying(150),
    address text,
    rif character varying(15),
    tax_name character varying(200),
    tax_regime character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    credit_balance numeric(14,6) DEFAULT 0 NOT NULL
);


ALTER TABLE public.customers OWNER TO posuser;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO posuser;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: employee_warehouses; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.employee_warehouses (
    employee_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.employee_warehouses OWNER TO posuser;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    email character varying(150),
    phone character varying(20),
    role_id integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.employees OWNER TO posuser;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO posuser;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    active boolean DEFAULT true,
    company_id integer NOT NULL
);


ALTER TABLE public.expense_categories OWNER TO posuser;

--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_categories_id_seq OWNER TO posuser;

--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    reference character varying(50),
    description character varying(255) NOT NULL,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    rate numeric(14,6) DEFAULT 1,
    category_id integer NOT NULL,
    payment_journal_id integer,
    employee_id integer NOT NULL,
    notes text,
    status character varying(20) DEFAULT 'activo'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    company_id integer NOT NULL
);


ALTER TABLE public.expenses OWNER TO posuser;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO posuser;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: income_categories; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.income_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    active boolean DEFAULT true,
    company_id integer
);


ALTER TABLE public.income_categories OWNER TO posuser;

--
-- Name: income_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.income_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_categories_id_seq OWNER TO posuser;

--
-- Name: income_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.income_categories_id_seq OWNED BY public.income_categories.id;


--
-- Name: incomes; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.incomes (
    id integer NOT NULL,
    reference character varying(50),
    description character varying(255) NOT NULL,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    rate numeric(14,6) DEFAULT 1,
    category_id integer NOT NULL,
    payment_journal_id integer,
    employee_id integer NOT NULL,
    company_id integer,
    notes text,
    status character varying(20) DEFAULT 'activo'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.incomes OWNER TO posuser;

--
-- Name: incomes_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.incomes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incomes_id_seq OWNER TO posuser;

--
-- Name: incomes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.incomes_id_seq OWNED BY public.incomes.id;


--
-- Name: payment_journals; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.payment_journals (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(30) DEFAULT 'efectivo'::character varying NOT NULL,
    bank_id integer,
    currency_id integer,
    bank character varying(200),
    color character varying(7) DEFAULT '#555555'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.payment_journals OWNER TO posuser;

--
-- Name: payment_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.payment_journals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_journals_id_seq OWNER TO posuser;

--
-- Name: payment_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.payment_journals_id_seq OWNED BY public.payment_journals.id;


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.payment_methods (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(50) NOT NULL,
    color character varying(7) DEFAULT '#555555'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.payment_methods OWNER TO posuser;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_methods_id_seq OWNER TO posuser;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    customer_id integer,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    exchange_rate numeric(12,6) DEFAULT 1.0 NOT NULL,
    payment_journal_id integer,
    employee_id integer,
    reference_date date,
    reference_number character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    change_given numeric(14,6) DEFAULT NULL::numeric,
    change_journal_id integer,
    company_id integer NOT NULL
);


ALTER TABLE public.payments OWNER TO posuser;

--
-- Name: COLUMN payments.change_given; Type: COMMENT; Schema: public; Owner: posuser
--

COMMENT ON COLUMN public.payments.change_given IS 'Cambio/vuelto entregado al cliente (en moneda base)';


--
-- Name: COLUMN payments.change_journal_id; Type: COMMENT; Schema: public; Owner: posuser
--

COMMENT ON COLUMN public.payments.change_journal_id IS 'Diario del que se descontó el cambio entregado';


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO posuser;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: product_combo_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.product_combo_items (
    id integer NOT NULL,
    combo_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.product_combo_items OWNER TO posuser;

--
-- Name: product_combo_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.product_combo_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_combo_items_id_seq OWNER TO posuser;

--
-- Name: product_combo_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.product_combo_items_id_seq OWNED BY public.product_combo_items.id;


--
-- Name: product_lots; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.product_lots (
    id integer NOT NULL,
    product_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    lot_number character varying(100) NOT NULL,
    expiration_date date NOT NULL,
    qty numeric(10,3) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.product_lots OWNER TO posuser;

--
-- Name: product_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.product_lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_lots_id_seq OWNER TO posuser;

--
-- Name: product_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.product_lots_id_seq OWNED BY public.product_lots.id;


--
-- Name: product_stock; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.product_stock (
    warehouse_id integer NOT NULL,
    product_id integer NOT NULL,
    qty numeric(10,3) DEFAULT 0 NOT NULL,
    company_id integer NOT NULL,
    CONSTRAINT product_stock_qty_check CHECK ((qty >= (0)::numeric))
);


ALTER TABLE public.product_stock OWNER TO posuser;

--
-- Name: products; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    price numeric(10,2) NOT NULL,
    stock numeric(10,3) DEFAULT 0 NOT NULL,
    unit character varying(20) DEFAULT 'unidad'::character varying NOT NULL,
    qty_step numeric(10,3) DEFAULT 1.000 NOT NULL,
    category_id integer,
    image_filename character varying(255),
    cost_price numeric(10,2) DEFAULT NULL::numeric,
    profit_margin numeric(5,2) DEFAULT NULL::numeric,
    min_stock numeric(10,3) DEFAULT 0 NOT NULL,
    package_size numeric(10,3) DEFAULT NULL::numeric,
    package_unit character varying(50) DEFAULT NULL::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_service boolean DEFAULT false NOT NULL,
    is_combo boolean DEFAULT false NOT NULL,
    barcode character varying(50),
    company_id integer NOT NULL,
    CONSTRAINT products_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT products_stock_check CHECK ((stock >= (0)::numeric))
);


ALTER TABLE public.products OWNER TO posuser;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO posuser;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: promotion_products; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.promotion_products (
    promotion_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.promotion_products OWNER TO posuser;

--
-- Name: promotions; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.promotions (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    discount_pct numeric(5,2),
    buy_qty integer,
    get_qty integer,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    active boolean DEFAULT true NOT NULL,
    company_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.promotions OWNER TO posuser;

--
-- Name: promotions_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.promotions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.promotions_id_seq OWNER TO posuser;

--
-- Name: promotions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.promotions_id_seq OWNED BY public.promotions.id;


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.purchase_items (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    product_id integer,
    product_name character varying(200) NOT NULL,
    package_unit character varying(50) DEFAULT 'unidad'::character varying NOT NULL,
    package_qty numeric(10,3) DEFAULT 1 NOT NULL,
    package_size numeric(10,3) DEFAULT 1 NOT NULL,
    package_price numeric(10,2) NOT NULL,
    unit_cost numeric(10,2) NOT NULL,
    profit_margin numeric(5,2) DEFAULT 0 NOT NULL,
    sale_price numeric(10,2) NOT NULL,
    total_units numeric(10,3) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    lot_number character varying(100) DEFAULT NULL::character varying,
    expiration_date date
);


ALTER TABLE public.purchase_items OWNER TO posuser;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.purchase_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_items_id_seq OWNER TO posuser;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.purchase_items_id_seq OWNED BY public.purchase_items.id;


--
-- Name: purchase_payments; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.purchase_payments (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    amount numeric(14,6) NOT NULL,
    currency_id integer,
    exchange_rate numeric(12,6) DEFAULT 1 NOT NULL,
    payment_journal_id integer,
    employee_id integer,
    reference_date date,
    reference_number character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.purchase_payments OWNER TO posuser;

--
-- Name: purchase_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.purchase_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_payments_id_seq OWNER TO posuser;

--
-- Name: purchase_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.purchase_payments_id_seq OWNED BY public.purchase_payments.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.purchases (
    id integer NOT NULL,
    supplier_id integer,
    supplier_name character varying(200),
    notes text,
    total numeric(10,2) DEFAULT 0 NOT NULL,
    employee_id integer,
    warehouse_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    payment_status character varying(20) DEFAULT 'pendiente'::character varying NOT NULL,
    company_id integer NOT NULL,
    status character varying(20) DEFAULT 'recibido'::character varying NOT NULL
);


ALTER TABLE public.purchases OWNER TO posuser;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchases_id_seq OWNER TO posuser;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.quotation_items (
    id integer NOT NULL,
    quotation_id integer NOT NULL,
    product_id integer,
    product_name character varying(255) NOT NULL,
    quantity numeric(14,4) NOT NULL,
    price numeric(14,4) NOT NULL,
    subtotal numeric(14,2) NOT NULL
);


ALTER TABLE public.quotation_items OWNER TO posuser;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.quotation_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_items_id_seq OWNER TO posuser;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.quotations (
    id integer NOT NULL,
    customer_id integer,
    customer_name character varying(255),
    customer_rif character varying(50),
    employee_id integer,
    warehouse_id integer,
    currency_id integer,
    exchange_rate numeric(14,6) DEFAULT 1,
    discount_amount numeric(14,2) DEFAULT 0,
    subtotal numeric(14,2) NOT NULL,
    total numeric(14,2) NOT NULL,
    status character varying(20) DEFAULT 'pendiente'::character varying,
    notes text,
    converted_sale_id integer,
    company_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.quotations OWNER TO posuser;

--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotations_id_seq OWNER TO posuser;

--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: return_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer,
    name character varying(300) NOT NULL,
    price numeric(12,4) NOT NULL,
    qty numeric(10,3) NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    sale_item_id integer,
    company_id integer NOT NULL
);


ALTER TABLE public.return_items OWNER TO posuser;

--
-- Name: return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.return_items_id_seq OWNER TO posuser;

--
-- Name: return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.return_items_id_seq OWNED BY public.return_items.id;


--
-- Name: returns; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.returns (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    employee_id integer,
    reason character varying(500),
    total numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    nc_number character varying(50)
);


ALTER TABLE public.returns OWNER TO posuser;

--
-- Name: returns_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.returns_id_seq OWNER TO posuser;

--
-- Name: returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.returns_id_seq OWNED BY public.returns.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.roles OWNER TO posuser;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO posuser;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.sale_items (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    product_id integer,
    name character varying(200) NOT NULL,
    price numeric(10,2) NOT NULL,
    quantity numeric(10,3) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    subtotal numeric(10,2) GENERATED ALWAYS AS (((price - discount) * quantity)) STORED,
    CONSTRAINT sale_items_quantity_check CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.sale_items OWNER TO posuser;

--
-- Name: sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sale_items_id_seq OWNER TO posuser;

--
-- Name: sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.sale_items_id_seq OWNED BY public.sale_items.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    total numeric(10,2) NOT NULL,
    paid numeric(10,2) NOT NULL,
    change numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'pendiente'::character varying NOT NULL,
    customer_id integer,
    employee_id integer,
    currency_id integer,
    exchange_rate numeric(12,6) DEFAULT 1.0 NOT NULL,
    discount_amount numeric(10,2) DEFAULT 0 NOT NULL,
    payment_method character varying(30) DEFAULT 'efectivo'::character varying NOT NULL,
    payment_method_id integer,
    payment_journal_id integer,
    warehouse_id integer,
    serie_id integer,
    serie_range_id integer,
    correlative_number integer,
    invoice_number character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    idempotency_key character varying(64)
);


ALTER TABLE public.sales OWNER TO posuser;

--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_id_seq OWNER TO posuser;

--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- Name: serie_ranges; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.serie_ranges (
    id integer NOT NULL,
    serie_id integer NOT NULL,
    start_number integer NOT NULL,
    end_number integer NOT NULL,
    current_number integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.serie_ranges OWNER TO posuser;

--
-- Name: serie_ranges_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.serie_ranges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.serie_ranges_id_seq OWNER TO posuser;

--
-- Name: serie_ranges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.serie_ranges_id_seq OWNED BY public.serie_ranges.id;


--
-- Name: series; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.series (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    prefix character varying(10) NOT NULL,
    padding integer DEFAULT 4 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    type character varying(20) DEFAULT 'factura'::character varying NOT NULL
);


ALTER TABLE public.series OWNER TO posuser;

--
-- Name: series_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.series_id_seq OWNER TO posuser;

--
-- Name: series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.series_id_seq OWNED BY public.series.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.settings (
    key character varying(100) NOT NULL,
    value text,
    company_id integer NOT NULL
);


ALTER TABLE public.settings OWNER TO posuser;

--
-- Name: stock_session_lines; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.stock_session_lines (
    id integer NOT NULL,
    session_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(255) NOT NULL,
    qty_before numeric(14,4) DEFAULT 0 NOT NULL,
    qty_adjusted numeric(14,4) NOT NULL,
    qty_after numeric(14,4) NOT NULL,
    type character varying(10) NOT NULL,
    reason character varying(60),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_session_lines OWNER TO posuser;

--
-- Name: stock_session_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.stock_session_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_session_lines_id_seq OWNER TO posuser;

--
-- Name: stock_session_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.stock_session_lines_id_seq OWNED BY public.stock_session_lines.id;


--
-- Name: stock_sessions; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.stock_sessions (
    id integer NOT NULL,
    warehouse_id integer NOT NULL,
    employee_id integer,
    company_id integer,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_sessions OWNER TO posuser;

--
-- Name: stock_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.stock_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_sessions_id_seq OWNER TO posuser;

--
-- Name: stock_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.stock_sessions_id_seq OWNED BY public.stock_sessions.id;


--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.stock_transfers (
    id integer NOT NULL,
    from_warehouse_id integer,
    to_warehouse_id integer NOT NULL,
    product_id integer,
    product_name character varying(200) NOT NULL,
    qty numeric(10,3) NOT NULL,
    note text,
    employee_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL,
    CONSTRAINT stock_transfers_qty_check CHECK ((qty > (0)::numeric))
);


ALTER TABLE public.stock_transfers OWNER TO posuser;

--
-- Name: stock_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.stock_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_transfers_id_seq OWNER TO posuser;

--
-- Name: stock_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.stock_transfers_id_seq OWNED BY public.stock_transfers.id;


--
-- Name: user_series; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.user_series (
    user_id integer NOT NULL,
    serie_id integer NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.user_series OWNER TO posuser;

--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: posuser
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.warehouses OWNER TO posuser;

--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: posuser
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouses_id_seq OWNER TO posuser;

--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: posuser
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: banks id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.banks ALTER COLUMN id SET DEFAULT nextval('public.banks_id_seq'::regclass);


--
-- Name: cash_session_journals id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals ALTER COLUMN id SET DEFAULT nextval('public.cash_session_journals_id_seq'::regclass);


--
-- Name: cash_sessions id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions ALTER COLUMN id SET DEFAULT nextval('public.cash_sessions_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: currencies id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.currencies ALTER COLUMN id SET DEFAULT nextval('public.currencies_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: income_categories id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.income_categories ALTER COLUMN id SET DEFAULT nextval('public.income_categories_id_seq'::regclass);


--
-- Name: incomes id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes ALTER COLUMN id SET DEFAULT nextval('public.incomes_id_seq'::regclass);


--
-- Name: payment_journals id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals ALTER COLUMN id SET DEFAULT nextval('public.payment_journals_id_seq'::regclass);


--
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: product_combo_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items ALTER COLUMN id SET DEFAULT nextval('public.product_combo_items_id_seq'::regclass);


--
-- Name: product_lots id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots ALTER COLUMN id SET DEFAULT nextval('public.product_lots_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: promotions id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotions ALTER COLUMN id SET DEFAULT nextval('public.promotions_id_seq'::regclass);


--
-- Name: purchase_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_items_id_seq'::regclass);


--
-- Name: purchase_payments id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments ALTER COLUMN id SET DEFAULT nextval('public.purchase_payments_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: return_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items ALTER COLUMN id SET DEFAULT nextval('public.return_items_id_seq'::regclass);


--
-- Name: returns id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns ALTER COLUMN id SET DEFAULT nextval('public.returns_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sale_items id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items ALTER COLUMN id SET DEFAULT nextval('public.sale_items_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- Name: serie_ranges id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.serie_ranges ALTER COLUMN id SET DEFAULT nextval('public.serie_ranges_id_seq'::regclass);


--
-- Name: series id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series ALTER COLUMN id SET DEFAULT nextval('public.series_id_seq'::regclass);


--
-- Name: stock_session_lines id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_session_lines ALTER COLUMN id SET DEFAULT nextval('public.stock_session_lines_id_seq'::regclass);


--
-- Name: stock_sessions id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions ALTER COLUMN id SET DEFAULT nextval('public.stock_sessions_id_seq'::regclass);


--
-- Name: stock_transfers id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers ALTER COLUMN id SET DEFAULT nextval('public.stock_transfers_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public."SequelizeMeta" (name) FROM stdin;
20260320000000-initial-schema.js
20260320000001-add-is-service-to-products.js
20260320232210-add-combo-support.js
20260324000001-create-cash-sessions.js
20260324000002-update-cash-sessions.js
20260324152000-remove-icon-from-payment-methods.js
20260413000000-add-sale-item-id-to-returns.js
20260413000001-allow-negative-payments.js
20260413100000-add-change-to-payments.js
20260413110000-add-color-to-categories.js
20260413120000-add-lot-fields-to-purchase-items.js
20260413120001-create-product-lots.js
20260414000000-create-expenses.js
20260414200000-create-purchase-payments.js
20260414210000-normalize-inventory-units.js
20260414220000-add-barcode-to-products.js
20260415121000-multi-company-setup.js
20260415133000-add-subscription-fields.js
20260415185900-complete-tenant-isolation-patch.js
20260415190820-isolate-currencies.js
20260415192205-remove-global-unique-constraints.js
20260415193302-final-multi-tenant-hardening.js
20260415200000-settings-composite-pk.js
20260421000000-granular-role-permissions.js
20260515000000-create-quotations.js
20260515001000-add-type-to-series-nc-number-to-returns.js
20260515002000-create-promotions.js
20260518000000-add-status-to-purchases.js
20260522000000-base-currency-symbol-ref.js
20260522010000-add-idempotency-key-to-sales.js
20260525000001-create-incomes.js
20260525100000-fix-change-given-precision.js
20260525200000-fix-amount-precision.js
20260527100000-fix-payments-amount-precision.js
20260529100000-add-credit-balance-to-customers.js
20260529200000-create-stock-sessions.js
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.audit_logs (id, employee_id, employee_name, method, path, ip, status_code, created_at, company_id) FROM stdin;
1	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-18 13:54:55.257299+00	1
2	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:03:25.881254+00	1
3	1	Administrador	POST	/	172.19.0.1	200	2026-05-18 14:04:00.280446+00	1
4	1	Administrador	POST	/1/ranges	172.19.0.1	200	2026-05-18 14:04:11.988467+00	1
5	1	Administrador	PUT	/1/users	172.19.0.1	200	2026-05-18 14:04:13.597112+00	1
6	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-05-18 14:04:41.823668+00	1
7	1	Administrador	POST	/open	172.19.0.1	201	2026-05-18 14:04:48.580101+00	1
8	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:07:13.075429+00	1
9	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-18 14:07:31.087931+00	1
10	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:07:55.212085+00	1
11	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:10:30.255092+00	1
12	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:12:54.885601+00	1
13	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:15:25.200824+00	1
14	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:15:45.487805+00	1
15	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:15:55.188241+00	1
16	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:16:03.502485+00	1
17	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:19:29.56238+00	1
18	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-18 14:23:45.665968+00	1
19	1	Administrador	POST	/3/return	172.19.0.1	201	2026-05-18 14:25:07.045152+00	1
20	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:14.717063+00	1
21	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:16.00161+00	1
22	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:16.524302+00	1
23	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:16.861508+00	1
24	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:22.876449+00	1
25	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:37.416348+00	1
26	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:30:51.908275+00	1
27	1	Administrador	PUT	/1/stock/1	172.19.0.1	200	2026-05-18 14:32:17.223337+00	1
28	1	Administrador	DELETE	/1/stock/1	172.19.0.1	200	2026-05-18 14:32:19.973211+00	1
29	1	Administrador	DELETE	/1/stock/2	172.19.0.1	200	2026-05-18 14:32:21.885511+00	1
30	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:34:01.487172+00	1
31	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:34:51.236336+00	1
32	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:35:18.606544+00	1
33	1	Administrador	PUT	/1/employees	172.19.0.1	200	2026-05-18 14:35:34.776213+00	1
34	1	Administrador	POST	/1/payments	172.19.0.1	500	2026-05-18 14:36:56.236861+00	1
35	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:36:56.714347+00	1
36	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:37:48.112321+00	1
37	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-18 14:38:07.461369+00	1
38	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:38:18.316154+00	1
39	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:44:36.842599+00	1
40	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 14:44:47.674506+00	1
41	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-18 14:45:03.763463+00	1
42	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-18 14:45:05.967366+00	1
43	1	Administrador	POST	/2/payments	172.19.0.1	201	2026-05-18 14:45:24.227151+00	1
44	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:51:19.212738+00	1
45	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-18 14:51:34.038832+00	1
46	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 14:51:57.323059+00	1
47	1	Administrador	DELETE	/1	172.19.0.1	200	2026-05-18 17:32:58.778214+00	1
48	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 17:57:38.588233+00	1
49	1	Administrador	POST	/1/payments	172.19.0.1	201	2026-05-18 18:30:32.272326+00	1
50	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 18:30:54.151086+00	1
51	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 18:31:10.977052+00	1
52	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 18:31:21.178611+00	1
53	1	Administrador	POST	/1/stock	172.19.0.1	200	2026-05-18 18:32:05.600283+00	1
54	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 19:19:48.045492+00	1
55	1	Administrador	POST	/	172.19.0.1	200	2026-05-18 19:27:39.556044+00	1
56	1	Administrador	POST	/2/ranges	172.19.0.1	200	2026-05-18 19:27:48.585233+00	1
57	1	Administrador	PUT	/2/users	172.19.0.1	200	2026-05-18 19:27:48.94232+00	1
58	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 19:59:18.150611+00	1
59	1	Administrador	POST	/	172.19.0.1	201	2026-05-18 20:49:16.095007+00	1
60	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-18 20:49:45.582315+00	1
61	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 13:50:03.149082+00	1
62	1	Administrador	PATCH	/5/confirm	172.19.0.1	200	2026-05-19 13:53:34.022833+00	1
63	1	Administrador	DELETE	/5	172.19.0.1	200	2026-05-19 14:01:46.385857+00	1
64	1	Administrador	DELETE	/3	172.19.0.1	500	2026-05-19 14:01:48.616525+00	1
65	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:02:42.900737+00	1
66	1	Administrador	PATCH	/6	172.19.0.1	200	2026-05-19 14:24:26.260131+00	1
67	1	Administrador	PATCH	/6/confirm	172.19.0.1	200	2026-05-19 14:24:33.748718+00	1
68	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-19 14:24:49.76147+00	1
69	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:26:45.164822+00	1
70	1	Administrador	PATCH	/7	172.19.0.1	200	2026-05-19 14:27:18.662645+00	1
71	1	Administrador	PATCH	/7	172.19.0.1	200	2026-05-19 14:36:49.599516+00	1
72	1	Administrador	PATCH	/7/receive	172.19.0.1	500	2026-05-19 14:36:52.958367+00	1
73	1	Administrador	PATCH	/7/receive	172.19.0.1	500	2026-05-19 14:36:54.498893+00	1
74	1	Administrador	PATCH	/7	172.19.0.1	200	2026-05-19 14:36:57.323723+00	1
75	1	Administrador	PATCH	/7/receive	172.19.0.1	200	2026-05-19 14:36:58.971013+00	1
76	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-19 14:43:58.800764+00	1
77	1	Administrador	DELETE	/3	172.19.0.1	500	2026-05-19 14:44:00.418958+00	1
78	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:44:15.109971+00	1
79	1	Administrador	PATCH	/8/confirm	172.19.0.1	200	2026-05-19 14:46:04.528232+00	1
80	1	Administrador	DELETE	/8	172.19.0.1	200	2026-05-19 14:46:13.453394+00	1
81	1	Administrador	DELETE	/3	172.19.0.1	500	2026-05-19 14:55:38.494205+00	1
82	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 14:56:11.942332+00	1
83	1	Administrador	PATCH	/9	172.19.0.1	200	2026-05-19 14:56:59.856803+00	1
84	1	Administrador	PATCH	/9/confirm	172.19.0.1	200	2026-05-19 14:57:01.611924+00	1
85	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-19 15:01:21.073002+00	1
86	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:01:34.978803+00	1
87	1	Administrador	PATCH	/10	172.19.0.1	200	2026-05-19 15:01:42.174527+00	1
88	1	Administrador	PATCH	/10	172.19.0.1	200	2026-05-19 15:01:50.036692+00	1
89	1	Administrador	PATCH	/10/receive	172.19.0.1	500	2026-05-19 15:08:15.100061+00	1
90	1	Administrador	PATCH	/10	172.19.0.1	200	2026-05-19 15:08:22.27886+00	1
91	1	Administrador	PATCH	/10/receive	172.19.0.1	200	2026-05-19 15:08:23.185153+00	1
92	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-19 15:08:40.630343+00	1
93	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:08:51.220962+00	1
94	1	Administrador	PATCH	/11	172.19.0.1	200	2026-05-19 15:25:19.482369+00	1
95	1	Administrador	PATCH	/11/receive	172.19.0.1	200	2026-05-19 15:25:56.895343+00	1
96	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-19 15:26:13.158487+00	1
97	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:26:24.989615+00	1
98	1	Administrador	PATCH	/12	172.19.0.1	200	2026-05-19 15:28:30.563548+00	1
99	1	Administrador	PATCH	/12/confirm	172.19.0.1	200	2026-05-19 15:32:45.609549+00	1
100	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-19 15:34:02.786622+00	1
101	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:34:21.950862+00	1
102	1	Administrador	PATCH	/13/confirm	172.19.0.1	200	2026-05-19 15:37:01.310713+00	1
103	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-19 15:37:45.270143+00	1
104	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:41:46.136508+00	1
105	1	Administrador	PATCH	/14/confirm	172.19.0.1	200	2026-05-19 15:42:07.530566+00	1
106	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:10.708055+00	1
107	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:12.858611+00	1
108	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:13.354506+00	1
109	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:13.647962+00	1
110	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:43:13.814022+00	1
111	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:19.763878+00	1
112	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:20.811417+00	1
113	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:23.010361+00	1
114	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:24.110046+00	1
115	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:30.019865+00	1
116	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:30.839113+00	1
117	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:31.388739+00	1
118	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:48:34.231748+00	1
119	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:48:42.489807+00	1
120	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:50.391975+00	1
121	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:51.182208+00	1
122	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:52.358765+00	1
123	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:50:52.881793+00	1
124	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:50:57.431801+00	1
125	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:50:58.90984+00	1
126	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:55:24.741523+00	1
127	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:55:26.96366+00	1
128	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:34.74044+00	1
129	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:35.828599+00	1
130	1	Administrador	PATCH	/14/receive	172.19.0.1	500	2026-05-19 15:56:35.873303+00	1
131	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.049181+00	1
132	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.486263+00	1
133	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.680855+00	1
134	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:37.867333+00	1
135	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:38.055166+00	1
136	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:38.182627+00	1
137	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:38.324183+00	1
138	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:39.03885+00	1
139	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:51.977498+00	1
140	1	Administrador	PATCH	/14	172.19.0.1	400	2026-05-19 15:56:52.807694+00	1
141	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-19 15:57:00.461294+00	1
142	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 15:57:30.720699+00	1
143	1	Administrador	PATCH	/15/confirm	172.19.0.1	200	2026-05-19 15:57:47.274903+00	1
144	1	Administrador	PATCH	/15	172.19.0.1	400	2026-05-19 15:58:01.853767+00	1
145	1	Administrador	PATCH	/15	172.19.0.1	200	2026-05-19 16:05:46.506554+00	1
146	1	Administrador	PATCH	/15/receive	172.19.0.1	200	2026-05-19 16:05:47.547064+00	1
147	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-19 16:06:05.737257+00	1
148	1	Administrador	DELETE	/1/stock/5	172.19.0.1	200	2026-05-19 16:06:22.514503+00	1
149	1	Administrador	DELETE	/1/stock/4	172.19.0.1	200	2026-05-19 16:06:24.443424+00	1
150	1	Administrador	DELETE	/1/stock/2	172.19.0.1	200	2026-05-19 16:06:26.549321+00	1
151	1	Administrador	DELETE	/1/stock/6	172.19.0.1	200	2026-05-19 16:06:31.187154+00	1
152	1	Administrador	DELETE	/4	172.19.0.1	400	2026-05-19 16:06:36.558377+00	1
153	1	Administrador	DELETE	/5	172.19.0.1	200	2026-05-19 16:06:40.219366+00	1
154	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-19 16:06:43.139288+00	1
155	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 16:07:07.239165+00	1
156	1	Administrador	PATCH	/16/confirm	172.19.0.1	200	2026-05-19 16:07:32.908062+00	1
157	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-19 16:22:39.973301+00	1
158	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 16:23:23.933496+00	1
159	1	Administrador	PATCH	/17	172.19.0.1	200	2026-05-19 16:23:38.985832+00	1
160	1	Administrador	PATCH	/17	172.19.0.1	200	2026-05-19 16:25:05.764791+00	1
161	1	Administrador	PATCH	/17/confirm	172.19.0.1	200	2026-05-19 16:25:44.817502+00	1
162	1	Administrador	PATCH	/17/receive	172.19.0.1	200	2026-05-19 16:25:47.260177+00	1
163	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-19 16:25:51.600944+00	1
164	1	Administrador	POST	/	172.19.0.1	201	2026-05-19 16:25:58.984022+00	1
165	1	Administrador	PATCH	/18	172.19.0.1	200	2026-05-19 16:29:05.703838+00	1
166	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-19 16:29:15.047722+00	1
167	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-19 16:29:36.398415+00	1
168	1	Administrador	PUT	/2	172.19.0.1	200	2026-05-19 16:29:46.073368+00	1
169	1	Administrador	PUT	/4	172.19.0.1	200	2026-05-19 16:29:53.20003+00	1
170	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-19 16:30:01.222485+00	1
171	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-19 16:30:07.008578+00	1
172	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-19 16:30:18.819881+00	1
173	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-22 14:37:29.867978+00	1
174	1	Administrador	PATCH	/18/confirm	172.19.0.1	200	2026-05-22 14:45:11.435331+00	1
175	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-22 16:09:21.317512+00	1
176	1	Administrador	PUT	/	172.19.0.1	200	2026-05-22 16:28:00.128102+00	1
177	1	Administrador	POST	/1/close	172.19.0.1	200	2026-05-22 20:41:48.373474+00	1
178	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:20:30.667678+00	1
179	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:20:34.924918+00	1
180	1	Administrador	POST	/1/stock	172.19.0.1	200	2026-05-25 15:21:26.494376+00	1
181	1	Administrador	POST	/1/stock	172.19.0.1	200	2026-05-25 15:21:36.429875+00	1
182	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:27:30.876429+00	1
183	1	Administrador	PUT	/roles/2	172.19.0.1	200	2026-05-25 15:27:41.838462+00	1
184	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 15:28:08.70944+00	1
185	1	Administrador	PUT	/roles/3	172.19.0.1	200	2026-05-25 15:28:55.432391+00	1
186	1	Administrador	PUT	/roles/3	172.19.0.1	200	2026-05-25 15:29:20.803774+00	1
187	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 15:55:10.10645+00	1
188	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 15:55:44.698557+00	1
189	1	Administrador	POST	/open	172.19.0.1	201	2026-05-25 15:56:01.051686+00	1
190	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 15:56:18.849205+00	1
191	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:02:51.312914+00	1
192	1	Administrador	DELETE	/8	172.19.0.1	200	2026-05-25 16:04:07.359389+00	1
193	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:07:27.020866+00	1
194	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-25 16:16:39.47075+00	1
195	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:16:56.33006+00	1
196	1	Administrador	DELETE	/9	172.19.0.1	200	2026-05-25 16:18:00.165285+00	1
197	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-25 16:18:02.346566+00	1
198	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-25 16:18:22.18391+00	1
199	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:21:35.813313+00	1
200	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:25:51.430541+00	1
201	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:26:15.154198+00	1
202	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-25 16:27:48.083332+00	1
203	1	Administrador	DELETE	/11	172.19.0.1	200	2026-05-25 16:27:53.131681+00	1
204	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 16:28:03.85392+00	1
205	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-25 16:28:49.415085+00	1
206	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-25 16:28:52.311811+00	1
207	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-25 16:28:56.450765+00	1
208	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:27:24.25644+00	1
209	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-25 17:28:04.843157+00	1
210	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:28:44.394003+00	1
211	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:29:04.190679+00	1
212	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-25 17:36:59.600007+00	1
213	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:37:10.493974+00	1
214	1	Administrador	POST	/2/close	172.19.0.1	200	2026-05-25 17:38:21.855849+00	1
215	1	Administrador	POST	/open	172.19.0.1	201	2026-05-25 17:45:06.312496+00	1
216	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:45:22.878053+00	1
217	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 17:45:36.548004+00	1
218	1	Administrador	POST	/3/close	172.19.0.1	200	2026-05-25 17:47:20.106389+00	1
219	1	Administrador	DELETE	/3	172.19.0.1	200	2026-05-25 18:12:18.513451+00	1
220	1	Administrador	DELETE	/18	172.19.0.1	200	2026-05-25 18:15:58.562884+00	1
221	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-25 18:16:00.354223+00	1
222	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-25 18:16:02.230116+00	1
223	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-25 18:16:07.391934+00	1
224	1	Administrador	DELETE	/13	172.19.0.1	200	2026-05-25 18:16:09.222792+00	1
225	1	Administrador	DELETE	/8	172.19.0.1	200	2026-05-25 18:28:04.594812+00	1
226	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-25 18:28:06.708084+00	1
227	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-25 18:28:09.887298+00	1
228	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-25 18:28:11.665187+00	1
229	1	Administrador	DELETE	/7	172.19.0.1	200	2026-05-25 18:28:21.435319+00	1
230	1	Administrador	DELETE	/6	172.19.0.1	200	2026-05-25 18:28:23.415541+00	1
231	1	Administrador	DELETE	/5	172.19.0.1	200	2026-05-25 18:28:25.339632+00	1
232	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-25 18:28:27.094249+00	1
233	1	Administrador	DELETE	/2	172.19.0.1	200	2026-05-25 18:28:29.004577+00	1
234	1	Administrador	DELETE	/1	172.19.0.1	400	2026-05-25 18:28:32.013732+00	1
235	1	Administrador	DELETE	/1	172.19.0.1	400	2026-05-25 18:28:33.284436+00	1
236	1	Administrador	DELETE	/1	172.19.0.1	400	2026-05-25 18:28:55.373293+00	1
237	1	Administrador	DELETE	/12	172.19.0.1	200	2026-05-25 18:31:52.938654+00	1
238	1	Administrador	DELETE	/14	172.19.0.1	200	2026-05-25 18:32:00.935159+00	1
239	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-25 18:32:02.525282+00	1
240	1	Administrador	PUT	/1/stock/1	172.19.0.1	200	2026-05-25 18:33:56.215786+00	1
241	1	Administrador	DELETE	/4	172.19.0.1	200	2026-05-25 18:34:02.27712+00	1
242	1	Administrador	DELETE	/2	172.19.0.1	200	2026-05-25 18:34:04.084728+00	1
243	1	Administrador	PATCH	/18	172.19.0.1	200	2026-05-25 18:36:26.115982+00	1
244	1	Administrador	PATCH	/18	172.19.0.1	200	2026-05-25 18:37:13.354751+00	1
245	1	Administrador	PATCH	/18/receive	172.19.0.1	200	2026-05-25 18:38:28.857097+00	1
246	1	Administrador	POST	/open	172.19.0.1	201	2026-05-25 18:39:23.708067+00	1
247	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:39:47.757985+00	1
248	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:40:19.628434+00	1
249	1	Administrador	DELETE	/15	172.19.0.1	200	2026-05-25 18:41:25.051814+00	1
250	1	Administrador	DELETE	/10	172.19.0.1	200	2026-05-25 18:41:31.070165+00	1
251	1	Administrador	DELETE	/19	172.19.0.1	400	2026-05-25 18:41:38.119511+00	1
252	1	Administrador	DELETE	/19	172.19.0.1	400	2026-05-25 18:41:38.742843+00	1
253	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:43:05.554529+00	1
254	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:43:59.390637+00	1
255	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:44:32.692849+00	1
256	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:44:53.090457+00	1
257	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-25 18:48:15.911692+00	1
258	1	Administrador	DELETE	/22	172.19.0.1	200	2026-05-25 18:48:26.921825+00	1
259	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:48:43.965841+00	1
260	1	Administrador	DELETE	/18	172.19.0.1	200	2026-05-25 18:49:04.378969+00	1
261	1	Administrador	DELETE	/23	172.19.0.1	200	2026-05-25 18:49:08.105695+00	1
262	1	Administrador	POST	/	172.19.0.1	201	2026-05-25 18:49:24.99794+00	1
263	1	Administrador	POST	/4/close	172.19.0.1	200	2026-05-25 18:57:23.432246+00	1
264	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:49.767524+00	1
265	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:50.516938+00	1
266	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:51.175831+00	1
267	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:52.43564+00	1
268	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-05-25 19:06:53.435378+00	1
269	1	Administrador	PUT	/2/rate	172.19.0.1	200	2026-05-25 19:06:58.077236+00	1
270	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-25 19:06:59.484146+00	1
271	1	Administrador	DELETE	/18/permanent	172.19.0.1	200	2026-05-25 19:16:31.149128+00	1
272	1	Administrador	DELETE	/17/permanent	172.19.0.1	200	2026-05-25 19:16:33.270504+00	1
273	1	Administrador	PUT	/2	172.19.0.1	200	2026-05-25 19:18:28.503433+00	1
274	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-25 19:19:50.60373+00	1
275	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-25 19:20:28.02517+00	1
276	1	Administrador	PUT	/3	172.19.0.1	200	2026-05-25 19:23:46.391886+00	1
277	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:24:12.181863+00	1
278	1	Administrador	DELETE	/20	172.19.0.1	200	2026-05-25 19:24:26.382536+00	1
279	1	Administrador	DELETE	/20/permanent	172.19.0.1	200	2026-05-25 19:24:28.399012+00	1
280	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-25 19:41:17.319273+00	1
281	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:41:42.647379+00	1
282	1	Administrador	PUT	/1	172.19.0.1	200	2026-05-25 19:45:05.309564+00	1
283	1	Administrador	DELETE	/17	172.19.0.1	200	2026-05-25 19:48:57.397475+00	1
284	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:49:05.500091+00	1
285	1	Administrador	DELETE	/18	172.19.0.1	200	2026-05-25 19:51:03.832863+00	1
286	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:52:07.5685+00	1
287	1	Administrador	DELETE	/19	172.19.0.1	200	2026-05-25 19:56:59.361525+00	1
288	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 19:57:05.200553+00	1
289	1	Administrador	DELETE	/20	172.19.0.1	200	2026-05-25 20:01:17.427905+00	1
290	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:01:23.274934+00	1
291	1	Administrador	DELETE	/21	172.19.0.1	200	2026-05-25 20:05:17.258605+00	1
292	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:05:34.866975+00	1
293	1	Administrador	DELETE	/22	172.19.0.1	200	2026-05-25 20:08:41.813928+00	1
294	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:08:55.504313+00	1
295	1	Administrador	DELETE	/23	172.19.0.1	200	2026-05-25 20:08:58.917575+00	1
296	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:09:28.146638+00	1
297	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:09:56.107558+00	1
298	1	Administrador	DELETE	/25	172.19.0.1	200	2026-05-25 20:10:05.750474+00	1
299	1	Administrador	DELETE	/24	172.19.0.1	200	2026-05-25 20:10:09.308068+00	1
300	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:11:25.234254+00	1
301	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:11:31.785008+00	1
302	1	Administrador	DELETE	/27	172.19.0.1	200	2026-05-25 20:11:35.164446+00	1
303	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:13:12.727215+00	1
304	1	Administrador	DELETE	/28	172.19.0.1	200	2026-05-25 20:14:11.867939+00	1
305	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:14:39.295745+00	1
306	1	Administrador	DELETE	/29	172.19.0.1	200	2026-05-25 20:15:20.295054+00	1
307	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:15:42.140208+00	1
308	1	Administrador	DELETE	/30	172.19.0.1	200	2026-05-25 20:15:51.209639+00	1
309	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-25 20:18:05.828528+00	1
310	1	Administrador	DELETE	/26	172.19.0.1	200	2026-05-27 14:45:59.041477+00	1
311	1	Administrador	DELETE	/31	172.19.0.1	200	2026-05-27 14:46:01.063561+00	1
312	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-27 14:46:11.855414+00	1
313	1	Administrador	POST	/18/payments	172.19.0.1	201	2026-05-27 14:46:20.921098+00	1
314	1	Administrador	POST	/12/return	172.19.0.1	201	2026-05-29 13:30:33.563122+00	1
315	1	Administrador	DELETE	/21	172.19.0.1	200	2026-05-29 13:32:43.21032+00	1
316	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:46:35.196484+00	1
317	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:46:40.370192+00	1
318	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:47:46.74739+00	1
319	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:47:52.150433+00	1
320	1	Administrador	POST	/12/exchange	172.19.0.1	500	2026-05-29 13:47:58.53105+00	1
321	1	Administrador	POST	/12/exchange	172.19.0.1	201	2026-05-29 13:49:35.264614+00	1
322	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:10:59.475035+00	1
323	1	Administrador	DELETE	/16	172.19.0.1	200	2026-05-29 15:12:58.401164+00	1
324	1	Administrador	DELETE	/25	172.19.0.1	400	2026-05-29 15:13:09.001749+00	1
325	1	Administrador	DELETE	/25	172.19.0.1	400	2026-05-29 15:13:09.797766+00	1
326	1	Administrador	POST	/12/return	172.19.0.1	201	2026-05-29 15:17:43.711239+00	1
327	1	Administrador	PATCH	/1/credit	172.19.0.1	200	2026-05-29 15:17:59.12587+00	1
328	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:28:45.547844+00	1
329	1	Administrador	PATCH	/19/confirm	172.19.0.1	200	2026-05-29 15:28:58.381635+00	1
330	1	Administrador	PATCH	/19	172.19.0.1	200	2026-05-29 15:31:17.190213+00	1
331	1	Administrador	PATCH	/19	172.19.0.1	200	2026-05-29 15:31:23.761545+00	1
332	1	Administrador	PATCH	/19/receive	172.19.0.1	200	2026-05-29 15:31:24.84333+00	1
333	1	Administrador	DELETE	/19	172.19.0.1	200	2026-05-29 15:32:48.205595+00	1
334	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:35:53.122104+00	1
335	1	Administrador	PATCH	/20/receive	172.19.0.1	500	2026-05-29 15:35:58.847538+00	1
336	1	Administrador	PATCH	/20/receive	172.19.0.1	500	2026-05-29 15:36:04.949342+00	1
337	1	Administrador	PATCH	/20	172.19.0.1	200	2026-05-29 15:36:07.60089+00	1
338	1	Administrador	PATCH	/20/receive	172.19.0.1	200	2026-05-29 15:36:08.347153+00	1
339	1	Administrador	DELETE	/20	172.19.0.1	200	2026-05-29 15:36:17.106005+00	1
340	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:42:50.881294+00	1
341	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:42:57.872686+00	1
342	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:43:08.408423+00	1
343	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:43:41.977073+00	1
344	1	Administrador	POST	/	172.19.0.1	400	2026-05-29 15:43:58.553934+00	1
345	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:45:22.350885+00	1
346	1	Administrador	PATCH	/21/confirm	172.19.0.1	200	2026-05-29 15:45:32.642381+00	1
347	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 15:47:14.712757+00	1
348	1	Administrador	PATCH	/21	172.19.0.1	200	2026-05-29 15:47:59.786874+00	1
349	1	Administrador	PATCH	/21	172.19.0.1	200	2026-05-29 15:52:04.754837+00	1
350	1	Administrador	PATCH	/21	172.19.0.1	200	2026-05-29 15:52:11.292069+00	1
351	1	Administrador	PATCH	/21/receive	172.19.0.1	200	2026-05-29 15:52:11.855445+00	1
352	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-05-29 16:20:17.483435+00	1
353	1	Administrador	POST	/1/sessions/1/lines	172.19.0.1	500	2026-05-29 16:20:17.541583+00	1
354	1	Administrador	POST	/1/sessions/1/lines	172.19.0.1	500	2026-05-29 16:20:25.754325+00	1
355	1	Administrador	POST	/1/sessions/1/lines	172.19.0.1	201	2026-05-29 16:24:52.319351+00	1
356	1	Administrador	PATCH	/1/sessions/1/close	172.19.0.1	200	2026-05-29 16:25:04.275087+00	1
357	1	Administrador	POST	/1/sessions	172.19.0.1	201	2026-05-29 16:25:22.960267+00	1
358	1	Administrador	PATCH	/1/sessions/2/close	172.19.0.1	200	2026-05-29 16:25:24.569651+00	1
359	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 17:01:58.475049+00	1
360	1	Administrador	POST	/open	172.19.0.1	201	2026-05-29 18:18:54.637398+00	1
361	1	Administrador	POST	/	172.19.0.1	500	2026-05-29 18:20:05.928226+00	1
362	1	Administrador	POST	/	172.19.0.1	500	2026-05-29 18:20:12.717894+00	1
363	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:23:21.454167+00	1
364	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:24:13.824204+00	1
365	1	Administrador	DELETE	/30	172.19.0.1	200	2026-05-29 18:28:16.24941+00	1
366	1	Administrador	DELETE	/29	172.19.0.1	200	2026-05-29 18:28:18.1956+00	1
367	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:28:35.340023+00	1
368	1	Administrador	DELETE	/32	172.19.0.1	200	2026-05-29 18:29:12.83969+00	1
369	1	Administrador	DELETE	/31	172.19.0.1	200	2026-05-29 18:29:14.959343+00	1
370	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:33:22.771259+00	1
371	1	Administrador	DELETE	/34	172.19.0.1	200	2026-05-29 18:33:29.955857+00	1
372	1	Administrador	DELETE	/33	172.19.0.1	200	2026-05-29 18:33:32.812363+00	1
373	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:33:47.434073+00	1
374	1	Administrador	DELETE	/36	172.19.0.1	200	2026-05-29 18:33:53.103231+00	1
375	1	Administrador	DELETE	/35	172.19.0.1	200	2026-05-29 18:33:54.683992+00	1
376	1	Administrador	POST	/	172.19.0.1	201	2026-05-29 18:34:16.985007+00	1
377	1	Administrador	POST	/refresh	172.19.0.1	200	2026-05-29 18:42:55.734641+00	1
378	1	Administrador	DELETE	/37	172.19.0.1	200	2026-05-29 18:52:53.369269+00	1
379	1	Administrador	DELETE	/27	172.19.0.1	200	2026-05-29 18:52:55.19172+00	1
380	1	Administrador	DELETE	/24	172.19.0.1	200	2026-05-29 18:52:58.259332+00	1
381	1	Administrador	DELETE	/25	172.19.0.1	400	2026-05-29 18:53:00.348322+00	1
382	1	Administrador	POST	/trigger	172.19.0.1	200	2026-05-29 19:22:02.678134+00	1
383	1	Administrador	POST	/trigger	172.19.0.1	200	2026-05-29 19:22:55.986623+00	1
\.


--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.banks (id, name, code, active, sort_order, created_at, company_id) FROM stdin;
1	Banco de Venezuela	0102	t	0	2026-05-18 13:53:31.63267+00	1
2	Banesco	0134	t	1	2026-05-18 13:53:31.63267+00	1
3	Banco Mercantil	0105	t	2	2026-05-18 13:53:31.63267+00	1
4	BBVA Provincial	0108	t	3	2026-05-18 13:53:31.63267+00	1
\.


--
-- Data for Name: cash_session_journals; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.cash_session_journals (id, session_id, journal_id, opening_amount, closing_amount, expected_amount, difference, company_id) FROM stdin;
6	4	1	0.00	13450.00	13450.00	0.00	1
7	4	2	0.00	0.00	0.00	0.00	1
8	5	1	0.00	\N	\N	\N	1
9	5	2	0.00	\N	\N	\N	1
\.


--
-- Data for Name: cash_sessions; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.cash_sessions (id, employee_id, warehouse_id, status, notes, opened_at, closed_at, company_id) FROM stdin;
4	1	1	closed	\N	2026-05-25 18:39:23.678+00	2026-05-25 18:57:23.408+00	1
5	1	1	open	\N	2026-05-29 18:18:54.586+00	\N	1
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.categories (id, name, color, company_id) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.companies (id, name, tax_id, address, phone, email, active, logo_url, created_at, updated_at, plan_name, subscription_status, expires_at, max_users) FROM stdin;
1	Empresa Principal	\N	\N	\N	\N	t	\N	2026-05-18 13:53:32.861285+00	2026-05-18 13:53:32.861285+00	Ilimitado	Activa	\N	0
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.currencies (id, code, name, symbol, exchange_rate, is_base, active, updated_at, company_id) FROM stdin;
1	USD	Dólar Americano	Ref.	1.000000	t	t	2026-05-22 14:36:47.077537+00	1
2	VES	Bolívar Venezolano	Bs.	549.371600	f	t	2026-05-29 18:42:55.721466+00	1
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.customers (id, type, name, phone, email, address, rif, tax_name, tax_regime, notes, created_at, updated_at, company_id, credit_balance) FROM stdin;
2	proveedor	CHINO SASA	\N	\N	3001 Av Lara	V-11111111	\N	\N	\N	2026-05-18 14:34:51.223+00	2026-05-25 19:18:28.496584+00	1	0.000000
1	cliente	JOSE MUJICA	04261521817	\N	BARQUISIMETO	V-29531224	\N	\N	\N	2026-05-18 14:10:30.24+00	2026-05-29 15:17:59.111604+00	1	0.000000
\.


--
-- Data for Name: employee_warehouses; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.employee_warehouses (employee_id, warehouse_id, company_id) FROM stdin;
1	1	1
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.employees (id, username, password_hash, full_name, email, phone, role_id, active, created_at, updated_at, is_superuser, company_id) FROM stdin;
2	prueba	$2a$10$XUQch63G8TBjTNQ1bgESxOs.n9OzZPrOkxXbVlr4XNKtwphNqvNXG	Prueba	\N	\N	3	t	2026-05-25 15:28:08.692+00	2026-05-25 15:28:08.692+00	f	1
1	admin	$2a$10$Z9MxwHHrTrhOCvd.58SMROpIoqqjQ8gGFQEiZGYiWK7DbXYS2moFa	Administrador	admin@mitienda.com	\N	1	t	2026-05-18 13:53:31.63267+00	2026-05-25 18:11:10.766664+00	t	1
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.expense_categories (id, name, active, company_id) FROM stdin;
1	Servicios Básicos	t	1
2	Alquiler	t	1
3	Nómina / Personal	t	1
4	Impuestos	t	1
5	Mantenimiento	t	1
6	Transporte	t	1
7	Suministros	t	1
8	Otros	t	1
9	Pagos a Proveedores	t	1
10	Cambio / Vuelto	t	1
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.expenses (id, reference, description, amount, currency_id, rate, category_id, payment_journal_id, employee_id, notes, status, created_at, updated_at, company_id) FROM stdin;
16	\N	Cambio entregado — Factura A-0011	0.037700	2	530.504700	10	1	1	\N	activo	2026-05-25 18:43:59.374+00	2026-05-25 18:43:59.374+00	1
19	\N	Cambio entregado — Factura A-0012	0.056550	2	530.504700	10	1	1	\N	activo	2026-05-25 18:49:24.982+00	2026-05-25 18:49:24.982+00	1
36	purchase_payment:32	Pago a proveedor — Proveedor (Compra #18)	48.067435	2	530.504700	9	1	1	Ref: #18	activo	2026-05-27 14:46:11.842+00	2026-05-27 14:46:11.842+00	1
37	purchase_payment:33	Pago a proveedor — Proveedor (Compra #18)	0.556074	2	530.504700	9	1	1	Ref: #18	activo	2026-05-27 14:46:20.902+00	2026-05-27 14:46:20.902+00	1
38	\N	Cambio entregado — Factura A-0013	0.508949	2	530.504700	10	1	1	\N	activo	2026-05-29 18:34:16.969+00	2026-05-29 18:34:16.969+00	1
\.


--
-- Data for Name: income_categories; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.income_categories (id, name, active, company_id) FROM stdin;
1	Ventas Externas	t	\N
2	Transferencia de Cuentas	t	\N
3	Préstamo / Capital	t	\N
4	Devolución de Proveedor	t	\N
5	Comisiones	t	\N
6	Otros	t	\N
\.


--
-- Data for Name: incomes; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.incomes (id, reference, description, amount, currency_id, rate, category_id, payment_journal_id, employee_id, company_id, notes, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_journals; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.payment_journals (id, name, type, bank_id, currency_id, bank, color, active, sort_order, company_id) FROM stdin;
1	CAJA BS	efectivo	\N	2	\N	#6366f1	t	0	1
2	Caja Divisa	efectivo	\N	1	\N	#32c814	t	0	1
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.payment_methods (id, name, code, color, active, sort_order, created_at, company_id) FROM stdin;
1	Efectivo	efectivo	#27ae60	t	0	2026-05-18 13:53:31.63267+00	1
2	Transferencia	transferencia	#5dade2	t	1	2026-05-18 13:53:31.63267+00	1
3	Pago Móvil	pago_movil	#f0a500	t	2	2026-05-18 13:53:31.63267+00	1
4	Zelle	zelle	#9b59b6	t	3	2026-05-18 13:53:31.63267+00	1
5	Punto de Venta	punto_venta	#e74c3c	t	4	2026-05-18 13:53:31.63267+00	1
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.payments (id, sale_id, customer_id, amount, currency_id, exchange_rate, payment_journal_id, employee_id, reference_date, reference_number, notes, created_at, change_given, change_journal_id, company_id) FROM stdin;
25	16	1	2.460000	1	1.000000	\N	1	2026-05-29	\N	Crédito aplicado por cambio — NC NC-0002	2026-05-29 13:49:35.24+00	\N	\N	1
26	11	1	5.990000	1	1.000000	\N	1	2026-05-29	\N	Crédito de cliente aplicado	2026-05-29 15:10:59.413+00	\N	\N	1
28	16	1	-2.460000	1	1.000000	\N	\N	2026-05-29	ANUL-16	Reembolso automático por anulación de factura	2026-05-29 15:12:58.386+00	\N	\N	1
\.


--
-- Data for Name: product_combo_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.product_combo_items (id, combo_id, product_id, quantity, company_id) FROM stdin;
8	8	3	24.000	1
9	9	1	20.000	1
10	11	10	24.000	1
\.


--
-- Data for Name: product_lots; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.product_lots (id, product_id, warehouse_id, lot_number, expiration_date, qty, created_at, updated_at, company_id) FROM stdin;
1	3	1	LOT 1	2026-12-29	24.000	2026-05-29 15:52:11.732+00	2026-05-29 15:52:11.761+00	1
\.


--
-- Data for Name: product_stock; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.product_stock (warehouse_id, product_id, qty, company_id) FROM stdin;
1	8	0.000	1
1	9	0.000	1
1	1	12.000	1
1	11	0.000	1
1	10	19.000	1
1	3	51.000	1
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.products (id, name, price, stock, unit, qty_step, category_id, image_filename, cost_price, profit_margin, min_stock, package_size, package_unit, created_at, updated_at, is_service, is_combo, barcode, company_id) FROM stdin;
9	Bulto de Harina Pan (20.000)	33.80	0.000	unidad	1.000	\N	\N	\N	\N	0.000	\N	\N	2026-05-25 18:38:28.712112+00	2026-05-25 18:38:28.813+00	f	t	\N	1
1	Harina Pan	1.69	12.000	UNIDAD	1.000	\N	\N	1.30	30.00	20.000	20.000	Bulto	2026-05-18 14:07:12.984569+00	2026-05-29 15:17:43.639192+00	f	f	\N	1
8	Bulto de Harina Juana (24.000)	29.33	0.000	unidad	1.000	\N	\N	\N	\N	0.000	\N	\N	2026-05-25 18:38:28.712112+00	2026-05-29 15:52:11.714427+00	f	t	\N	1
11	Bulto de ARROZ  (24.000)	26.00	0.000	unidad	1.000	\N	\N	\N	\N	0.000	\N	\N	2026-05-29 15:52:11.714427+00	2026-05-29 15:52:11.817+00	f	t	\N	1
10	ARROZ 	1.08	19.000	UNIDAD	1.000	\N	\N	0.83	30.00	0.000	24.000	Bulto	2026-05-29 15:47:14.676358+00	2026-05-29 18:23:21.381447+00	f	f	\N	1
3	Harina Juana	1.22	51.000	UNIDAD	1.000	\N	\N	0.94	30.00	30.000	24.000	Bulto	2026-05-18 14:34:01.475608+00	2026-05-29 18:23:21.381447+00	f	f	\N	1
\.


--
-- Data for Name: promotion_products; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.promotion_products (promotion_id, product_id) FROM stdin;
\.


--
-- Data for Name: promotions; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.promotions (id, name, type, discount_pct, buy_qty, get_qty, starts_at, ends_at, active, company_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.purchase_items (id, purchase_id, product_id, product_name, package_unit, package_qty, package_size, package_price, unit_cost, profit_margin, sale_price, total_units, subtotal, lot_number, expiration_date) FROM stdin;
40	18	3	Harina Juana	Bulto	1.000	24.000	22.62	0.94	30.00	1.23	24.000	22.62	\N	\N
41	18	1	Harina Pan	Bulto	1.000	20.000	26.00	1.30	30.00	1.69	20.000	26.00	\N	\N
52	21	3	Harina Juana	Bulto	1.000	24.000	22.56	0.94	30.00	1.22	24.000	22.56	LOT 1	2026-12-29
53	21	10	ARROZ 	Bulto	1.000	24.000	20.00	0.83	30.00	1.08	24.000	20.00	\N	\N
\.


--
-- Data for Name: purchase_payments; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.purchase_payments (id, purchase_id, amount, currency_id, exchange_rate, payment_journal_id, employee_id, reference_date, reference_number, notes, created_at, company_id) FROM stdin;
32	18	48.067435	2	530.504700	1	1	2026-05-27	\N	\N	2026-05-27 14:46:11.813+00	1
33	18	0.552565	2	530.504700	1	1	2026-05-27	\N	\N	2026-05-27 14:46:20.897+00	1
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.purchases (id, supplier_id, supplier_name, notes, total, employee_id, warehouse_id, created_at, payment_status, company_id, status) FROM stdin;
21	\N	\N	\N	42.56	1	1	2026-05-29 15:45:22.312+00	pendiente	1	recibido
18	\N	\N	\N	48.62	1	1	2026-05-19 16:25:58.955+00	pagado	1	recibido
\.


--
-- Data for Name: quotation_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.quotation_items (id, quotation_id, product_id, product_name, quantity, price, subtotal) FROM stdin;
1	1	10	ARROZ 	5.0000	1.0800	5.40
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.quotations (id, customer_id, customer_name, customer_rif, employee_id, warehouse_id, currency_id, exchange_rate, discount_amount, subtotal, total, status, notes, converted_sale_id, company_id, created_at, updated_at) FROM stdin;
1	\N	\N	\N	1	1	1	1.000000	0.00	5.40	5.40	convertida	\N	19	1	2026-05-29 17:01:58.439+00	2026-05-29 18:23:21.438+00
\.


--
-- Data for Name: return_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.return_items (id, return_id, product_id, name, price, qty, subtotal, sale_item_id, company_id) FROM stdin;
2	2	1	Harina Pan	1.6900	3.000	5.07	12	1
8	8	1	Harina Pan	1.6900	2.000	3.38	12	1
9	9	1	Harina Pan	1.6900	2.000	3.38	12	1
\.


--
-- Data for Name: returns; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.returns (id, sale_id, employee_id, reason, total, created_at, company_id, nc_number) FROM stdin;
2	12	1	\N	5.07	2026-05-29 13:30:33.511+00	1	NC-0001
8	12	1	Cambio de producto	3.38	2026-05-29 13:49:35.181+00	1	NC-0002
9	12	1	\N	3.38	2026-05-29 15:17:43.655+00	1	NC-0003
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.roles (id, name, label, permissions) FROM stdin;
1	admin	Administrador	{"all": true}
4	warehouse	Almacén	{"products": true, "inventory": true, "purchases": true}
2	manager	Gerente	{"sales": false, "config": false, "reports": false, "products": false}
3	cashier	Cajero	{"sales": true, "products": false, "customers": true}
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.sale_items (id, sale_id, product_id, name, price, quantity, discount) FROM stdin;
11	11	1	Harina Pan	1.69	5.000	0.00
12	12	1	Harina Pan	1.69	10.000	0.00
13	16	3	Harina Juana	1.23	2.000	0.00
20	19	10	ARROZ 	1.08	5.000	0.00
21	19	3	Harina Juana	1.22	5.000	0.00
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.sales (id, total, paid, change, status, customer_id, employee_id, currency_id, exchange_rate, discount_amount, payment_method, payment_method_id, payment_journal_id, warehouse_id, serie_id, serie_range_id, correlative_number, invoice_number, created_at, company_id, idempotency_key) FROM stdin;
19	11.50	0.00	0.00	pendiente	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	13	A-0013	2026-05-29 18:23:21.397+00	1	cde76719-0c15-4b86-b482-5a02da48c399
11	8.45	0.00	0.00	parcial	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	11	A-0011	2026-05-25 18:43:05.517+00	1	328b6f81-3a2c-438f-9aaa-f53d2165d06f
12	16.90	0.00	0.00	pendiente	1	1	1	1.000000	0.00	efectivo	\N	\N	1	1	1	12	A-0012	2026-05-25 18:44:32.668+00	1	1d5516da-81b9-4339-aa68-3c55d477a388
16	2.46	0.00	0.00	anulado	1	1	1	1.000000	0.00	efectivo	\N	\N	1	\N	\N	\N	\N	2026-05-29 13:49:35.216+00	1	\N
\.


--
-- Data for Name: serie_ranges; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.serie_ranges (id, serie_id, start_number, end_number, current_number, active, created_at) FROM stdin;
2	2	1	100	4	t	2026-05-18 19:27:48.572+00
1	1	1	100	14	t	2026-05-18 14:04:11.977+00
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.series (id, name, prefix, padding, active, created_at, company_id, type) FROM stdin;
1	A	A	4	t	2026-05-18 14:04:00.269+00	1	factura
2	NC	NC	4	t	2026-05-18 19:27:39.537+00	1	nc
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.settings (key, value, company_id) FROM stdin;
base_currency	USD	1
store_name	Mi Tienda	1
tax_name	IVA	1
tax_rate	16	1
\.


--
-- Data for Name: stock_session_lines; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.stock_session_lines (id, session_id, warehouse_id, product_id, product_name, qty_before, qty_adjusted, qty_after, type, reason, notes, created_at, updated_at) FROM stdin;
1	1	1	3	Harina Juana	48.0000	8.0000	56.0000	in	compra	\N	2026-05-29 16:24:52.301+00	2026-05-29 16:24:52.301+00
\.


--
-- Data for Name: stock_sessions; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.stock_sessions (id, warehouse_id, employee_id, company_id, status, opened_at, closed_at, notes, created_at, updated_at) FROM stdin;
1	1	1	1	closed	2026-05-29 16:20:17.459+00	2026-05-29 16:25:04.257+00	\N	2026-05-29 16:20:17.46+00	2026-05-29 16:25:04.258+00
2	1	1	1	closed	2026-05-29 16:25:22.945+00	2026-05-29 16:25:24.55+00	\N	2026-05-29 16:25:22.946+00	2026-05-29 16:25:24.55+00
\.


--
-- Data for Name: stock_transfers; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.stock_transfers (id, from_warehouse_id, to_warehouse_id, product_id, product_name, qty, note, employee_id, created_at, company_id) FROM stdin;
\.


--
-- Data for Name: user_series; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.user_series (user_id, serie_id, company_id) FROM stdin;
1	1	1
1	2	1
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: posuser
--

COPY public.warehouses (id, name, description, active, sort_order, created_at, company_id) FROM stdin;
1	Principal	Almacén Principal	t	0	2026-05-18 13:53:31.63267+00	1
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 383, true);


--
-- Name: banks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.banks_id_seq', 4, true);


--
-- Name: cash_session_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.cash_session_journals_id_seq', 9, true);


--
-- Name: cash_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.cash_sessions_id_seq', 5, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.companies_id_seq', 1, false);


--
-- Name: currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.currencies_id_seq', 2, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.customers_id_seq', 2, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.employees_id_seq', 2, true);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 10, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.expenses_id_seq', 38, true);


--
-- Name: income_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.income_categories_id_seq', 1, false);


--
-- Name: incomes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.incomes_id_seq', 1, false);


--
-- Name: payment_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.payment_journals_id_seq', 2, true);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 5, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.payments_id_seq', 37, true);


--
-- Name: product_combo_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.product_combo_items_id_seq', 10, true);


--
-- Name: product_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.product_lots_id_seq', 1, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.products_id_seq', 11, true);


--
-- Name: promotions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.promotions_id_seq', 1, true);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.purchase_items_id_seq', 53, true);


--
-- Name: purchase_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.purchase_payments_id_seq', 33, true);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.purchases_id_seq', 21, true);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.quotation_items_id_seq', 1, true);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, true);


--
-- Name: return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.return_items_id_seq', 9, true);


--
-- Name: returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.returns_id_seq', 9, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.sale_items_id_seq', 21, true);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.sales_id_seq', 19, true);


--
-- Name: serie_ranges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.serie_ranges_id_seq', 2, true);


--
-- Name: series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.series_id_seq', 2, true);


--
-- Name: stock_session_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.stock_session_lines_id_seq', 1, true);


--
-- Name: stock_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.stock_sessions_id_seq', 2, true);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.stock_transfers_id_seq', 1, false);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: posuser
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 1, true);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banks banks_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_pkey PRIMARY KEY (id);


--
-- Name: cash_session_journals cash_session_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_pkey PRIMARY KEY (id);


--
-- Name: cash_sessions cash_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: employee_warehouses employee_warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_pkey PRIMARY KEY (employee_id, warehouse_id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employees employees_username_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_username_key UNIQUE (username);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: income_categories income_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.income_categories
    ADD CONSTRAINT income_categories_pkey PRIMARY KEY (id);


--
-- Name: incomes incomes_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_pkey PRIMARY KEY (id);


--
-- Name: payment_journals payment_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: product_combo_items product_combo_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_pkey PRIMARY KEY (id);


--
-- Name: product_lots product_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_pkey PRIMARY KEY (id);


--
-- Name: product_stock product_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_pkey PRIMARY KEY (warehouse_id, product_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: promotion_products promotion_products_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotion_products
    ADD CONSTRAINT promotion_products_pkey PRIMARY KEY (promotion_id, product_id);


--
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_payments purchase_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: return_items return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_pkey PRIMARY KEY (id);


--
-- Name: returns returns_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sales sales_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: serie_ranges serie_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.serie_ranges
    ADD CONSTRAINT serie_ranges_pkey PRIMARY KEY (id);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key, company_id);


--
-- Name: stock_session_lines stock_session_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_session_lines
    ADD CONSTRAINT stock_session_lines_pkey PRIMARY KEY (id);


--
-- Name: stock_sessions stock_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions
    ADD CONSTRAINT stock_sessions_pkey PRIMARY KEY (id);


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: user_series user_series_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_pkey PRIMARY KEY (user_id, serie_id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: banks_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX banks_name_company_id_unique ON public.banks USING btree (name, company_id);


--
-- Name: categories_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX categories_name_company_id_unique ON public.categories USING btree (name, company_id);


--
-- Name: currencies_code_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX currencies_code_company_id_unique ON public.currencies USING btree (code, company_id);


--
-- Name: customers_email_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX customers_email_company_id_unique ON public.customers USING btree (email, company_id);


--
-- Name: customers_rif_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX customers_rif_company_id_unique ON public.customers USING btree (rif, company_id);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_employee; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_audit_employee ON public.audit_logs USING btree (employee_id);


--
-- Name: idx_customers_name; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_customers_name ON public.customers USING btree (name);


--
-- Name: idx_customers_rif; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_customers_rif ON public.customers USING btree (rif);


--
-- Name: idx_employees_username; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_employees_username ON public.employees USING btree (username);


--
-- Name: idx_payments_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_payments_created_at ON public.payments USING btree (created_at DESC);


--
-- Name: idx_payments_customer; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_payments_customer ON public.payments USING btree (customer_id);


--
-- Name: idx_payments_sale_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_payments_sale_id ON public.payments USING btree (sale_id);


--
-- Name: idx_product_lots_expiry; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_lots_expiry ON public.product_lots USING btree (expiration_date);


--
-- Name: idx_product_lots_lot; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_lots_lot ON public.product_lots USING btree (lot_number);


--
-- Name: idx_product_lots_product_warehouse; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_lots_product_warehouse ON public.product_lots USING btree (product_id, warehouse_id);


--
-- Name: idx_product_stock_product; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_stock_product ON public.product_stock USING btree (product_id);


--
-- Name: idx_product_stock_warehouse; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_product_stock_warehouse ON public.product_stock USING btree (warehouse_id);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_products_category ON public.products USING btree (category_id);


--
-- Name: idx_purchase_items_purch; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_purchase_items_purch ON public.purchase_items USING btree (purchase_id);


--
-- Name: idx_purchases_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_purchases_created_at ON public.purchases USING btree (created_at DESC);


--
-- Name: idx_sale_items_sale; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sale_items_sale ON public.sale_items USING btree (sale_id);


--
-- Name: idx_sales_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_created_at ON public.sales USING btree (created_at DESC);


--
-- Name: idx_sales_customer; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_customer ON public.sales USING btree (customer_id);


--
-- Name: idx_sales_employee; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_employee ON public.sales USING btree (employee_id);


--
-- Name: idx_sales_journal; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_sales_journal ON public.sales USING btree (payment_journal_id);


--
-- Name: idx_transfers_created_at; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX idx_transfers_created_at ON public.stock_transfers USING btree (created_at DESC);


--
-- Name: payment_methods_code_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX payment_methods_code_company_id_unique ON public.payment_methods USING btree (code, company_id);


--
-- Name: payment_methods_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX payment_methods_name_company_id_unique ON public.payment_methods USING btree (name, company_id);


--
-- Name: products_barcode_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX products_barcode_company_id_unique ON public.products USING btree (barcode, company_id);


--
-- Name: return_items_sale_item_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX return_items_sale_item_id ON public.return_items USING btree (sale_item_id);


--
-- Name: stock_session_lines_session_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX stock_session_lines_session_id ON public.stock_session_lines USING btree (session_id);


--
-- Name: stock_sessions_company_id; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX stock_sessions_company_id ON public.stock_sessions USING btree (company_id);


--
-- Name: stock_sessions_warehouse_id_status; Type: INDEX; Schema: public; Owner: posuser
--

CREATE INDEX stock_sessions_warehouse_id_status ON public.stock_sessions USING btree (warehouse_id, status);


--
-- Name: warehouses_name_company_id_unique; Type: INDEX; Schema: public; Owner: posuser
--

CREATE UNIQUE INDEX warehouses_name_company_id_unique ON public.warehouses USING btree (name, company_id);


--
-- Name: currencies trg_currencies_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_currencies_updated_at BEFORE UPDATE ON public.currencies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: customers trg_customers_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: employees trg_employees_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: products trg_products_updated_at; Type: TRIGGER; Schema: public; Owner: posuser
--

CREATE TRIGGER trg_products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: audit_logs audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: banks banks_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: cash_session_journals cash_session_journals_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: cash_session_journals cash_session_journals_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES public.payment_journals(id) ON DELETE SET NULL;


--
-- Name: cash_session_journals cash_session_journals_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_session_journals
    ADD CONSTRAINT cash_session_journals_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.cash_sessions(id) ON DELETE CASCADE;


--
-- Name: cash_sessions cash_sessions_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: cash_sessions cash_sessions_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: cash_sessions cash_sessions_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: categories categories_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: currencies currencies_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: customers customers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: employee_warehouses employee_warehouses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: employee_warehouses employee_warehouses_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_warehouses employee_warehouses_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employee_warehouses
    ADD CONSTRAINT employee_warehouses_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: employees employees_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: employees employees_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: expense_categories expense_categories_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.expense_categories(id);


--
-- Name: expenses expenses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: expenses expenses_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: expenses expenses_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id);


--
-- Name: incomes incomes_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.income_categories(id);


--
-- Name: incomes incomes_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: incomes incomes_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: incomes incomes_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id);


--
-- Name: payment_journals payment_journals_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.banks(id) ON DELETE SET NULL;


--
-- Name: payment_journals payment_journals_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: payment_journals payment_journals_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_journals
    ADD CONSTRAINT payment_journals_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id) ON DELETE SET NULL;


--
-- Name: payment_methods payment_methods_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: payments payments_change_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_change_journal_id_fkey FOREIGN KEY (change_journal_id) REFERENCES public.payment_journals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: payments payments_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id) ON DELETE SET NULL;


--
-- Name: payments payments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: payments payments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: payments payments_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id) ON DELETE SET NULL;


--
-- Name: payments payments_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: product_combo_items product_combo_items_combo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_combo_id_fkey FOREIGN KEY (combo_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_combo_items product_combo_items_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: product_combo_items product_combo_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_combo_items
    ADD CONSTRAINT product_combo_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_lots product_lots_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: product_lots product_lots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_lots product_lots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_lots
    ADD CONSTRAINT product_lots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_stock product_stock_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: product_stock product_stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_stock product_stock_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.product_stock
    ADD CONSTRAINT product_stock_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: products products_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: promotion_products promotion_products_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotion_products
    ADD CONSTRAINT promotion_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: promotion_products promotion_products_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.promotion_products
    ADD CONSTRAINT promotion_products_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES public.promotions(id) ON DELETE CASCADE;


--
-- Name: purchase_items purchase_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: purchase_items purchase_items_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE CASCADE;


--
-- Name: purchase_payments purchase_payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: purchase_payments purchase_payments_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: purchase_payments purchase_payments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: purchase_payments purchase_payments_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id);


--
-- Name: purchase_payments purchase_payments_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: purchases purchases_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: purchases purchases_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: quotation_items quotation_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: quotation_items quotation_items_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_quotation_id_fkey FOREIGN KEY (quotation_id) REFERENCES public.quotations(id) ON DELETE CASCADE;


--
-- Name: quotations quotations_converted_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_converted_sale_id_fkey FOREIGN KEY (converted_sale_id) REFERENCES public.sales(id);


--
-- Name: quotations quotations_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: quotations quotations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: quotations quotations_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: quotations quotations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: return_items return_items_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: return_items return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: return_items return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.returns(id) ON DELETE CASCADE;


--
-- Name: return_items return_items_sale_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_sale_item_id_fkey FOREIGN KEY (sale_item_id) REFERENCES public.sale_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: returns returns_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: returns returns_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: returns returns_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: sale_items sale_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: sale_items sale_items_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: sales sales_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: sales sales_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id) ON DELETE SET NULL;


--
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: sales sales_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: sales sales_payment_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_payment_journal_id_fkey FOREIGN KEY (payment_journal_id) REFERENCES public.payment_journals(id) ON DELETE SET NULL;


--
-- Name: sales sales_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id) ON DELETE SET NULL;


--
-- Name: sales sales_serie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_serie_id_fkey FOREIGN KEY (serie_id) REFERENCES public.series(id) ON DELETE SET NULL;


--
-- Name: sales sales_serie_range_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_serie_range_id_fkey FOREIGN KEY (serie_range_id) REFERENCES public.serie_ranges(id) ON DELETE SET NULL;


--
-- Name: sales sales_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: serie_ranges serie_ranges_serie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.serie_ranges
    ADD CONSTRAINT serie_ranges_serie_id_fkey FOREIGN KEY (serie_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: series series_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: settings settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: stock_session_lines stock_session_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_session_lines
    ADD CONSTRAINT stock_session_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.stock_sessions(id) ON DELETE CASCADE;


--
-- Name: stock_sessions stock_sessions_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions
    ADD CONSTRAINT stock_sessions_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: stock_sessions stock_sessions_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_sessions
    ADD CONSTRAINT stock_sessions_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_transfers stock_transfers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: stock_transfers stock_transfers_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_from_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_from_warehouse_id_fkey FOREIGN KEY (from_warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: stock_transfers stock_transfers_to_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_to_warehouse_id_fkey FOREIGN KEY (to_warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: user_series user_series_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: user_series user_series_serie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_serie_id_fkey FOREIGN KEY (serie_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: user_series user_series_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.user_series
    ADD CONSTRAINT user_series_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: warehouses warehouses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: posuser
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GeGoulK4Zn2Hm9hktZ3fjtSBvylAm48JegQucnrFnNpcFe5qt2EennVp3czSCqb

